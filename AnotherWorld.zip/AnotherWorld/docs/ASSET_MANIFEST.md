# Asset Manifest

สร้างจาก `MF` ในเกม (manifest7.json) และไฟล์บนดิสก์ วันที่ 2026-11-11
ทุกภาพอยู่ใต้ `a/` ในอาร์ติแฟกต์ (ต้นฉบับที่ /home/claude/game3/a)

## ตัวละครคน (ระบบชั้น)

| ไฟล์ | ขนาด | สเปก | ที่มา | ใช้ที่ |
|---|---|---|---|---|
| a/gh/chars.png | 800x14336 | 32 ชั้น ชั้นละ 800x448 · เฟรม 80x64 · 7 แถว: idle 5, walk 8, run 8, jump 4, fall 4, attack 6, death 10 · จุดยึด: กลางล่างของเฟรม | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | gchar.js `charFrame`, `drawHuman` ทุกคนในเกม |

ลำดับชั้น: ผิวชาย 0-4, ผิวหญิง 5-9, ผมชาย 10, ผมหญิง 15, เสื้อชาย 20-21, กางเกง 22, บูท 23, รองเท้า 24, คอร์เซ็ต 25-26, กระโปรง 27, ถุงเท้า 28, บูทหญิง 29, ดาบชาย 30, ดาบหญิง 31
สีผม 20 สี เสื้อ 16 สี เปลี่ยนสีด้วยโค้ด ทรงผม 6 แบบต่อเพศสร้างด้วยโค้ดจากชั้นผม

## มอนสเตอร์

| คีย์ | ไฟล์ | เฟรม (กxส) | ท่า: จำนวนเฟรม | ที่มา |
|---|---|---|---|---|
| slime_g | a/m/slime_g/*.png | 128x128 | Idle 8, Attack_1 4, Hurt 6, Dead 3 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| slime_b | a/m/slime_b/*.png | 128x128 | Idle 8, Attack_1 4, Hurt 6, Dead 3 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| slime_r | a/m/slime_r/*.png | 128x128 | Idle 8, Attack_1 4, Hurt 6, Dead 3 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| skel_w | a/m/skel_w/*.png | 128x128 | Idle 7, Attack_1 5, Hurt 2, Dead 4 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| skel_s | a/m/skel_s/*.png | 128x128 | Idle 7, Attack_1 4, Hurt 3, Dead 5 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| skel_a | a/m/skel_a/*.png | 128x128 | Idle 7, Attack_1 5, Hurt 2, Dead 5 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| wolf_w | a/m/wolf_w/*.png | 128x128 | Idle 8, Attack_1 6, Hurt 2, Dead 2 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| wolf_b | a/m/wolf_b/*.png | 128x128 | Idle 8, Attack_1 6, Hurt 2, Dead 2 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| wolf_r | a/m/wolf_r/*.png | 128x128 | Idle 8, Attack_1 6, Hurt 2, Dead 2 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ |
| rat | a/m2/rat.png | 32x32 | Idle 6, Walk 6, Attack_1 6, Hurt 6, Dead 6 | Rat pack · **ต้องยืนยัน** |
| frost | a/m2/frost.png | 192x128 | Idle 6, Walk 10, Attack_1 14, Hurt 7, Dead 16 | Frost Guardian pack · **ต้องยืนยัน** |
| demonlord | a/m2/demonlord.png | 80x64 | Idle 16, Walk 16, Attack_1 16, Hurt 3, Dead 16 | Dark fantasy big boss · **ต้องยืนยัน** |
| necro | a/m2/necro.png | 160x128 | Idle 8, Walk 8, Attack_1 17, Hurt 5, Dead 9 | Necromancer sheet · **ต้องยืนยัน** |
| td0 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td1 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td2 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td3 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td4 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td5 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td6 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td7 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td8 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td9 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |
| td10 | a/m2/td.png | 80x80 | Idle 6, Walk 8, Attack_1 6, Hurt 5, Dead 8 | Topdown Monsters Part 1 Free · ผู้สร้างไม่ระบุในไฟล์ **ต้องยืนยัน** |

จุดยึดเท้าต่อท่าตั้งไว้ใน `ANCHORS` (art12.js) ฟิลด์ `oy` ยกขึ้น และ `dx` เลื่อนข้าง

## ฉากหลัง (576x324 ต่อชั้น ปูซ้ำแนวนอนเป็น 1152)

| คีย์ | ชั้น | ที่มา | ใช้ที่ |
|---|---|---|---|
| awaken | 7 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| guild | 8 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| casino | 8 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| hospital | 7 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| home | 4 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| tower | 6 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| sky | 5 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| sea | 1 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| death | 4 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_forest | 7 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_green | 8 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_snow | 11 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_mount | 3 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_autumn | 6 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_desert | 5 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_rocks | 6 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| fire | 7 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| gatered | 7 | CraftPix.net Free · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| city | 6 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| city_w | 6 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| city_a | 6 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| gate | 5 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| train | 5 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| w_ruin | 6 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| fwinter | 5 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| road | 5 | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากต่อสู้/เดินทาง `bgWide` |
| a/gh/c_{n,w,a}{1-5,castle}.png | 6 ต่อฤดู x 3 ฤดู | GandalfHardcore · ใช้ในเกมได้ ห้ามแจกไฟล์ต้นฉบับ | ฉากเมือง ตลาด ทุ่ง ทะเลสาบ ลานฝึก หน้าแรก `ghLay` |

## เอฟเฟกต์

| คีย์ | ไฟล์ | เฟรม | จำนวน | ที่มา |
|---|---|---|---|---|
| wind | a/fx/wind.png | 200x150 | 9 | CraftPix.net Free |
| fire | a/fx/fire.png | 200x150 | 12 | CraftPix.net Free |
| light | a/fx/light.png | 200x150 | 12 | CraftPix.net Free |
| poison | a/fx/poison.png | 200x150 | 12 | CraftPix.net Free |
| water | a/fx/water.png | 200x150 | 12 | CraftPix.net Free |
| ult | a/fx/ult.png | 200x150 | 10 | CraftPix.net Free |
| sword | a/m2/fx.png | 104x64 | 14 | pvfx · CC0 |
| bow | a/m2/fx.png | 64x32 | 17 | pvfx · CC0 |
| mage | a/m2/fx.png | 96x64 | 19 | pvfx · CC0 |
| assassin | a/m2/fx.png | 56x56 | 12 | pvfx · CC0 |
| healer | a/m2/fx.png | 80x120 | 14 | pvfx · CC0 |
| tank | a/m2/fx.png | 128x64 | 19 | pvfx · CC0 |
| curse | a/m2/fx.png | 96x112 | 27 | pvfx · CC0 |
| ice | a/m2/fx.png | 96x80 | 26 | pvfx · CC0 |
| thunder | a/m2/fx.png | 96x128 | 18 | pvfx · CC0 |
| crit | a/m2/fx.png | 96x80 | 11 | pvfx · CC0 |
| levelup | a/m2/fx.png | 64x96 | 20 | pvfx · CC0 |

## ไอคอน (32x32)

| คีย์ | ไฟล์ | ที่มา |
|---|---|---|
| wep0 | a/i/wep0.png | CraftPix.net Free |
| wep1 | a/i/wep1.png | CraftPix.net Free |
| wep2 | a/i/wep2.png | CraftPix.net Free |
| wep3 | a/i/wep3.png | CraftPix.net Free |
| wep4 | a/i/wep4.png | CraftPix.net Free |
| wep5 | a/i/wep5.png | CraftPix.net Free |
| arm0 | a/i/arm0.png | CraftPix.net Free |
| arm1 | a/i/arm1.png | CraftPix.net Free |
| arm2 | a/i/arm2.png | CraftPix.net Free |
| arm3 | a/i/arm3.png | CraftPix.net Free |
| arm4 | a/i/arm4.png | CraftPix.net Free |
| arm5 | a/i/arm5.png | CraftPix.net Free |
| potion | a/i/potion.png | CraftPix.net Free |
| fruit | a/i/fruit.png | CraftPix.net Free |
| mark | a/i/mark.png | CraftPix.net Free |
| years | a/i/years.png | CraftPix.net Free |
| mon0 | a/i/mon0.png | CraftPix.net Free |
| mon1 | a/i/mon1.png | CraftPix.net Free |
| mon2 | a/i/mon2.png | CraftPix.net Free |
| mon3 | a/i/mon3.png | CraftPix.net Free |
| mon4 | a/i/mon4.png | CraftPix.net Free |
| mon5 | a/i/mon5.png | CraftPix.net Free |

## NPC แยก

| trader | a/c/trader/Idle.png | 768x128 · 6 เฟรม 128x128 | CraftPix.net Free |

## วาดด้วยโค้ด (ไม่ใช่ไฟล์ภาพ ต้องแทนที่)

| ส่วน | ไฟล์โค้ด | หมายเหตุ |
|---|---|---|
| ฉากในอาคาร 13 ฉาก + ของประกอบฉาก | art12.js `SC12` | สี่เหลี่ยมสีเรียบ ขัดกับ Art Direction |
| เครื่องแต่งกาย 17 ชิ้น | gchar.js `gearPaint` | พิกเซลวาดตามกรอบผม/เสื้อ หยาบ |
| ไอคอนวิชา 26 อัน | sys11.js `SKILLS[].ic` | อีโมจิ |
| ประตูมิติ หน้าแรก | art4.js `portal`, create5.js `titleScene` | วาดด้วยโค้ด ยอมรับได้ชั่วคราว |
| UI ทั้งหมด | template.html | CSS ล้วน ไม่มีภาพ |

## ชั้นตัวละครใหม่ (สร้างด้วย art/tools/build_char_layers.py)
| ไฟล์ | ขนาด | สเปก | ที่มา | ใช้ที่ |
|---|---|---|---|---|
| a/art/char/outfit_tunic_m.png | 800x448 | เฟรม 80x64 7 แถว ตรงกับ chars.png · เทา 4 ระดับ ย้อมได้ · เส้นขอบ #13131c · เข็มขัดหนัง หัวทอง | วาดเอง (ต่อยอดจากโครง GandalfHardcore) | char13.js outfit 6 |
| a/art/char/outfit_tunic_f.png | 800x448 | เหมือนกัน | เหมือนกัน | เหมือนกัน |
| a/art/char/wep_staff_m.png | 800x448 | ไม้เท้าไม้ ลูกแก้วม่วง ไม่ย้อมสี · ยึดตำแหน่งมือจากชั้นดาบ | วาดเอง | char13.js `WEP_PNG` mage healer |
| a/art/char/wep_staff_f.png | 800x448 | เหมือนกัน | วาดเอง | เหมือนกัน |
