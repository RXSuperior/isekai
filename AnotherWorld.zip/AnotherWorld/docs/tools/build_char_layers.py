"""สร้างชั้นภาพตัวละครแบบโมดูลาร์ (ชุดทูนิก ไม้เท้า) จากโครงของ GandalfHardcore
ทุกชั้นขนาด 800x448 เฟรม 80x64 7 แถว ตรงกับ chars.png ทุกเฟรม (จุดยึดเดียวกัน)
สีของชุดเป็นเทา 4 ระดับ (ค่า R = 1..4 ระดับ) ให้เกมย้อมสีเอง เส้นขอบ #13131c ไม่ย้อม
รัน: python3 art/tools/build_char_layers.py"""
from PIL import Image
SRC='/home/claude/game3/a/gh/chars.png';OUT='/home/claude/game3/a/art/char/'
FW,FH,ROWN=80,64,[5,8,8,4,4,6,10]
IDX={'mskin':0,'fskin':5,'mshirt':20,'mpants':22,'fcorset':25,'fskirt':27,'msword':30,'fsword':31}
atlas=Image.open(SRC).convert('RGBA')
def layer(i):return atlas.crop((0,448*i,800,448*i+448)).load()
OL=(19,19,28,255);G=[None,(60,60,60,255),(110,110,110,255),(165,165,165,255),(220,220,220,255)]
def lum(c):return .3*c[0]+.59*c[1]+.11*c[2]
def frames():
  for r,n in enumerate(ROWN):
    for c in range(n):yield r,c,c*FW,r*FH
def tunic(sex):
  top=layer(IDX[sex+('shirt' if sex=='m' else 'corset')]);bot=layer(IDX[sex+('pants' if sex=='m' else 'skirt')]);sk=layer(IDX[sex+'skin'])
  im=Image.new('RGBA',(800,448));o=im.load()
  for r,c,X,Y in frames():
    pts=[(x,y) for y in range(FH) for x in range(FW) if top[X+x,Y+y][3]>10]
    if not pts:continue
    ys=[p[1] for p in pts];y0,y1=min(ys),max(ys)
    lying=(max(p[0] for p in pts)-min(p[0] for p in pts))>(y1-y0)+6
    # ตัวเสื้อ: ใช้แสงเงาเดิมของเสื้อ แปลงเป็น 4 ระดับ
    for x,y in pts:
      p=top[X+x,Y+y];o[X+x,Y+y]=OL if lum(p)<40 else G[1 if lum(p)<95 else 2 if lum(p)<150 else 3 if lum(p)<205 else 4]
    if lying:continue
    # ชายเสื้อยาวลงทับสะโพก 6 พิกเซล ตามความกว้างของกางเกงแถวนั้น
    for y in range(y1+1,min(FH,y1+7)):
      xs=[x for x in range(FW) if bot[X+x,Y+y][3]>10 or (sk[X+x,Y+y][3]>10 and top[X+x,Y+y-1][3]>10)]
      if not xs:continue
      a,b=min(xs),max(xs)
      for x in range(a,b+1):o[X+x,Y+y]=OL if x in(a,b) or y==min(FH-1,y1+6) else G[2 if x<a+2 else 1 if x>b-2 else 3]
    # เข็มขัดหนัง + หัวเข็มขัดทอง (ทองไม่ย้อม)
    yb=y1
    xs=[x for x in range(FW) if o[X+x,Y+yb][3]>0]
    if xs:
      for x in range(min(xs)+1,max(xs)):o[X+x,Y+yb]=(58,38,26,255)
      m=(min(xs)+max(xs))//2;o[X+m,Y+yb]=(232,184,64,255);o[X+m+1,Y+yb]=(255,224,128,255)
    # คอเสื้อสีเข้ม
    for x in range(FW):
      if o[X+x,Y+y0][3] and top[X+x,Y+y0][3]>10:o[X+x,Y+y0]=G[1]
  im.save(OUT+f'outfit_tunic_{sex}.png')
def staff(sex):
  sw=layer(IDX[sex+'sword']);top=layer(IDX[sex+('shirt' if sex=='m' else 'corset')])
  im=Image.new('RGBA',(800,448));o=im.load()
  WOOD=[(70,44,28,255),(112,74,44,255),(150,104,62,255)];ORB=[(90,60,170,255),(150,110,240,255),(210,190,255,255),(255,255,255,255)]
  for r,c,X,Y in frames():
    pts=[(x,y) for y in range(FH) for x in range(FW) if sw[X+x,Y+y][3]>10]
    tp=[(x,y) for y in range(FH) for x in range(FW) if top[X+x,Y+y][3]>10]
    if not pts or not tp:continue
    cx=sum(p[0] for p in tp)/len(tp);cy=sum(p[1] for p in tp)/len(tp)
    # มือ = ปลายดาบที่ใกล้ลำตัวที่สุด, ทิศ = ไปยังปลายอีกด้าน
    hand=min(pts,key=lambda p:(p[0]-cx)**2+(p[1]-cy)**2);far=max(pts,key=lambda p:(p[0]-hand[0])**2+(p[1]-hand[1])**2)
    dx,dy=far[0]-hand[0],far[1]-hand[1];L=max(1,(dx*dx+dy*dy)**.5);dx,dy=dx/L,dy/L
    if r in(0,1,2,3,4):dx,dy=0.15 if dx>0 else -0.15,-1  # ท่าปกติถือไม้เท้าตั้ง
    for t in range(-8,23):
      x=round(hand[0]+dx*t);y=round(hand[1]+dy*t)
      for k,(ox,oy) in enumerate(((0,0),(1,0))):
        X2,Y2=x+ox,y+oy
        if 0<=X2<FW and 0<=Y2<FH:o[X+X2,Y+Y2]=WOOD[2 if k==0 else 0] if t%7 else WOOD[1]
    ex,ey=round(hand[0]+dx*24),round(hand[1]+dy*24)
    for yy in range(-2,3):
      for xx in range(-2,3):
        d=abs(xx)+abs(yy)
        if d<=3 and 0<=ex+xx<FW and 0<=ey+yy<FH:o[X+ex+xx,Y+ey+yy]=OL if d==3 else ORB[3 if (xx,yy)==(-1,-1) else 2 if d<=1 else 1]
  im.save(OUT+f'wep_staff_{sex}.png')
for s in 'mf':tunic(s);staff(s)
# ตรวจ: ทุกไฟล์ 800x448 และไม่มีพิกเซลกึ่งโปร่งใส
import glob
for p in glob.glob(OUT+'*.png'):
  im=Image.open(p);assert im.size==(800,448),p
  assert all(a in(0,255) for a in im.getchannel('A').get_flattened_data()),p
  print('ok',p.split('/')[-1],im.size)
