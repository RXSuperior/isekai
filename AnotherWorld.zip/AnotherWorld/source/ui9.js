// ---- v8: ฉากแบบ Way of Xian ----
// ฉากคือที่ที่ตัวละครอยู่จริง วันว่างไปตามจุดต่าง ๆ อยู่ที่ละ 3-12 เดือน เปลี่ยนที่ต้องเดินทางผ่านถนน เหตุการณ์เล่นมีแถบดำบนล่าง แล้วกลับที่เดิม
const SPOTS={school:[['school',5],['home',3],['city',2],['train',1]],hunter:[['guild',4],['gatezone',3],['train',3],['city',2],['home',2]]};
const PATH_SPOT={study:'school',sport:'train',social:'city',work:'city',hunt:'gatezone',guild:'guild',research:'guild',train:'train',dark:'casino'};
let TRAVEL=null,FLASH=0,LASTKEY='';
function pickSpot(){if(P.hp<maxHp(P)*.35)return 'hospital';const b=(SPOTS[P.stage]||SPOTS.school).slice();const pp=PATH_SPOT[P.path];if(pp)b.push([pp,6]);
 const ok=b.filter(([id])=>{const pl=PLACES.find(x=>x.id===id);return !pl||!pl.c||pl.c(P)});return wpick(ok.map(x=>x[0]),ok.map(x=>x[1]))}
function placeName(id){return (PLACES.find(x=>x.id===id)||{}).n||SCENE_CAP[id]||id}
function moveTo(id,why){if(!P||id===P.spot)return;const from=P.spot;P.spot=id;P.place=id;if(from&&speed<=5)TRAVEL={to:id,t:0,why:why||''};}
function sceneNow(){if(!P)return 'city';if(!P.alive||P.scene==='death')return 'death';if(PENDING[0]?.sc)return PENDING[0].sc;if(TRAVEL)return 'road';return P.spot||P.place||'home'}
const _tick9=tick;tick=function(){const was=P&&P.m;_tick9();if(!P||!P.alive||P.m===was)return;
 if(!P.spot){P.spot=P.place||'home';P.spotUntil=P.m+ri(3,12)}
 if(P.place&&P.place!==P.spot&&P.pin>P.m)P.spot=P.place;
 const hurt=P.hp<maxHp(P)*.35;
 if((P.m>=(P.spotUntil||0)&&!(P.pin>P.m))||(hurt&&P.spot!=='hospital')){const n=pickSpot();P.spotUntil=P.m+ri(3,12);if(n!==P.spot)moveTo(n,hurt?'ไปพักรักษาตัว':'')}
 else P.place=P.spot};
const _go9=goPlace;goPlace=function(id){_go9(id);if(P.place===id){P.pin=P.m+12;P.spotUntil=P.m+12;const f=P.spot;P.spot=null;moveTo(id,'ท่านเลือกไปเอง');if(!f)P.spot=id}};
// ถนนระหว่างเดินทาง
MF.bg.road=MF.bg.train||MF.bg.w_green;GROUND.road=['#33402a','#557a34','grass'];SCENE_CAP.road='ระหว่างเดินทาง';
// บ้านตามฐานะครอบครัว
const HOME_KIND=()=>P&&P.homeOwn||({orphan:'church',poor:'hut',slum:'hut',mafia:'manor',chaebol:'manor',guildheir:'manor'}[P&&P.famId]||'home');
Object.defineProperty(SCENE_CAP,'home',{get(){return {church:'โบสถ์เด็กกำพร้า',hut:'กระท่อมเก่า',manor:'คฤหาสน์ของตระกูล',home:'บ้านพัก'}[HOME_KIND()]},configurable:true});
// ภาพเปลี่ยนฉาก แถบดำเหตุการณ์ และฉากเดินทาง
const _ds9=drawScene;drawScene=function(cv,sc,P0,t,night){if(!cv)return;const key=sceneKey(sc);
 if(TRAVEL){TRAVEL.t++;if(TRAVEL.t>16){TRAVEL=null;FLASH=6}}
 _ds9(cv,sc,P0,t,night);const g=cv.getContext('2d');
 if(key!==LASTKEY){if(LASTKEY)FLASH=6;LASTKEY=key}
 if(sc==='road'&&TRAVEL){g.fillStyle='rgba(10,12,24,.75)';g.fillRect(0,H-34,W,34);g.font='600 14px Sarabun, sans-serif';g.fillStyle='#ffe6a8';g.textAlign='center';g.fillText(`กำลังเดินทางไป ${placeName(TRAVEL.to)}${TRAVEL.why?' · '+TRAVEL.why:''}`,W/2,H-12);R(g,40,H-6,(W-80)*Math.min(1,TRAVEL.t/16),3,'#ffd36b')}
 if(P0&&PENDING.length&&!minimized){R(g,0,0,W,22,'#000');R(g,0,H-22,W,22,'#000')}
 if(FLASH>0){g.fillStyle=`rgba(255,255,255,${FLASH/9})`;g.fillRect(0,0,W,H);FLASH--}};
// จุดต่าง ๆ ในเมือง (แบบ WoX: ฉาก · เมือง)
const TOWN='เมืองหลวงอัลเทีย';
const SPOT_SC={forest:'w_forest'};
const SPOT_N={market:'ตลาด',field:'ทุ่งนานอกกำแพง',lake:'ริมทะเลสาบ',forest:'ป่าข้างเมือง',tavern:'โรงเตี๊ยม',shrine:'วิหารแห่งทวยเทพ',city:'จัตุรัสกลางเมือง',home:null,school:'สถาบันเวทหลวง',guild:'กิลด์นักผจญภัย',gatezone:'ปากทางดันเจี้ยน',train:'ลานฝึก',hospital:'วิหารรักษา',casino:'บ่อนใต้ดิน'};
[['market','ตลาด','ซื้อขาย ข่าวลือ และคนแปลกหน้า'],['field','ทุ่งนานอกกำแพง','เงียบสงบ เหมาะฝึกฝนและพักใจ'],['lake','ริมทะเลสาบ','ที่นัดพบของคนหนุ่มสาวและคนเหงา'],['forest','ป่าข้างเมือง','สมุนไพรและสัตว์อสูรตัวเล็ก'],['tavern','โรงเตี๊ยม','นักผจญภัยพักแรม ข่าวลือจากเมืองอื่น'],['shrine','วิหารแห่งทวยเทพ','ขอพร เหล่าเทพจับตาท่านใกล้ขึ้น']].forEach(([id,n,d])=>{if(!PLACES.find(x=>x.id===id))PLACES.push({id,n,d})});
SPOTS.school.push(['market',2],['field',1],['lake',1],['shrine',1]);SPOTS.hunter.push(['tavern',2],['forest',2],['market',1],['shrine',1],['lake',1]);
const _sk9=sceneKey;sceneKey=function(sc){return _sk9(SPOT_SC[sc]||sc)};
function capOf(sc){const base=SCENE_CAP[sc]||SCENE_CAP[sceneKey(sc)]||'';const n=SPOT_N[sc]===null?base:(SPOT_N[sc]||base);return ['road','death','sky','fire','gatered'].includes(sc)||!SPOT_N.hasOwnProperty(sc)?base:`${n} · ${TOWN}`}
function chapter(){const a=ageY(P);if(P.flags.demonSlain)return 'ผู้ปราบจอมมาร';if(a>=60)return 'บั้นปลายชีวิต';if(P.stage==='school')return P.flags.earth?'ผู้มาจากต่างโลก':'วัยเรียน';if(a<25)return 'นักผจญภัยหน้าใหม่';if(a<40)return 'ช่วงรุ่งโรจน์';return 'วัยกลางคน'}
