// ---- v7 ต่างโลก: ฉากหลังแฟนตาซี (GandalfHardcore) ----
const GHB=(t,castle)=>['5',...(castle?['castle']:[]),'4','3','2','1'].map(n=>`a/gh/c_${t}${n}.png`);
Object.assign(MF.bg,{city:GHB('n',1),city_w:GHB('w',1),city_a:GHB('a',1),gate:GHB('a'),train:GHB('n'),w_ruin:GHB('a',1),fwinter:GHB('w')});
Object.values(MF.bg).flat().forEach(s=>img(s));
Object.assign(GROUND,{city:['#3a3226','#6a5a3a','tile'],gate:['#4a3a20','#8a6a30','leaf'],train:['#33402a','#557a34','grass'],w_ruin:['#3a3020','#6a5030','leaf']});
const _dl6=drawLayers;drawLayers=function(g,key,t,move){let k=key;if(key==='city'&&P){const s=SEASON(P.m);k=s==='winter'?'city_w':s==='autumn'?'city_a':'city'}
 _dl6(g,k,t,move)};
SCENE_CAP.sky='วิหารแห่งทวยเทพ';SCENE_CAP.city='เมืองหลวงอัลเทีย';SCENE_CAP.gate='ปากทางดันเจี้ยน';SCENE_CAP.gatezone='ปากทางดันเจี้ยน';SCENE_CAP.school='ห้องเรียนสถาบันเวท';
// สไปรต์มอนสเตอร์แบบใหม่ (เฟรมไม่จัตุรัส หลายแถวในไฟล์เดียว)
const _spr6=spr;spr=function(g,s,f,x,y,sc=2,flip=false,alpha=1,tint=0){if(!s)return;if(!s.w)return _spr6(g,s,f,x,y,sc,flip,alpha,tint);
 const im=IMG[s.src]||img(s.src);if(!im||!im.complete)return;const fr=((f%s.n)+s.n)%s.n,k=sc*(s.k||1),fl=s.left?!flip:flip;
 g.save();g.globalAlpha=alpha;g.imageSmoothingEnabled=false;g.translate(Math.round(x),Math.round(y));if(fl)g.scale(-1,1);g.drawImage(im,fr*s.w,s.y||0,s.w,s.h,-s.w*k/2+(s.dx||0)*k,-(s.h-(s.oy||0))*k,s.w*k,s.h*k);g.restore()};
MON_N.rat='หนูยักษ์ดันเจี้ยน';MON_N.frost='ผู้พิทักษ์น้ำแข็ง';MON_N.necro='นักบวชวิญญาณดำ';MON_N.demonlord='จอมมาร';
MON_BY_RANK[0].push('rat');MON_BY_RANK[1].push('rat');MON_BY_RANK[4].push('necro');MON_BY_RANK[5].push('frost','necro');
// มอนสเตอร์ชุด Topdown (หันหน้าเข้าจอ)
Object.assign(MON_N,{td0:'มารเกล็ดเงิน',td1:'ปีศาจเขาแพะ',td2:'โอเกอร์หนองบึง',td3:'ซอมบี้หัวไฟ',td4:'อสูรเขาทอง',td5:'นกฮูกอัคคี',td6:'โจรเผ่าจิ้งจอก',td7:'มนุษย์มังกรฟ้า',td8:'ไก่ชนนักรบ',td9:'ปีศาจแดง',td10:'นักรบกระดูกแดง'});
[['td3','td8'],['td5','td6'],['td2','td0'],['td7','td1'],['td4','td10'],['td9']].forEach((a,i)=>MON_BY_RANK[i].push(...a));
