// =============== ตัวสร้างตัวละครพิกเซล ===============
// ตาราง 40x64 เท้าอยู่แถวล่างสุด วาดเป็น "วัสดุ" แล้วลงเงาและเส้นขอบอัตโนมัติ
const CW=40,CH=64;
const HAIR_COLORS=[['ดำ','#1c1b26'],['ดำอมน้ำเงิน','#1d2340'],['น้ำตาลเข้ม','#3e2a20'],['น้ำตาล','#6b4428'],['น้ำตาลแดง','#7a3424'],['บลอนด์','#d9b45a'],['บลอนด์อ่อน','#ece0a6'],['เงิน','#c8ccd8'],['ขาว','#eef0f6'],['เทา','#7a7f8c'],
 ['แดง','#b8282e'],['ส้ม','#d8702a'],['ชมพู','#e88aaa'],['ม่วง','#7a4ab8'],['ม่วงเข้ม','#4a2a6e'],['น้ำเงิน','#2e56b8'],['ฟ้า','#6ab8e8'],['เขียว','#2e8a4e'],['เขียวมิ้นต์','#6ad0b0'],['ทอง','#e8b830']];
const EYE_COLORS=[['ดำ','#2a2228'],['น้ำตาล','#6b3e22'],['น้ำตาลอ่อน','#a86a34'],['อำพัน','#d89a2a'],['ทอง','#f0c840'],['แดง','#c42a34'],['แดงเลือด','#7a1020'],['ชมพู','#e86aa0'],['ม่วง','#8a4ad8'],['ม่วงอ่อน','#b89af0'],
 ['น้ำเงิน','#2a5ad8'],['ฟ้า','#4ab0f0'],['ฟ้าน้ำแข็ง','#9ae0ff'],['เขียวมรกต','#1a9a5a'],['เขียวอ่อน','#7ad06a'],['เทา','#7a8090'],['เงิน','#c0c8d8'],['ส้ม','#f07a2a'],['ขาว','#eef0f6'],['ดำสนิท','#0a0a10']];
const SKINS=[['ขาวอมชมพู','#ffe2d4'],['ขาวเหลือง','#f8d8b4'],['ผิวสองสี','#e8b88a'],['แทน','#c8905e'],['น้ำผึ้ง','#a8703e'],['คล้ำ','#7a4a2a'],['เข้ม','#553220'],['ซีด','#f0e4e0']];
const OUT_COLORS=[['กรมท่า','#2a3a7a'],['น้ำเงิน','#3a5ad0'],['ม่วง','#5a3a9a'],['ดำ','#2a2a32'],['เทาเข้ม','#4a4e5a'],['ขาว','#e4e6ee'],['แดง','#a82a34'],['แดงเลือดหมู','#6a1a24'],
 ['เขียว','#2e6a3e'],['เขียวทหาร','#5a6a3a'],['น้ำตาล','#6a4a2e'],['ครีม','#d8c8a0'],['ส้ม','#d0702a'],['ชมพู','#d07aa0'],['ฟ้า','#4a9ad0'],['ทอง','#c8a030']];
const FACES=[];[['กลม',13,13,'r'],['กลมเล็ก',12,12,'r'],['กลมยาว',13,14,'r'],['เรียว V',12,14,'v'],['เรียว V กว้าง',13,14,'v'],['คางแหลม',12,15,'v'],['เหลี่ยม',13,13,'s'],['เหลี่ยมกว้าง',14,13,'s'],['เหลี่ยมยาว',13,15,'s'],['ไข่',12,14,'o'],['ไข่กว้าง',13,14,'o'],['ทรงหัวใจ',13,14,'h'],['ทรงหัวใจเล็ก',12,13,'h'],['ยาวเรียว',11,15,'o'],['กว้างใหญ่',14,14,'r']].forEach(([n,w,h,j])=>FACES.push({n,w,h,j}));
const EYES=[ // o=ขอบ/ขนตา i=ม่านตา d=รูม่านตา h=ประกาย w=ตาขาว
 {n:'กลมโต',p:['oooo','hiiw','iddw','.ii.']},{n:'คม',p:['.ooo','oiiw','.dd.']},{n:'ง่วง',p:['....','oooo','iidw']},{n:'เรียวเท่',p:['oooo','.idw']},
 {n:'ตาแมว',p:['ooo.','hidw','.ii.']},{n:'ตาตก',p:['.ooo','hiio','idw.']},{n:'ตาโต',p:['oooo','hiiw','iiiw','iddw','.oo.']},{n:'มุ่งมั่น',p:['ooo.','oiiw','.ddo']},
 {n:'ยิ้มหยี',p:['....','.oo.','o..o']},{n:'ประกายดาว',p:['oooo','iihw','ihiw','.ii.']}];
const MOUTHS=[{n:'เรียบเฉย',p:['mmm']},{n:'ยิ้ม',p:['m..m','.mm.']},{n:'ยิ้มกว้าง',p:['mmmm','.tt.']},{n:'มุมปาก',p:['...m','mmm.']},{n:'หน้าบึ้ง',p:['.mm.','m..m']},
 {n:'อ้าปาก',p:['.mm.','mrrm','.mm.']},{n:'ปากแมว',p:['m.m.m','.m.m.']},{n:'จุ๊บ',p:['.r.','rrr']},{n:'แลบลิ้น',p:['mmm','.r.']},{n:'ยิ้มฟัน',p:['mttm']}];
const NOSES=[{n:'ไม่มี',p:[]},{n:'จุด',p:['n']},{n:'เส้นสั้น',p:['n','n']},{n:'ตัวแอล',p:['n.','nn']},{n:'เงาข้าง',p:['.n','n.']},{n:'กระดุม',p:['nn']},{n:'โด่ง',p:['n','n','nn']}];
const HAIRS=['สั้นยุ่ง','ชี้ฟู','ปัดข้าง','รองทรง','หน้าม้าตรง','บ็อบ','ยาวตรง','ยาวสลวย','หางม้า','แกละสองข้าง','มวยผม','หางหมาป่า','หยักศก','เสยหลัง','สกินเฮด','ผมปิดตา','ไว้ยาวประบ่า','ถักเปีย','โมฮอว์ก','มวยครึ่งหัว'];
const OUTFITS=['แจ็กเก็ตเปิดหน้า','เสื้อยืดยีนส์','ฮู้ดดี้','โค้ทยาว','ชุดนักเรียนชาย','ชุดนักเรียนหญิง','สูท','เสื้อกล้าม','เกราะเบา','เกราะหนัก','เสื้อคลุมนักเวท','ชุดนินจา','ชุดนักบวช','ชุดทหาร','แจ็กเก็ตหนัง','กิโมโน','เดรส','เสื้อกั๊ก','ชุดไซเบอร์','ผ้าคลุมพเนจร'];
const LOOK_OPTS={face:FACES.length,hair:HAIRS.length,hairC:HAIR_COLORS.length,skin:SKINS.length,eyes:EYES.length,eyeC:EYE_COLORS.length,nose:NOSES.length,mouth:MOUTHS.length,outfit:OUTFITS.length,outC:OUT_COLORS.length};
function randomLook(sex){const r=n=>Math.floor(Math.random()*n);const L={sex:sex||(Math.random()<.5?'m':'f')};for(const k in LOOK_OPTS)L[k]=r(LOOK_OPTS[k]);
 if(L.sex==='m'&&[5,15,16].includes(L.outfit))L.outfit=r(5);return L}
// ---- สี ----
function hx(c){const n=parseInt(c.slice(1),16);return [n>>16,n>>8&255,n&255]}
function mix(c,t,a){const A=hx(c),B=hx(t);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*a).toString(16).padStart(2,'0')).join('')}
function ramp(c){return {ol:mix(c,'#14101e',.72),dk:mix(c,'#1a1430',.32),md:c,lt:mix(c,'#ffffff',.28)}}
// ---- วาดลงตารางวัสดุ ----
function Grid(){this.m=new Array(CW*CH).fill(null)}
Grid.prototype.set=function(x,y,k){x|=0;y|=0;if(x>=0&&y>=0&&x<CW&&y<CH)this.m[y*CW+x]=k};
Grid.prototype.get=function(x,y){return x<0||y<0||x>=CW||y>=CH?null:this.m[y*CW+x]};
Grid.prototype.rect=function(x,y,w,h,k){for(let j=0;j<h;j++)for(let i=0;i<w;i++)this.set(x+i,y+j,k)};
Grid.prototype.ell=function(cx,cy,rx,ry,k,cut){for(let y=Math.floor(cy-ry);y<=cy+ry;y++)for(let x=Math.floor(cx-rx);x<=cx+rx;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1&&(!cut||cut(x,y)))this.set(x,y,k)}};
Grid.prototype.poly=function(pts,k){let x0=99,x1=-1,y0=99,y1=-1;pts.forEach(([x,y])=>{x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)});
 for(let y=Math.floor(y0);y<=y1;y++)for(let x=Math.floor(x0);x<=x1;x++){let ins=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const [xi,yi]=pts[i],[xj,yj]=pts[j];if(((yi>y+.5)!==(yj>y+.5))&&(x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi))ins=!ins}if(ins)this.set(x,y,k)}};
Grid.prototype.line=function(x0,y0,x1,y1,k){const n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0))+1;for(let i=0;i<n;i++){const t=n>1?i/(n-1):0;this.set(Math.round(x0+(x1-x0)*t),Math.round(y0+(y1-y0)*t),k)}};
// ---- ร่างกาย ----
// pose: {name:'idle'|'walk'|'attack'|'hurt', f}
function buildChar(L,pose){
 const g=new Grid(),det=[];const P=pose||{name:'idle',f:0};const f=P.f||0;
 const fem=L.sex==='f',F=FACES[L.face]||FACES[0],cx=20;
 let bob=0;if(P.name==='idle')bob=f%2;if(P.name==='walk')bob=f%2;if(P.name==='hurt')bob=1;
 const fw=F.w+3,fh=F.h+3,top=3+bob,hy=top+1,fx=cx-fw/2;
 const ty=hy+fh+1,hip=ty+15;
 // ขา
 let lx=0,rx=0,ll=0,rl=0;if(P.name==='walk'){const s=[[-2,2,0,1],[0,0,1,0],[2,-2,1,0],[0,0,0,1]][f%4];lx=s[0];rx=s[1];ll=s[2];rl=s[3]}
 if(P.name==='attack'){lx=-2;rx=2}
 const LW=fem?4:5,LX=fem?16:15,RX=21;
 hairBack(g,L.hair,cx,top,fw,fh);
 const legs=(k,from=hip,to=60)=>{g.rect(LX+lx,from,LW,to-from-ll,k);g.rect(RX+rx,from,LW,to-from-rl,k)};
 const shoes=(k)=>{g.rect(LX-1+lx,60-ll,LW+2,4,k);g.rect(RX+rx,60-rl,LW+2,4,k)};
 const o=L.outfit;const shW=fem?14:16,shX=cx-shW/2;
 const AW=fem?3:4,AL=hip-ty;
 const armL=()=>({x:shX-AW,y:ty+1}),armR=()=>({x:shX+shW,y:ty+1});
 const torso=(k)=>{if(fem){g.poly([[shX,ty],[shX+shW,ty],[shX+shW-2,ty+9],[shX+shW-1,hip],[shX+1,hip],[shX+2,ty+9]],k)}else g.rect(shX,ty,shW,hip-ty,k);g.rect(shX+1,ty-1,shW-2,1,k)};
 const arm=(side,k,len=AL)=>{const a=side<0?armL():armR();
  if(side>0&&P.name==='attack'){const ext=[0,6,9][f%3];g.rect(a.x,a.y,AW,6,k);g.rect(a.x,a.y+4,AW+ext,AW,k)}
  else if(P.name==='walk'){const sw=(side<0?[1,0,-1,0]:[-1,0,1,0])[f%4];g.rect(a.x,a.y,AW,len-4,k);g.rect(a.x+sw,a.y+len-4,AW,4,k)}
  else if(P.name==='hurt'){g.rect(a.x+(side<0?-1:1),a.y,AW,len-2,k)}
  else g.rect(a.x,a.y,AW,len,k)};
 const hand=(side)=>{const a=side<0?armL():armR();
  if(side>0&&P.name==='attack'){const ext=[0,6,9][f%3];g.rect(a.x+AW+ext-1,a.y+4,3,AW,'skin');return}
  let x=a.x,y=a.y+AL;if(P.name==='hurt'){y-=2;x+=side<0?-1:1}if(P.name==='walk')x+=(side<0?[1,0,-1,0]:[-1,0,1,0])[f%4];g.rect(x,y,AW,3,'skin')};
 const skirt=(k,len=10)=>{g.poly([[shX+1,hip-3],[shX+shW-1,hip-3],[shX+shW+2,hip+len],[shX-2,hip+len]],k)};
 const top1='oa',sec='ob',pants='pn';
 const base=(legK,shoeK)=>{legs(legK);shoes(shoeK)};
 switch(o){
  case 0:base(pants,'sh');torso('sb');g.rect(shX,ty,5,hip-ty,top1);g.rect(shX+shW-5,ty,5,hip-ty,top1);g.poly([[shX+5,ty],[shX+7,ty],[shX+5,ty+5]],sec);g.poly([[shX+shW-7,ty],[shX+shW-5,ty],[shX+shW-5,ty+5]],sec);arm(-1,top1);arm(1,top1);break;
  case 1:base('jean','sh');torso(top1);arm(-1,top1,6);arm(1,top1,6);{const a=armL(),b=armR();g.rect(a.x,a.y+6,AW,AL-6,'skin');g.rect(b.x,b.y+6,AW,AL-6,'skin')}break;
  case 2:base(pants,'sh');torso(top1);arm(-1,top1);arm(1,top1);g.rect(shX+3,ty+9,shW-6,4,sec);g.line(cx-2,ty+1,cx-2,ty+6,'wh');g.line(cx+1,ty+1,cx+1,ty+6,'wh');g.rect(shX-1,ty-2,shW+2,3,top1);break;
  case 3:base(pants,'sh');torso(top1);g.rect(shX-1,hip-1,shW+2,14,top1);g.rect(cx-1,ty,2,hip-ty+13,'sb');arm(-1,top1);arm(1,top1);g.rect(shX,ty,shW,2,sec);g.rect(shX,hip-3,shW,2,'blt');break;
  case 4:base('pn2','sh');torso('wh');g.rect(cx-1,ty+1,2,8,top1);arm(-1,'wh');arm(1,'wh');g.rect(shX,hip-2,shW,2,'blt');break;
  case 5:legs('skin');g.rect(LX+lx,hip+11,LW,49-hip-ll,'sock');g.rect(RX+rx,hip+11,LW,49-hip-rl,'sock');shoes('sh');torso('wh');skirt(top1);g.poly([[cx-3,ty],[cx+3,ty],[cx,ty+4]],'rd');arm(-1,'wh');arm(1,'wh');g.rect(shX,ty,shW,2,top1);break;
  case 6:base('pn2','sh');torso(top1);g.poly([[cx-3,ty],[cx+3,ty],[cx,ty+9]],'wh');g.rect(cx-1,ty+1,2,8,'rd');arm(-1,top1);arm(1,top1);break;
  case 7:base(pants,'sh');torso(top1);g.rect(shX,ty,2,4,'skin');g.rect(shX+shW-2,ty,2,4,'skin');{const a=armL(),b=armR();g.rect(a.x,a.y,AW,AL,'skin');g.rect(b.x,b.y,AW,AL,'skin')}g.rect(LX+lx,hip+9,LW,51-hip-ll,'skin');g.rect(RX+rx,hip+9,LW,51-hip-rl,'skin');break;
  case 8:base(pants,'sh');torso(sec);g.rect(shX+2,ty+2,shW-4,9,'mt');g.rect(shX-3,ty-1,6,5,'mt');g.rect(shX+shW-3,ty-1,6,5,'mt');arm(-1,sec);arm(1,sec);g.rect(shX,hip-3,shW,3,'blt');break;
  case 9:base('mt','mt');torso('mt');g.rect(shX+2,ty+3,shW-4,9,top1);g.rect(shX-4,ty-2,7,7,'mt');g.rect(shX+shW-3,ty-2,7,7,'mt');arm(-1,'mt');arm(1,'mt');g.rect(shX,hip-3,shW,3,top1);break;
  case 10:base(pants,'sh');torso(top1);g.poly([[shX-1,hip-2],[shX+shW+1,hip-2],[shX+shW+3,62],[shX-3,62]],top1);g.rect(cx-1,ty,2,62-ty,sec);arm(-1,top1);arm(1,top1);g.rect(shX,hip-3,shW,2,'gd');g.rect(shX-2,ty-1,shW+4,3,sec);break;
  case 11:base('dk','dk');torso('dk');g.rect(shX,ty+3,shW,2,top1);g.rect(cx-6,ty-3,12,4,top1);g.rect(cx+6,ty-2,4,12,top1);arm(-1,'dk');arm(1,'dk');g.rect(shX,hip-3,shW,2,top1);break;
  case 12:base('wh','sh');torso('wh');g.poly([[shX-1,hip-2],[shX+shW+1,hip-2],[shX+shW+2,61],[shX-2,61]],'wh');g.rect(cx-1,ty+2,2,10,'gd');g.rect(cx-3,ty+4,6,2,'gd');arm(-1,'wh');arm(1,'wh');g.rect(shX,ty,shW,2,top1);break;
  case 13:base(top1,'sh');torso(top1);g.rect(shX+2,ty+3,4,3,sec);g.rect(shX+shW-6,ty+3,4,3,sec);g.rect(shX,hip-3,shW,2,'blt');arm(-1,top1);arm(1,top1);g.rect(shX-1,ty,shW+2,2,sec);break;
  case 14:base('jean','sh');torso('dk');g.rect(shX,ty,6,hip-ty,'lth');g.rect(shX+shW-6,ty,6,hip-ty,'lth');arm(-1,'lth');arm(1,'lth');g.rect(shX-1,ty-1,shW+2,3,'lth');break;
  case 15:base(top1,'sh');torso(top1);g.poly([[shX,ty],[cx+3,ty],[shX+3,ty+10]],sec);g.rect(shX,hip-4,shW,3,'gd');g.poly([[shX-1,hip-2],[shX+shW+1,hip-2],[shX+shW+1,59],[shX-1,59]],top1);arm(-1,top1);arm(1,top1);{const a=armL(),b=armR();g.rect(a.x-1,a.y+8,AW+2,6,top1);g.rect(b.x-1,b.y+8,AW+2,6,top1)}break;
  case 16:legs('skin');shoes('sh');torso(top1);skirt(top1,15);g.rect(shX,ty,2,3,'skin');g.rect(shX+shW-2,ty,2,3,'skin');{const a=armL(),b=armR();g.rect(a.x,a.y,AW,AL,'skin');g.rect(b.x,b.y,AW,AL,'skin')}g.rect(shX,hip-3,shW,2,sec);break;
  case 17:base(pants,'sh');torso('wh');g.rect(shX,ty,shW,hip-ty-2,top1);g.rect(cx-1,ty,2,hip-ty-2,'wh');g.rect(cx-1,ty+1,2,6,'rd');arm(-1,'wh');arm(1,'wh');break;
  case 18:base('dk','sh');torso('dk');g.line(shX+1,ty+2,shX+1,hip-2,'neon');g.line(shX+shW-2,ty+2,shX+shW-2,hip-2,'neon');g.rect(shX,ty+8,shW,1,'neon');arm(-1,'dk');arm(1,'dk');g.line(LX+1+lx,hip+4,LX+1+lx,hip+18,'neon');g.line(RX+LW-2+rx,hip+4,RX+LW-2+rx,hip+18,'neon');break;
  case 19:base(pants,'sh');torso(sec);g.poly([[shX-3,ty-1],[shX+shW+3,ty-1],[shX+shW+5,hip+14],[shX-5,hip+14]],top1);arm(-1,top1,10);arm(1,top1,10);g.rect(cx-7,ty-3,14,4,top1);break;
 }
 hand(-1);hand(1);
 g.rect(cx-2,ty-3,4,4,'skin');
 // หัว
 if(F.j==='r')g.ell(cx,hy+fh/2,fw/2,fh/2,'skin');
 else if(F.j==='o')g.ell(cx,hy+fh/2,fw/2,fh/2+.5,'skin');
 else if(F.j==='s'){g.rect(fx,hy+1,fw,fh-3,'skin');g.rect(fx+1,hy,fw-2,1,'skin');g.rect(fx+1,hy+fh-2,fw-2,2,'skin')}
 else if(F.j==='v'){g.ell(cx,hy+fh*.42,fw/2,fh*.42+1,'skin');g.poly([[fx,hy+fh*.45],[fx+fw,hy+fh*.45],[cx+2,hy+fh],[cx-2,hy+fh]],'skin')}
 else if(F.j==='h'){g.ell(cx,hy+fh*.42,fw/2+.5,fh*.42+.5,'skin');g.poly([[fx,hy+fh*.5],[fx+fw,hy+fh*.5],[cx+2.5,hy+fh],[cx-2.5,hy+fh]],'skin')}
 g.rect(Math.floor(fx)-1,hy+Math.round(fh*.45),1,3,'skin');g.rect(Math.ceil(fx+fw),hy+Math.round(fh*.45),1,3,'skin');
 // ใบหน้า
 const ey=hy+Math.round(fh*.47),eye=EYES[L.eyes]||EYES[0],ew=eye.p[0].length;
 eye.p.forEach((row,j)=>{for(let i=0;i<row.length;i++){const ch=row[i];if(ch==='.')continue;det.push([cx+1+i,ey+j,ch]);det.push([cx-2-i,ey+j,ch==='h'?'h':ch])}});
 for(let i=0;i<ew;i++){det.push([cx+1+i,ey-2-(i===ew-1&&fem?0:0),'b']);det.push([cx-2-i,ey-2,'b'])}
 const nose=NOSES[L.nose]||NOSES[0],ny=ey+eye.p.length;nose.p.forEach((row,j)=>{for(let i=0;i<row.length;i++)if(row[i]==='n')det.push([cx-1+i,ny+j,'n'])});
 const mo=MOUTHS[P.name==='hurt'?5:L.mouth]||MOUTHS[0],my=Math.min(hy+fh-3,ny+Math.max(2,nose.p.length+1)),mw=mo.p[0].length;
 mo.p.forEach((row,j)=>{for(let i=0;i<row.length;i++){const ch=row[i];if(ch!=='.')det.push([cx-Math.ceil(mw/2)+i,my+j,ch])}});
 if(fem){det.push([cx-6,ey+3,'bl']);det.push([cx-5,ey+3,'bl']);det.push([cx+4,ey+3,'bl']);det.push([cx+5,ey+3,'bl'])}
 hairFront(g,L.hair,cx,top,fw,fh,det);
 if(P.weapon)weapon(g,P.weapon,P.name==='attack'?f%3:-1,armR(),AW,AL);
 return {g,det,hy,fh};
}
function hairBack(g,h,cx,top,fw,fh){const k='hr',x0=cx-fw/2-2,w=fw+4,hy=top+1;
 const long=(y)=>{g.rect(x0-1,hy+4,w+2,y-hy-4,k);g.ell(cx,hy+5,fw/2+2.5,7,k)};
 switch(h){case 6:long(38);break;case 7:long(44);g.rect(x0-1,36,w+2,8,k);break;case 8:g.poly([[cx+5,hy+3],[cx+9,hy+6],[cx+11,34],[cx+7,36]],k);break;
  case 9:g.ell(cx-fw/2-3,hy+16,3,9,k);g.ell(cx+fw/2+3,hy+16,3,9,k);break;case 10:g.ell(cx,hy-2,4,3,k);break;case 11:long(30);g.poly([[x0,26],[x0+w,26],[x0+w-2,32],[cx,29],[x0+2,32]],k);break;
  case 12:long(30);g.ell(cx,hy+8,fw/2+4,9,k);break;case 16:long(32);break;case 17:long(28);for(let y=28;y<44;y+=3)g.ell(cx+6,y,2,2,k);break;case 19:g.ell(cx,hy-1,3,3,k);long(30);break;case 5:long(25);break;}
}
function hairFront(g,h,cx,top,fw,fh,det){const k='hr',x0=cx-fw/2-1,x1=cx+fw/2+1,hy=top+1,fore=hy+4;
 const cap=(extra=0,tuft=0)=>{g.ell(cx,hy+4,fw/2+2+extra,6.5+extra,k,(x,y)=>y<=fore+1);if(tuft)for(let i=-fw/2;i<=fw/2;i+=3){const ty0=hy-2-extra+Math.abs(i)*.35;g.set(cx+i,ty0,k);g.set(cx+i+1,ty0-1,k)}
  const jag=(x,len)=>{for(let j=0;j<len;j++)g.set(cx+x,fore+j,k)};g.rect(cx-fw/2,fore,fw,1,k)};
 const side=(len)=>{g.rect(x0-1,hy+2,3,len+2,k);g.rect(x1-2,hy+2,3,len+2,k)};
 const fringe=(cols)=>cols.forEach(([x,l])=>g.rect(cx+x,fore,1,l,k));
 switch(h){
  case 0:cap(.5,1);fringe([[-6,3],[-5,4],[-4,2],[-3,4],[-1,3],[0,5],[1,3],[3,4],[4,2],[5,3]]);side(5);g.set(cx-2,hy-3,k);g.set(cx+3,hy-3,k);break;
  case 1:cap(1);[[-6,-3],[-3,-5],[0,-6],[3,-5],[6,-3]].forEach(([x,y])=>g.poly([[cx+x-2,hy+1],[cx+x+2,hy+1],[cx+x+1,hy+y]],k));fringe([[-5,4],[-4,5],[-2,3],[-1,5],[1,4],[2,6],[4,3],[5,4]]);side(4);break;
  case 2:cap(.5);g.poly([[x0-1,fore-1],[cx+6,fore-1],[cx-2,fore+6],[x0,fore+7]],k);g.poly([[cx+2,fore-1],[x1+1,fore-1],[x1,fore+3]],k);side(5);break;
  case 3:cap(0,1);fringe([[-6,2],[-4,3],[-2,2],[0,3],[2,2],[4,3],[6,2]]);side(6);break;
  case 4:cap();g.rect(x0,fore,fw+2,3,k);for(let i=-6;i<=6;i+=2)g.set(cx+i,fore+3,k);side(7);break;
  case 5:cap(.5);g.rect(x0,fore,fw+2,3,k);g.rect(x0-1,hy+2,3,fh+1,k);g.rect(x1-2,hy+2,3,fh+1,k);break;
  case 6:case 7:cap(.5);g.rect(x0,fore,6,3,k);g.rect(cx+1,fore,6,2,k);g.rect(x0-1,hy+2,2,fh+4,k);g.rect(x1-1,hy+2,2,fh+4,k);break;
  case 8:cap();fringe([[-5,3],[-4,4],[-3,2],[-1,3],[0,4],[2,3],[3,2],[4,3]]);side(5);g.rect(cx+fw/2,hy+2,2,2,'rd');break;
  case 9:cap();g.rect(x0,fore,fw+2,2,k);side(4);g.rect(x0-1,hy+6,2,2,'rd');g.rect(x1-1,hy+6,2,2,'rd');break;
  case 10:cap(.5);fringe([[-5,3],[-3,2],[2,2],[4,3]]);side(6);break;
  case 11:cap(1,1);fringe([[-6,5],[-5,3],[-3,5],[-1,4],[1,6],[3,4],[5,5],[6,3]]);side(8);break;
  case 12:cap(1.5,1);for(let i=-7;i<=7;i+=2)g.ell(cx+i,fore,1.5,1.5,k);side(8);break;
  case 13:g.ell(cx,hy+3,fw/2+2,7,k,(x,y)=>y<=fore);g.poly([[cx-fw/2-1,hy+2],[cx+fw/2+3,hy-3],[cx+fw/2+2,hy+3]],k);break;
  case 14:g.ell(cx,hy+3,fw/2+.5,4.5,'hrs',(x,y)=>y<=fore);break;
  case 15:cap();g.poly([[x0-1,fore-1],[cx+3,fore-1],[cx+3,fore+8],[x0,fore+7]],k);side(7);break;
  case 16:cap(.5,1);fringe([[-5,3],[-4,2],[-2,3],[0,2],[2,3],[4,2],[5,3]]);side(10);break;
  case 17:cap();g.rect(x0,fore,fw+2,2,k);side(5);break;
  case 18:g.ell(cx,hy+3,fw/2+.5,4.5,'hrs',(x,y)=>y<=fore);g.poly([[cx-2,hy+5],[cx+2,hy+5],[cx+1,hy-6],[cx-1,hy-6]],k);break;
  case 19:cap(0,1);fringe([[-5,4],[-4,3],[-2,2],[2,2],[4,3],[5,4]]);side(6);break;
 }
}
function weapon(g,w,f,a,AW,AL){
 const hx=f<0?a.x+1:a.x+AW+[0,6,9][f]-1,hy=f<0?a.y+AL+1:a.y+5;
 switch(w){
  case 'sword':if(f<0){g.line(hx+2,hy,hx+7,hy+9,'bl1');g.line(hx+3,hy,hx+8,hy+9,'bl1');g.rect(hx,hy-1,4,2,'gd')}else if(f===0){g.line(hx+1,hy,hx-2,hy-15,'bl1');g.line(hx+2,hy,hx-1,hy-15,'bl1')}else{g.line(hx,hy,hx+14,hy-(f===1?8:1),'bl1');g.line(hx,hy+1,hx+14,hy+1-(f===1?8:1),'bl1');g.rect(hx-1,hy-1,2,4,'gd')}break;
  case 'tank':{const sx=f<0?a.x-2:hx-1,sy=f<0?a.y+5:hy-7;g.rect(sx,sy,7,14,'mt');g.rect(sx+2,sy+2,3,10,'oa')}break;
  case 'bow':{const bx=f<0?hx+3:hx+1;g.line(bx,hy-10,bx+3,hy-5,'wd');g.line(bx+3,hy-5,bx+3,hy+5,'wd');g.line(bx+3,hy+5,bx,hy+10,'wd');g.line(bx,hy-10,bx,hy+10,'wh')}break;
  case 'mage':g.line(hx+2,hy-18,hx+2,hy+10,'wd');g.ell(hx+2,hy-19,2.5,2.5,'orb');break;
  case 'assassin':g.line(hx+1,hy,hx+(f<0?4:8),hy+(f<0?7:-1),'bl1');break;
  case 'healer':g.rect(hx,hy-5,6,7,'bk');g.rect(hx+2,hy-4,2,5,'gd');break;
 }
}
// ---- ลงสี ----
function matColors(L){
 const hair=HAIR_COLORS[L.hairC]?.[1]||'#222',skin=SKINS[L.skin]?.[1]||'#f8d8b4',oc=OUT_COLORS[L.outC]?.[1]||'#3a5ad0';
 return {hr:ramp(hair),hrs:ramp(mix(hair,skin,.55)),skin:ramp(skin),oa:ramp(oc),ob:ramp(mix(oc,'#ffffff',.35)),sb:ramp('#26262e'),pn:ramp('#2e3448'),pn2:ramp('#22263a'),jean:ramp('#3a5a8a'),sh:ramp('#2a2224'),
  wh:ramp('#e8eaf2'),rd:ramp('#b8283a'),blt:ramp('#4a3424'),mt:ramp('#9aa4b8'),dk:ramp('#2a2836'),gd:ramp('#d8b040'),lth:ramp('#4a3020'),neon:ramp('#4af0ff'),sock:ramp('#f0f0f4'),
  bl1:ramp('#dfe6f2'),wd:ramp('#8a5a30'),orb:ramp('#7af0ff'),bk:ramp('#7a2a3a'),eyeC:EYE_COLORS[L.eyeC]?.[1]||'#333'};
}
const NOSHADE={neon:1,orb:1};
function renderChar(L,pose){
 const {g,det,hy}=buildChar(L,pose),C=matColors(L);
 const c=document.createElement('canvas');c.width=CW;c.height=CH;const x=c.getContext('2d');const im=x.createImageData(CW,CH),d=im.data;
 const put=(i,j,col)=>{const [r,gg,b]=hx(col),k=(j*CW+i)*4;d[k]=r;d[k+1]=gg;d[k+2]=b;d[k+3]=255};
 for(let j=0;j<CH;j++)for(let i=0;i<CW;i++){const m=g.get(i,j);if(!m)continue;const R=C[m]||ramp('#ff00ff');
  const e=[g.get(i-1,j),g.get(i+1,j),g.get(i,j-1),g.get(i,j+1)];
  let col=R.md;
  if(e.some(v=>!v))col=R.ol;
  else if(NOSHADE[m])col=R.lt;
  else if(g.get(i+1,j)!==m||g.get(i,j+1)!==m||g.get(i+1,j+1)!==m)col=R.dk;
  else if((g.get(i-1,j)!==m||g.get(i,j-1)!==m)&&m!=='skin')col=R.lt;
  if(m==='hr'&&col===R.md){if(j<=hy+2&&i>=14&&i<=19)col=R.lt;else if(j>hy+4&&(i%3===0))col=R.dk}
  put(i,j,col)}
 const ec=C.eyeC,sk=C.skin;
 const DC={o:'#1a1420',i:ec,d:mix(ec,'#000000',.55),h:'#ffffff',w:'#f4f2f6',b:C.hr.dk,n:sk.dk,m:'#5a2a2a',r:'#c84a5a',t:'#ffffff',bl:mix(sk.md,'#ff7a8a',.45)};
 det.forEach(([i,j,ch])=>{if(g.get(i,j)&&DC[ch])put(i,j,DC[ch])});
 x.putImageData(im,0,0);return c;
}
const CCACHE={};
function charFrame(L,name,f,wep){const k=JSON.stringify(L)+name+(f%4)+(wep||'');if(!CCACHE[k])CCACHE[k]=renderChar(L,{name,f:f%4,weapon:wep});return CCACHE[k]}
// วาดตัวละครที่ (x,เท้า) ขนาด sc
function drawHuman(g,L,name,t,x,y,sc=2,flip=false,alpha=1,wep){
 if(!L)return;const fr=name==='walk'?t%4:name==='attack'?Math.min(2,t):t%2;const c=charFrame(L,name,name==='idle'?Math.floor(t/5):fr,wep);
 g.save();g.globalAlpha=alpha;g.imageSmoothingEnabled=false;g.translate(x,y);if(flip)g.scale(-1,1);g.drawImage(c,-CW*sc/2,-CH*sc,CW*sc,CH*sc);g.restore();
}
