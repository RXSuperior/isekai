// ---- ทรงผม 30 แบบ (0-14 ชาย, 15-29 หญิง) ----
// fr=[รากx, ปลายx, ยาว, กว้าง] ปอยผมหน้า | sp=[x, สูง, เอียง] ปอยชี้บนกระหม่อม | sd=[ซ้าย,ขวา] จอนข้าง | bk=ผมด้านหลัง | bl=ความยาวผมหลัง(แถว)
const HSTY=[
 {n:'แสกกลางม่าน',cap:1,fr:[[-1,-4,6,4],[-4,-7,6,4],[1,4,6,4],[4,7,6,4]],sd:[7,7]},
 {n:'ทูบล็อก',cap:1,ud:1,sp:[[-4,3,-1],[0,4,0],[4,3,1]],fr:[[-5,-4,4,4],[-2,-1,5,4],[1,2,5,4],[4,6,4,4]],sd:[2,2]},
 {n:'คอมม่าแฮร์',cap:1,fr:[[-6,-6,4,4],[-3,-1,5,4],[0,3,7,4],[3,5,4,3]],sd:[6,6],curl:[[2,9]]},
 {n:'แชโดว์เพิร์ม',cap:2,wave:1,sp:[[-5,1,-1],[-1,2,0],[3,1,1]],fr:[[-6,-6,5,3],[-3,-4,6,3],[0,0,5,3],[3,4,6,3],[6,7,5,3]],sd:[7,7]},
 {n:'แดนดี้',cap:1,fr:[[-6,-6,5,3],[-3,-3,5,3],[0,0,5,3],[3,3,5,3],[6,6,4,3]],sd:[6,6]},
 {n:'ปัดข้าง',cap:1.5,sp:[[-3,2,2],[2,2,3]],fr:[[-6,-2,3,5],[-3,3,4,5],[1,7,6,4]],sd:[5,7]},
 {n:'ยุ่งตื่นนอน',cap:1.5,sp:[[-6,3,-2],[-3,4,-1],[1,4,1],[4,3,2],[7,2,3]],fr:[[-6,-7,6,3],[-3,-3,7,3],[0,1,6,3],[3,4,7,3],[6,7,5,3]],sd:[8,8]},
 {n:'หยิกสั้น',cap:.5,ud:1,wave:2,fr:[[-5,-5,2,4],[-1,-1,2,4],[3,3,2,4]],sd:[1,1]},
 {n:'หน้าม้าเฉียง',cap:1,fr:[[-6,-6,8,4],[-3,-2,9,4],[0,1,6,3],[4,5,3,3]],sd:[8,6]},
 {n:'ม่านยาว',cap:1,fr:[[-1,-5,8,4],[-4,-8,9,4],[1,5,8,4],[4,8,9,4]],sd:[10,10]},
 {n:'เสยหลัง',cap:1,sp:[[-4,2,3],[0,3,3],[4,2,3]],fr:[[-6,-6,2,4],[5,6,2,3]],sd:[4,4],slick:1},
 {n:'วูล์ฟคัตชาย',cap:1.5,sp:[[-3,2,-1],[3,2,1]],fr:[[-6,-7,6,3],[-3,-3,6,3],[0,0,5,3],[3,4,6,3],[6,7,6,3]],sd:[10,10],bk:'wolf',bl:30},
 {n:'แสกกลาง',cap:1,fr:[[-1,-6,5,5],[1,6,5,5]],sd:[9,9]},
 {n:'แสกข้างเรียบ',cap:1,fr:[[-5,-7,3,5],[2,7,2,6]],sd:[5,5],slick:1},
 {n:'ทูบล็อกชี้',cap:1,ud:1,sp:[[-5,5,-2],[-2,6,-1],[1,6,1],[4,5,2]],fr:[[-4,-4,3,3],[0,0,4,3],[4,4,3,3]],sd:[2,2]},
 {n:'ยาวตรงหน้าม้า',cap:1,fr:[[-6,-6,5,3],[-3,-3,5,3],[0,0,5,3],[3,3,5,3],[6,6,5,3]],sd:[18,18],bk:'long',bl:46},
 {n:'ฮิเมะคัท',cap:1,fr:[[-6,-6,5,3],[-3,-3,5,3],[0,0,5,3],[3,3,5,3],[6,6,5,3]],sd:[13,13],blunt:1,bk:'long',bl:48},
 {n:'หางม้าสูง',cap:1,fr:[[-6,-5,5,4],[-2,0,6,4],[2,5,5,4]],sd:[8,8],bk:'pony',bl:42},
 {n:'หางม้าต่ำ',cap:1,fr:[[-1,-5,6,4],[-4,-7,7,4],[1,4,6,4],[4,7,7,4]],sd:[9,9],bk:'lowpony',bl:40},
 {n:'แกละสองข้าง',cap:1,fr:[[-6,-6,5,3],[-3,-3,5,3],[0,0,4,3],[3,3,5,3],[6,6,5,3]],sd:[7,7],bk:'twin',bl:44},
 {n:'บ็อบ',cap:1.5,fr:[[-6,-6,5,3],[-3,-3,5,3],[0,0,5,3],[3,3,5,3],[6,6,5,3]],sd:[12,12],bk:'bob',bl:0},
 {n:'บ็อบสั้น',cap:1,fr:[[-5,-7,5,4],[-2,-1,6,4],[2,4,5,4]],sd:[9,9],bk:'bob',bl:-3},
 {n:'ยาวลอนคลื่น',cap:1.5,wave:1,fr:[[-1,-5,7,4],[-4,-8,8,4],[1,5,7,4],[4,8,8,4]],sd:[16,16],bk:'long',bl:44},
 {n:'ครึ่งมวย',cap:1,fr:[[-6,-6,5,3],[-3,-2,6,3],[0,1,5,3],[3,4,6,3],[6,7,5,3]],sd:[14,14],bk:'long',bl:42,bun:1},
 {n:'มวยสูง',cap:1,fr:[[-5,-6,5,4],[-1,-1,6,4],[3,5,5,4]],sd:[9,9],bun:2},
 {n:'เปียข้าง',cap:1,fr:[[-6,-4,5,4],[-2,1,6,4],[2,6,6,4]],sd:[8,8],bk:'braid',bl:42},
 {n:'วูล์ฟคัตยาว',cap:1.5,sp:[[-3,2,-1],[2,2,1]],fr:[[-6,-7,7,3],[-3,-3,6,3],[0,0,6,3],[3,4,7,3],[6,7,7,3]],sd:[12,12],bk:'wolf',bl:36},
 {n:'ยาวปัดข้าง',cap:1.5,fr:[[-6,-2,3,5],[-3,3,5,5],[1,7,8,4]],sd:[14,18],bk:'long',bl:46},
 {n:'พิกซี่',cap:1,fr:[[-6,-3,4,5],[-2,3,5,5],[2,7,6,4]],sd:[5,5]},
 {n:'ฮัชคัท',cap:1.5,fr:[[-1,-5,7,4],[-4,-8,8,4],[1,5,7,4],[4,8,8,4]],sd:[13,13],bk:'wolf',bl:34},
];
const HAIRS=HSTY.map(h=>h.n);
const OUTFITS=['แจ็กเก็ตฮันเตอร์','แจ็กเก็ตไซเบอร์','โค้ทยาวสีดำ','ชุดลอบเร้น','ชุดนักบวช','เสื้อกั๊กสูท','เสื้อกั๊กยุทธวิธี','เครื่องแบบนาวี','คาร์ดิแกน+เดรส','ฮู้ดครอป+สก็อต','ครอปท็อป+แจ็กเก็ต','นักเรียนชาย','นักเรียนหญิง','ฮู้ดดี้ยีนส์','แจ็กเก็ตหนัง','เกราะเบา','เกราะหนัก','เสื้อคลุมจอมเวท','ชุดฝึกยุทธ์','ผ้าคลุมพเนจร'];
const FEM_OUT=[8,9,10,12];
const LOOK_OPTS={face:FACES.length,hair:HAIRS.length,hairC:HAIR_COLORS.length,skin:SKINS.length,eyes:EYES.length,eyeC:EYE_COLORS.length,nose:NOSES.length,mouth:MOUTHS.length,outfit:OUTFITS.length,outC:OUT_COLORS.length};
function randomLook(sex){const r=n=>Math.floor(Math.random()*n);const L={sex:sex||(Math.random()<.5?'m':'f')};for(const k in LOOK_OPTS)L[k]=r(LOOK_OPTS[k]);
 L.hair=L.sex==='m'?r(15):15+r(15);if(L.sex==='m')while(FEM_OUT.includes(L.outfit))L.outfit=r(OUTFITS.length);
 if(Math.random()<.6)L.hairC=r(5);if(Math.random()<.5)L.skin=r(3);return L}
// ---- สี ----
function hx(c){const n=parseInt(c.slice(1),16);return [n>>16,n>>8&255,n&255]}
function mix(c,t,a){const A=hx(c),B=hx(t);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*a).toString(16).padStart(2,'0')).join('')}
function ramp(c){return {ol:mix(c,'#0e0a18',.8),dd:mix(c,'#1a1030',.55),dk:mix(c,'#2a1c52',.36),md:c,lt:mix(c,'#fff8e6',.3)}}
// ---- ตาราง ----
function Grid(){this.m=new Array(CW*CH).fill(null)}
Grid.prototype.set=function(x,y,k){x=Math.floor(x);y=Math.floor(y);if(x>=0&&y>=0&&x<CW&&y<CH)this.m[y*CW+x]=k};
Grid.prototype.get=function(x,y){return x<0||y<0||x>=CW||y>=CH?null:this.m[y*CW+x]};
Grid.prototype.rect=function(x,y,w,h,k){for(let j=0;j<h;j++)for(let i=0;i<w;i++)this.set(x+i,y+j,k)};
Grid.prototype.ell=function(cx,cy,rx,ry,k,cut){for(let y=Math.floor(cy-ry);y<=cy+ry;y++)for(let x=Math.floor(cx-rx);x<=cx+rx;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1&&(!cut||cut(x,y)))this.set(x,y,k)}};
Grid.prototype.poly=function(pts,k){let x0=99,x1=-1,y0=99,y1=-1;pts.forEach(([x,y])=>{x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)});
 for(let y=Math.floor(y0);y<=y1;y++)for(let x=Math.floor(x0);x<=x1;x++){let ins=false;for(let i=0,j=pts.length-1;i<pts.length;j=i++){const [xi,yi]=pts[i],[xj,yj]=pts[j];if(((yi>y+.5)!==(yj>y+.5))&&(x+.5<(xj-xi)*(y+.5-yi)/(yj-yi)+xi))ins=!ins}if(ins)this.set(x,y,k)}};
Grid.prototype.line=function(x0,y0,x1,y1,k){const n=Math.max(Math.abs(x1-x0),Math.abs(y1-y0))+1;for(let i=0;i<n;i++){const t=n>1?i/(n-1):0;this.set(Math.round(x0+(x1-x0)*t),Math.round(y0+(y1-y0)*t),k)}};
// ปอยผมเรียวแหลม
Grid.prototype.lock=function(rx,ry,tx,ty,w,k){this.poly([[rx-w/2,ry],[rx+w/2,ry],[tx+.8,ty],[tx-.8,ty]],k);this.set(tx,ty-1,k)};
const HAIRK={hr:1,hq:1,hb:1,hc:1};
// ---- ร่างกาย ----
function buildChar(L,pose){
 const g=new Grid(),det=[];const P=pose||{name:'idle',f:0};const f=P.f||0;
 const fem=L.sex==='f',F=FACES[L.face]||FACES[0],cx=20,H=HSTY[L.hair]||HSTY[0];
 let bob=0;if(P.name==='idle'||P.name==='walk')bob=f%2;if(P.name==='hurt')bob=1;
 const fw=F.w+3,fh=F.h+3,top=3+bob,hy=top+1,fx=cx-fw/2;
 const ty=hy+fh+1,hip=ty+14,FT=60;
 let lx=0,rx=0,ll=0,rl=0;if(P.name==='walk'){const s=[[-2,2,0,1],[0,0,1,0],[2,-2,1,0],[0,0,0,1]][f%4];lx=s[0];rx=s[1];ll=s[2];rl=s[3]}
 if(P.name==='attack'){lx=-2;rx=2}
 const LW=fem?4:5,LX=cx-LW,RX=cx+1;
 const shW=fem?12:15,shX=cx-shW/2,waW=fem?9:12,AW=fem?3:4,AL=hip-ty+1;
 // ผมด้านหลัง
 hairBack(g,H,cx,hy,fw,fh,ty);
 const o=L.outfit;
 const legs=(k,from=hip,to=FT)=>{g.rect(LX+lx,from,LW,to-from-ll,k);g.rect(RX+rx,from,LW,to-from-rl,k);if(from<=hip)g.rect(LX,hip,LW*2+1,3,k)};
 const legPart=(k,from,to)=>{g.rect(LX+lx,from,LW,to-from,k);g.rect(RX+rx,from,LW,to-from,k)};
 const shoes=(k,boot=0)=>{const b=boot?5:0;g.rect(LX-1+lx,FT-ll-b,LW+1,4+b,k);g.rect(RX+rx,FT-rl-b,LW+1,4+b,k);g.rect(LX-1+lx,FT+3-ll,LW+2,1,'sole');g.rect(RX+rx,FT+3-rl,LW+2,1,'sole')};
 const torso=(k,t=ty,b=hip)=>{if(fem)g.poly([[shX,t],[shX+shW,t],[cx+waW/2,t+8],[cx+LW+1,b],[cx-LW-1,b],[cx-waW/2,t+8]],k);else g.poly([[shX,t],[shX+shW,t],[cx+waW/2,b],[cx-waW/2,b]],k);
  g.ell(shX+1,t+1.5,2.2,2,k);g.ell(shX+shW-1,t+1.5,2.2,2,k)};
 const armBase=(side)=>({x:side<0?shX-AW+1:shX+shW-1,y:ty+1});
 const arm=(side,k,len=AL)=>{const a=armBase(side);
  if(side>0&&P.name==='attack'){const ext=[0,6,9][f%3];g.rect(a.x,a.y,AW,6,k);g.rect(a.x,a.y+4,Math.min(len,AW+ext),AW,k)}
  else if(P.name==='walk'){const sw=(side<0?[1,0,-1,0]:[-1,0,1,0])[f%4];g.rect(a.x,a.y,AW,Math.min(len,AL-5),k);if(len>AL-5)g.rect(a.x+sw,a.y+AL-5,AW,len-(AL-5),k)}
  else if(P.name==='hurt'){g.rect(a.x+(side<0?-1:1),a.y,AW,len-1,k)}
  else{g.rect(a.x,a.y,AW,len,k);if(len>8)g.rect(a.x+(side<0?0:0),a.y+len-3,AW,3,k)}};
 const cuff=(k,at=AL-2)=>{for(const s of[-1,1]){if(s>0&&P.name==='attack')continue;const a=armBase(s);let x=a.x;if(P.name==='walk')x+=(s<0?[1,0,-1,0]:[-1,0,1,0])[f%4];if(P.name==='hurt')x+=s;g.rect(x,a.y+at,AW,2,k)}};
 const hand=(side)=>{const a=armBase(side);
  if(side>0&&P.name==='attack'){const ext=[0,6,9][f%3];g.rect(a.x+AW+ext-1,a.y+4,3,AW,'skin');return}
  let x=a.x,y=a.y+AL;if(P.name==='hurt'){y-=2;x+=side<0?-1:1}if(P.name==='walk')x+=(side<0?[1,0,-1,0]:[-1,0,1,0])[f%4];g.rect(x,y,AW,3,'skin');g.set(x+(side<0?AW-1:0),y+3,'skin')};
 const skirt=(k,len=10,flare=3)=>g.poly([[cx-waW/2,hip-3],[cx+waW/2,hip-3],[cx+waW/2+flare,hip+len],[cx-waW/2-flare,hip+len]],k);
 const panels=(k,w,t=ty,b=hip+2)=>{g.poly([[shX-1,t],[shX+w,t],[shX+w-1,b],[shX-1,b]],k);g.poly([[shX+shW-w,t],[shX+shW+1,t],[shX+shW+1,b],[shX+shW-w+1,b]],k)};
 const trimV=(x,y0,y1,k='tr')=>g.rect(x,y0,1,y1-y0,k);
 const coatTail=(k,to,split=1)=>{g.poly([[cx-waW/2-1,hip-2],[cx+waW/2+1,hip-2],[cx+waW/2+4,to],[cx-waW/2-4,to]],k);if(split)g.rect(cx,hip+2,1,to-hip-2,'oc')};
 const belt=(y,k='blt')=>{g.rect(cx-waW/2-(fem?1:0),y,waW+(fem?2:0),2,k);g.rect(cx-1,y,2,2,'gd')};
 const btn=(x,y0,y1,s=3,k='gd')=>{for(let y=y0;y<y1;y+=s)g.set(x,y,k)};
 const collar=(k)=>{g.poly([[cx-4,ty-1],[cx-1,ty-1],[cx-1,ty+4]],k);g.poly([[cx+1,ty-1],[cx+4,ty-1],[cx+1,ty+4]],k)};
 const sock=(k,from)=>{g.rect(LX+lx,from,LW,FT-from-ll,k);g.rect(RX+rx,from,LW,FT-from-rl,k)};
 switch(o){
  case 0:legs('pn');shoes('sh');torso('in');panels('oa',5);trimV(shX+4,ty,hip+2);trimV(shX+shW-4,ty,hip+2);g.poly([[shX+2,ty-1],[shX+5,ty-1],[shX+5,ty+5]],'ob');g.poly([[shX+shW-5,ty-1],[shX+shW-2,ty-1],[shX+shW-5,ty+5]],'ob');arm(-1,'oa');arm(1,'oa');cuff('ob');break;
  case 1:legs('pn');legPart('oc',hip+6,hip+10);shoes('sh',1);torso('oc');panels('oa',6);trimV(shX+5,ty,hip+2,'neon');trimV(shX+shW-5,ty,hip+2,'neon');g.rect(shX-1,ty+7,shW+2,1,'neon');arm(-1,'oa');arm(1,'oa');cuff('neon',AL-4);collar('oc');break;
  case 2:legs('pn');shoes('sh',1);torso('in');coatTail('oa',FT-6);panels('oa',6,ty,hip);trimV(shX+5,ty,hip,'oc');trimV(shX+shW-5,ty,hip,'oc');belt(hip-3,'oc');arm(-1,'oa');arm(1,'oa');cuff('oc');g.poly([[shX-1,ty-2],[cx-2,ty-2],[shX+5,ty+6]],'ob');g.poly([[cx+2,ty-2],[shX+shW+1,ty-2],[shX+shW-5,ty+6]],'ob');break;
  case 3:legs('oc');shoes('oc',1);torso('oc');g.rect(shX,ty+3,shW,2,'oa');g.rect(cx-5,ty-3,10,4,'oa');g.poly([[cx+4,ty-3],[cx+7,ty-3],[cx+10,ty+8],[cx+8,ty+9]],'oa');arm(-1,'oc');arm(1,'oc');cuff('oa',AL-6);belt(hip-3,'oa');legPart('oa',hip+12,hip+14);break;
  case 4:legs('wh');shoes('sh');torso('wh');g.poly([[cx-waW/2-1,hip-2],[cx+waW/2+1,hip-2],[cx+waW/2+3,FT-1],[cx-waW/2-3,FT-1]],'wh');g.rect(cx-3,ty,2,FT-ty-3,'oa');g.rect(cx+1,ty,2,FT-ty-3,'oa');g.rect(cx-3,FT-6,6,2,'gd');g.rect(cx-1,ty+3,2,6,'gd');g.rect(cx-3,ty+5,6,2,'gd');arm(-1,'wh');arm(1,'wh');cuff('gd');break;
  case 5:legs('oc');shoes('sh');torso('wh');g.poly([[shX+1,ty+2],[cx-1,ty+7],[cx-1,hip],[cx-waW/2,hip]],'oa');g.poly([[shX+shW-1,ty+2],[cx+1,ty+7],[cx+1,hip],[cx+waW/2,hip]],'oa');g.rect(cx-1,ty,2,9,'rd');btn(cx-2,ty+9,hip,2,'oc');arm(-1,'wh');arm(1,'wh');cuff('wh');break;
  case 6:legs('cg');legPart('cg2',hip+5,hip+9);shoes('sh',1);torso('in');arm(-1,'in',6);arm(1,'in',6);{const a=armBase(-1),b=armBase(1);if(P.name!=='attack'){g.rect(a.x,a.y+6,AW,AL-6,'skin');g.rect(b.x,b.y+6,AW,AL-6,'skin')}else g.rect(a.x,a.y+6,AW,AL-6,'skin')}
   g.rect(shX+1,ty+1,shW-2,hip-ty-2,'oa');g.rect(shX+2,ty+5,4,3,'oc');g.rect(shX+shW-6,ty+5,4,3,'oc');g.rect(shX+2,ty+9,4,3,'oc');g.rect(shX+shW-6,ty+9,4,3,'oc');g.rect(cx-1,ty+1,2,hip-ty-2,'in');belt(hip-2);break;
  case 7:legs('oa');shoes('sh');torso('oa');g.rect(shX-1,ty-1,4,2,'gd');g.rect(shX+shW-3,ty-1,4,2,'gd');btn(cx-3,ty+3,hip,3);btn(cx+2,ty+3,hip,3);collar('wh');g.rect(cx-waW/2,hip-3,waW,1,'gd');arm(-1,'oa');arm(1,'oa');cuff('gd');g.poly([[cx-waW/2,hip-2],[cx+waW/2,hip-2],[cx+waW/2+1,hip+3],[cx-waW/2-1,hip+3]],'oa');break;
  case 8:legs('skin',hip+8);sock('wh',FT-2);shoes('wh');torso('fl');skirt('fl',13,4);g.rect(cx-3,ty-1,6,2,'wh');panels('oa',4,ty,hip+1);arm(-1,'oa');arm(1,'oa');cuff('ob');btn(shX+3,ty+2,hip,3,'ob');break;
  case 9:legs('skin',hip+6);sock('wh',FT-3);shoes('wh');skirt('pl',9,4);torso('oa',ty,hip-2);g.rect(cx-waW/2,hip-2,waW,1,'skin');g.rect(cx-1,ty+1,1,4,'wh');g.rect(cx+1,ty+1,1,4,'wh');g.rect(shX+2,ty+7,shW-4,3,'ob');arm(-1,'oa');arm(1,'oa');cuff('ob');break;
  case 10:legs('skin',hip+6);sock('in',FT-4);shoes('in',1);skirt('pl',8,3);torso('skin',ty+6,hip);torso('wh',ty,ty+7);panels('oa',4,ty,ty+8);arm(-1,'oa');arm(1,'oa');cuff('ob');belt(hip-3,'in');break;
  case 11:legs('pn2');shoes('sh');torso('oa');g.poly([[cx-3,ty],[cx+3,ty],[cx,ty+8]],'wh');g.rect(cx-1,ty+1,2,8,'rd');btn(cx+2,ty+9,hip,3,'gd');g.rect(shX+2,ty+8,3,1,'ob');arm(-1,'oa');arm(1,'oa');cuff('ob');g.poly([[cx-waW/2,hip-2],[cx+waW/2,hip-2],[cx+waW/2+1,hip+3],[cx-waW/2-1,hip+3]],'oa');break;
  case 12:legs('skin',hip+6);sock('sock',hip+14);shoes('sh');skirt('pl',9,3);torso('oa');g.poly([[cx-3,ty],[cx+3,ty],[cx,ty+7]],'wh');g.poly([[cx-2,ty+3],[cx+2,ty+3],[cx,ty+8]],'rd');btn(cx+2,ty+9,hip-2,3,'gd');arm(-1,'oa');arm(1,'oa');cuff('ob');break;
  case 13:legs('jean');shoes('wh');torso('oa');g.rect(shX+2,ty+8,shW-4,4,'ob');g.line(cx-2,ty+1,cx-2,ty+6,'wh');g.line(cx+1,ty+1,cx+1,ty+6,'wh');g.ell(cx,ty,shW/2+1,2.5,'oa');arm(-1,'oa');arm(1,'oa');cuff('ob');break;
  case 14:legs('jean');shoes('sh',1);torso('in');panels('lth',6);trimV(shX+5,ty,hip+2,'mt');g.poly([[shX,ty-2],[cx-2,ty-2],[shX+5,ty+5]],'lth');g.poly([[cx+2,ty-2],[shX+shW,ty-2],[shX+shW-5,ty+5]],'lth');arm(-1,'lth');arm(1,'lth');cuff('mt');belt(hip-1);break;
  case 15:legs('pn');legPart('mt',hip+8,hip+13);shoes('lth',1);torso('oa');g.rect(shX+2,ty+2,shW-4,8,'mt');g.ell(shX,ty+1,3.5,3,'mt');g.ell(shX+shW,ty+1,3.5,3,'mt');arm(-1,'oa');arm(1,'oa');cuff('lth',AL-6);belt(hip-3,'lth');break;
  case 16:legs('mt');shoes('mt',1);torso('mt');g.rect(shX+3,ty+3,shW-6,7,'oa');g.ell(shX-1,ty+1,4.5,4,'mt');g.ell(shX+shW+1,ty+1,4.5,4,'mt');arm(-1,'mt');arm(1,'mt');belt(hip-3,'oa');legPart('oa',hip+10,hip+12);g.rect(cx-waW/2-1,hip-2,waW+2,4,'mt');break;
  case 17:legs('pn');shoes('sh');torso('oa');g.poly([[cx-waW/2-1,hip-2],[cx+waW/2+1,hip-2],[cx+waW/2+4,FT],[cx-waW/2-4,FT]],'oa');g.rect(cx,ty+2,1,FT-ty-2,'gd');g.rect(shX-2,ty-1,shW+4,3,'ob');arm(-1,'oa');arm(1,'oa');{const a=armBase(-1),b=armBase(1);g.rect(a.x-1,a.y+AL-6,AW+1,5,'oa');if(P.name!=='attack')g.rect(b.x,b.y+AL-6,AW+1,5,'oa')}belt(hip-3,'gd');break;
  case 18:legs('wh');shoes('skin');torso('wh');g.poly([[cx-4,ty-1],[cx,ty-1],[cx+3,ty+9],[cx+1,ty+9]],'oa');g.rect(cx-waW/2-1,hip-3,waW+2,2,'in');g.rect(cx+2,hip-1,2,5,'in');arm(-1,'wh');arm(1,'wh');break;
  case 19:legs('pn');shoes('lth',1);torso('in');g.poly([[shX-3,ty-1],[shX+shW+3,ty-1],[shX+shW+5,hip+12],[cx,hip+10],[shX-5,hip+12]],'oa');arm(-1,'oa',10);arm(1,'oa',10);g.rect(cx-6,ty-3,12,4,'oa');g.rect(cx-1,ty-1,2,2,'gd');break;
 }
 hand(-1);hand(1);
 g.rect(cx-2,ty-3,4,4,'skin');
 // หัว
 if(F.j==='r')g.ell(cx,hy+fh/2,fw/2,fh/2,'skin');
 else if(F.j==='o')g.ell(cx,hy+fh/2,fw/2,fh/2+.5,'skin');
 else if(F.j==='s'){g.rect(fx,hy+1,fw,fh-3,'skin');g.rect(fx+1,hy,fw-2,1,'skin');g.rect(fx+1,hy+fh-2,fw-2,2,'skin')}
 else if(F.j==='v'){g.ell(cx,hy+fh*.42,fw/2,fh*.42+1,'skin');g.poly([[fx,hy+fh*.45],[fx+fw,hy+fh*.45],[cx+2,hy+fh],[cx-2,hy+fh]],'skin')}
 else if(F.j==='h'){g.ell(cx,hy+fh*.42,fw/2+.5,fh*.42+.5,'skin');g.poly([[fx,hy+fh*.5],[fx+fw,hy+fh*.5],[cx+2.5,hy+fh],[cx-2.5,hy+fh]],'skin')}
 g.rect(Math.floor(fx)-1,hy+Math.round(fh*.45),1,3,'skin');g.rect(Math.ceil(fx+fw),hy+Math.round(fh*.45),1,3,'skin');
 // ใบหน้า
 const ey=hy+Math.round(fh*.5),eye=EYES[L.eyes]||EYES[0],ew=eye.p[0].length;
 eye.p.forEach((row,j)=>{for(let i=0;i<row.length;i++){const ch=row[i];if(ch==='.')continue;det.push([cx+2+i,ey+j,ch]);det.push([cx-3-i,ey+j,ch==='h'?'h':ch])}});
 for(let i=0;i<ew;i++){det.push([cx+2+i,ey-2+(i===0?1:0),'b']);det.push([cx-3-i,ey-2+(i===0?1:0),'b'])}
 const nose=NOSES[L.nose]||NOSES[0],ny=ey+eye.p.length;nose.p.forEach((row,j)=>{for(let i=0;i<row.length;i++)if(row[i]==='n')det.push([cx-1+i,ny+j,'n'])});
 const mo=MOUTHS[P.name==='hurt'?5:L.mouth]||MOUTHS[0],my=Math.min(hy+fh-3,ny+Math.max(2,nose.p.length+1)),mw=mo.p[0].length;
 mo.p.forEach((row,j)=>{for(let i=0;i<row.length;i++){const ch=row[i];if(ch!=='.')det.push([cx-Math.ceil(mw/2)+i,my+j,ch])}});
 if(fem){det.push([cx-6,ey+3,'bl']);det.push([cx-5,ey+3,'bl']);det.push([cx+5,ey+3,'bl']);det.push([cx+6,ey+3,'bl'])}
 hairFront(g,H,cx,hy,fw,fh);
 if(P.weapon)weapon(g,P.weapon,P.name==='attack'?f%3:-1,armBase(1),AW,AL);
 return {g,det,hy,fh,ty};
}
function hairBack(g,H,cx,hy,fw,fh,ty){const bk=H.bk,bl=H.bl||0,l=cx-fw/2-2,r=cx+fw/2+2;
 const strands=(x0,x1,y0,y1,step=3,jag=2)=>{let n=0;for(let x=x0;x<=x1;x+=step,n++)g.lock(x+1.5,y0,x+1+(n%2?.5:-.5),y1-(n%3===1?jag:0),step+1.2,n%2?'hb':'hc')};
 if(H.bun===2)g.ell(cx,hy-4,4.5,3.5,'hb');
 if(H.bun===1)g.ell(cx,hy-1,3.5,3,'hb');
 if(bk==='long'){g.ell(cx,hy+6,fw/2+3,8,'hb');strands(l-1,r-1,hy+4,bl,3,H.wave?3:2);if(H.wave)for(let y=hy+14;y<bl-2;y+=5){g.set(l-2,y,'hb');g.set(r+1,y+2,'hb')}}
 else if(bk==='wolf'){g.ell(cx,hy+6,fw/2+3,8,'hb');strands(l,r-2,hy+4,bl,3,3);g.lock(l,bl-6,l-3,bl+1,3,'hb');g.lock(r,bl-6,r+3,bl+1,3,'hc')}
 else if(bk==='bob'){g.ell(cx,hy+7,fw/2+3.5,fh/2+2+bl/3,'hb');strands(l-1,r-1,hy+6,hy+fh+2+bl,3,1)}
 else if(bk==='pony'){g.ell(cx+3,hy-1,3.5,3,'hb');g.lock(cx+6,hy,cx+11,bl,6,'hb');g.lock(cx+8,hy+2,cx+9,bl-4,4,'hc');g.rect(cx+4,hy,3,2,'rd')}
 else if(bk==='lowpony'){g.lock(cx+6,hy+fh-4,cx+5,bl,6,'hb');g.lock(cx+7,hy+fh-2,cx+8,bl-3,4,'hc');g.rect(cx+5,hy+fh-3,3,2,'rd')}
 else if(bk==='twin'){for(const s of[-1,1]){const x=cx+s*(fw/2+2);g.lock(x,hy+2,x+s*4,bl,8,'hb');g.lock(x+s*1.5,hy+5,x+s*3,bl-3,5,'hc');g.rect(x-1,hy+2,3,2,'rd')}}
 else if(bk==='braid'){g.ell(cx,hy+6,fw/2+3,7,'hb');for(let i=0,y=hy+fh-2;y<bl;i++,y+=3)g.ell(cx+fw/2+(i%2?1:2),y,2.6,2,i%2?'hb':'hc');g.rect(cx+fw/2,bl,3,2,'rd')}
 else g.ell(cx,hy+5,fw/2+2,6,'hb');
}
function hairFront(g,H,cx,hy,fw,fh){
 const capR=fw/2+1.2+H.cap*.6,capY=hy+fh*.36,capRY=fh*.36+1.6+H.cap*.5,fore=hy+2;
 if(H.ud){g.ell(cx,capY+1,fw/2+.6,capRY-1,'hb',(x,y)=>y<=hy+5);}
 const w=H.ud?capR-1:capR;
 g.ell(cx,capY,w,capRY,'hr',(x,y)=>y<=fore+(H.ud?0:1));
 if(H.wave)for(let x=Math.ceil(cx-w)+1;x<cx+w-1;x+=3)for(let y=Math.ceil(capY-capRY)+2;y<fore;y+=3)g.set(x+((y>>1)%2),y,'hq');
 if(H.slick)for(let i=-4;i<=4;i+=3)g.line(cx+i,fore,cx+i+3,capY-capRY+1,'hq');
 (H.sp||[]).forEach(([x,h,d],i)=>{const by=capY-capRY+2+Math.abs(x)*.25;g.lock(cx+x,by+2,cx+x+d,by-h,5.5,i%2?'hq':'hr')});
 // จอนข้าง
 const sd=H.sd||[5,5];[-1,1].forEach((s,i)=>{const len=sd[i];if(len<=0)return;const x=cx+s*(fw/2+.5);
  if(H.blunt){g.rect(s<0?x-2:x-1,hy+3,3,len+1,'hq');return}
  g.lock(x,hy+2,x+s*(len>10?1:0),hy+3+len,3.4,'hq');if(len>6)g.lock(x-s*1.6,hy+3,x-s*1,hy+2+len*.7,2.2,'hr')});
 // ปอยหน้า
 (H.fr||[]).forEach(([r0,t0,len,wd],i)=>{const k=i%2?'hq':'hr';if(H.blunt){g.rect(cx+r0-wd/2,fore-1,wd,len+1,k);return}g.lock(cx+r0,fore-1,cx+t0,fore+len,wd,k)});
 (H.curl||[]).forEach(([x,len])=>{g.lock(cx+x,fore,cx+x-1,fore+len,2.5,'hq');g.set(cx+x-2,fore+len-1,'hq')});
}
function weapon(g,w,f,a,AW,AL){
 const hx=f<0?a.x+1:a.x+AW+[0,6,9][f]-1,hy=f<0?a.y+AL+1:a.y+5;
 switch(w){
  case 'sword':if(f<0){g.line(hx+1,hy+2,hx+7,hy+16,'bl2');g.line(hx+2,hy+2,hx+8,hy+16,'bl1');g.line(hx+3,hy+2,hx+9,hy+16,'bl2');g.rect(hx,hy,5,2,'gd');g.rect(hx+1,hy-3,2,3,'grip')}
   else if(f===0){g.line(hx,hy-2,hx-3,hy-18,'bl2');g.line(hx+1,hy-2,hx-2,hy-18,'bl1');g.line(hx+2,hy-2,hx-1,hy-18,'bl2');g.rect(hx-1,hy-2,5,2,'gd');g.rect(hx,hy,2,3,'grip')}
   else{const d=f===1?9:1;g.line(hx+1,hy-1,hx+17,hy-1-d,'bl2');g.line(hx+1,hy,hx+17,hy-d,'bl1');g.line(hx+1,hy+1,hx+17,hy+1-d,'bl2');g.rect(hx,hy-2,2,5,'gd');g.rect(hx-3,hy,3,2,'grip')}break;
  case 'tank':{const sx=f<0?a.x-3:hx-1,sy=f<0?a.y+4:hy-7;g.rect(sx,sy,8,15,'mt');g.rect(sx+2,sy+2,4,11,'oa');g.rect(sx+3,sy+6,2,3,'gd')}break;
  case 'bow':{const bx=f<0?hx+3:hx+1;g.line(bx,hy-11,bx+3,hy-6,'wd');g.line(bx+3,hy-6,bx+3,hy+6,'wd');g.line(bx+3,hy+6,bx,hy+11,'wd');g.line(bx,hy-11,bx,hy+11,'wh')}break;
  case 'mage':g.line(hx+2,hy-18,hx+2,hy+10,'wd');g.ell(hx+2,hy-19,2.5,2.5,'orb');g.set(hx+1,hy-17,'gd');g.set(hx+3,hy-17,'gd');break;
  case 'assassin':g.line(hx+1,hy,hx+(f<0?4:9),hy+(f<0?8:-1),'bl1');g.rect(hx,hy-1,2,2,'grip');break;
  case 'healer':g.rect(hx,hy-5,6,7,'bk');g.rect(hx+2,hy-4,2,5,'gd');break;
 }
}
// ---- ลงสี ----
function matColors(L){
 const hair=HAIR_COLORS[L.hairC]?.[1]||'#222',skin=SKINS[L.skin]?.[1]||'#f8d8b4',oc=OUT_COLORS[L.outC]?.[1]||'#3a5ad0';
 const hr=ramp(hair),hb=ramp(mix(hair,'#100c1c',.22));hr.lt=mix(hair,'#c8d0ff',.34);
 return {hr,hq:hr,hb,hc:hb,hrs:ramp(mix(hair,skin,.6)),skin:ramp(skin),oa:ramp(oc),ob:ramp(mix(oc,'#ffffff',.4)),oc:ramp(mix(oc,'#14121c',.55)),tr:ramp(mix(oc,'#ffffff',.6)),
  in:ramp('#24222c'),pn:ramp('#2a2e44'),pn2:ramp('#22263a'),jean:ramp('#3a5a8a'),cg:ramp('#3e4436'),cg2:ramp('#2e3428'),sh:ramp('#2a2430'),sole:ramp('#d8d4e0'),
  wh:ramp('#eceef4'),rd:ramp('#c02a3c'),blt:ramp('#4a3424'),mt:ramp('#9aa4bc'),gd:ramp('#e0b440'),lth:ramp('#4a2e22'),neon:ramp('#4af0ff'),sock:ramp('#f2f2f6'),
  fl:ramp('#f0a8b8'),pl:ramp(mix(oc,'#3a3a48',.4)),grip:ramp('#5a3a7a'),bl1:ramp('#e8eef8'),bl2:ramp('#9aa6c8'),wd:ramp('#8a5a30'),orb:ramp('#7af0ff'),bk:ramp('#7a2a3a'),eyeC:EYE_COLORS[L.eyeC]?.[1]||'#333'};
}
const NOSHADE={neon:1,orb:1};
function renderChar(L,pose){
 const {g,det,hy,fh,ty}=buildChar(L,pose),C=matColors(L);
 const c=document.createElement('canvas');c.width=CW;c.height=CH;const x=c.getContext('2d');const im=x.createImageData(CW,CH),d=im.data;
 const put=(i,j,col)=>{const [r,gg,b]=hx(col),k=(j*CW+i)*4;d[k]=r;d[k+1]=gg;d[k+2]=b;d[k+3]=255};
 const run=(i,j,m,s)=>{let n=0;while(n<7&&g.get(i+s*(n+1),j)===m)n++;return n};
 const ishair=v=>HAIRK[v];
 for(let j=0;j<CH;j++)for(let i=0;i<CW;i++){const m=g.get(i,j);if(!m)continue;const R=C[m]||ramp('#ff00ff');
  const e=[g.get(i-1,j),g.get(i+1,j),g.get(i,j-1),g.get(i,j+1)];
  let col=R.md;
  if(e.some(v=>!v))col=R.ol;
  else if(NOSHADE[m])col=R.lt;
  else{const l=run(i,j,m,-1),r=run(i,j,m,1),w=l+r+1;
   if(g.get(i+1,j)!==m||g.get(i,j+1)!==m)col=(ishair(m)&&ishair(g.get(i+1,j))&&ishair(g.get(i,j+1)))?R.dd:R.dk;
   else if(w>=4&&r<Math.max(1,Math.round(w*.28)))col=R.dk;
   else if(l===0&&w>=3&&m!=='skin')col=R.lt;
   if(m==='skin'&&ishair(g.get(i,j-1)))col=R.dk;
   if(m==='skin'&&j>=hy+fh&&j<ty)col=R.dk;
   if(m!=='skin'&&!ishair(m)&&j>=ty&&j<=ty+1&&g.get(i,j-1)==='skin')col=R.dk;
   if(ishair(m)&&col===R.md){const sy=hy+Math.round(Math.abs(i-18)*.3);if((j===sy||j===sy+1)&&i>=13&&i<=24&&(i+j)%4!==0)col=R.lt}
   if(m==='pl'&&col===R.md&&(i%4===0||j%4===0))col=R.dd;
   if(m==='fl'&&col===R.md&&(i*7+j*3)%11===0)col=C.wh.md;}
  put(i,j,col)}
 const ec=C.eyeC,sk=C.skin;
 const DC={o:'#1a1020',i:ec,d:mix(ec,'#000000',.55),h:'#ffffff',w:'#f4f2f6',b:C.hr.dd,n:sk.dk,m:'#5a2a2a',r:'#c84a5a',t:'#ffffff',bl:mix(sk.md,'#ff7a8a',.45)};
 det.forEach(([i,j,ch])=>{if(g.get(i,j)==='skin'&&DC[ch])put(i,j,DC[ch])});
 x.putImageData(im,0,0);return c;
}
const CCACHE={};
function charFrame(L,name,f,wep){const k=JSON.stringify(L)+name+(f%4)+(wep||'');if(!CCACHE[k])CCACHE[k]=renderChar(L,{name,f:f%4,weapon:wep});return CCACHE[k]}
function drawHuman(g,L,name,t,x,y,sc=2,flip=false,alpha=1,wep){
 if(!L)return;const fr=name==='walk'?t%4:name==='attack'?Math.min(2,t):t%2;const c=charFrame(L,name,name==='idle'?Math.floor(t/5):fr,wep);
 g.save();g.globalAlpha=alpha;g.imageSmoothingEnabled=false;g.translate(x,y);if(flip)g.scale(-1,1);g.drawImage(c,-CW*sc/2,-CH*sc,CW*sc,CH*sc);g.restore();
}
