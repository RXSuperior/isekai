// =============== ข้อมูลหลัก ===============
const RANKS=['E','D','C','B','A','S'];
const GATE_DIFF=[60,120,220,400,680,1100];
const SN={str:'กาย',agi:'ความเร็ว',int:'ปัญญา',vit:'ความอึด',cha:'เสน่ห์',luk:'โชค',gold:'เงิน',fame:'ชื่อเสียง',karma:'กรรม',coin:'ดาวเหรียญ',hp:'พลังชีวิต'};
const STATS=['str','agi','int','vit','cha','luk'];
const CLASSES=[
 {id:'sword',n:'นักดาบ',m:'str',d:'ฟันระยะประชิด เน้นกาย'},{id:'bow',n:'นักธนู',m:'agi',d:'ยิงจากระยะไกล เน้นความเร็ว'},
 {id:'mage',n:'นักเวท',m:'int',d:'ร่ายลูกไฟ เน้นปัญญา'},{id:'assassin',n:'นักลอบสังหาร',m:'agi',d:'หายตัวไปด้านหลังศัตรู'},
 {id:'healer',n:'ผู้รักษา',m:'int',d:'ฟื้นฟูตัวเองและทีม'},{id:'tank',n:'ผู้คุ้มกัน',m:'vit',d:'ยกโล่รับดาเมจแทนทีม'}];
const TRAITS=[['brave','ขี้ขลาด','กล้าหาญ'],['kind','โหดร้าย','ใจดี'],['dili','ขี้เกียจ','ขยัน'],['loyal','เห็นแก่ตัว','ซื่อสัตย์']];
const PATHS={
 school:[{id:'study',n:'ตั้งใจเรียน',d:'ปัญญาโตเร็ว เหตุการณ์เรื่องเรียนมาบ่อย',act:'เรียนหนังสือ',g:{int:.5}},
  {id:'sport',n:'เล่นกีฬา',d:'กายและความอึดโตเร็ว เหตุการณ์ด้านกำลังมาบ่อย',act:'ซ้อมกีฬา',g:{str:.3,vit:.3}},
  {id:'social',n:'ผูกมิตร',d:'เสน่ห์โตเร็ว เหตุการณ์เรื่องผู้คนมาบ่อย',act:'เที่ยวกับเพื่อน',g:{cha:.5}},
  {id:'work',n:'ทำงานพิเศษ',d:'ได้เงินทุกเดือน ความเร็วโตขึ้นเล็กน้อย',act:'ทำงานพิเศษ',g:{agi:.2},gold:40}],
 hunter:[{id:'hunt',n:'นักล่าเกต',d:'ได้ EXP ทุกเดือน เหตุการณ์ในเกตมาบ่อย',act:'ลาดตระเวนย่านเกต',g:{str:.15,agi:.15},exp:1},
  {id:'guild',n:'คนของสมาคม',d:'ได้เงินและชื่อเสียงจากงานสมาคม',act:'รับงานสมาคม',g:{cha:.2},gold:1,fame:.3},
  {id:'research',n:'นักวิจัยเกต',d:'ปัญญาโตเร็ว ได้ดาวเหรียญจากการศึกษาเกต',act:'ศึกษาแกนอสูร',g:{int:.5},coin:.25},
  {id:'train',n:'ฝึกฝนตัวเอง',d:'ค่าพลังหลักของอาชีพโตเร็วที่สุด',act:'ฝึกที่ลานฝึก',g:{main:.6,vit:.2}},
  {id:'dark',n:'ฮันเตอร์นอกกฎหมาย',d:'เงินดี แต่กรรมลดและเหตุการณ์มืดมาบ่อย',act:'รับงานใต้ดิน',g:{agi:.2},gold:2.5,karma:-.3}]};
const PLACES=[
 {id:'home',n:'บ้าน',d:'ที่พักของท่าน เรื่องในครอบครัวเกิดที่นี่'},
 {id:'school',n:'โรงเรียนมัธยมฮันนัม',d:'เรียน สอบ ชมรม และเพื่อนร่วมชั้น',c:p=>p.stage==='school',why:'จบการศึกษาแล้ว'},
 {id:'city',n:'ย่านใจกลางเมือง',d:'ร้านค้า ข่าวลือ และผู้คน'},
 {id:'guild',n:'สมาคมฮันเตอร์',d:'รับภารกิจ ซื้ออุปกรณ์ หาเพื่อนร่วมทีม',c:p=>p.stage==='hunter',why:'ต้องตื่นพลังก่อน'},
 {id:'gatezone',n:'ย่านเกต',d:'เขตกั้นรอบเกตที่เปิดอยู่ อันตรายแต่คุ้มค่า',c:p=>p.stage==='hunter',why:'ต้องตื่นพลังก่อน'},
 {id:'hospital',n:'โรงพยาบาลฮันเตอร์',d:'พักรักษาตัว ฟื้นพลังชีวิตเร็วขึ้นมาก'},
 {id:'casino',n:'บ่อนใต้ดิน',d:'เดิมพัน ข่าวมืด และงานนอกกฎหมาย',c:p=>p.stage==='hunter',why:'คนธรรมดาเข้าไม่ได้'}];
const STARS=[
 {id:'night',n:'ผู้เฝ้าประตูราตรี',like:'risk',gift:'เกตที่สูงกว่าแรงก์ให้รางวัลเพิ่ม 30%',say:['หัวเราะเบา ๆ ตอนท่านก้าวเข้าเกตที่ไม่ควรเข้า','ชอบคนที่ไม่รู้จักกลัว']},
 {id:'sage',n:'ปราชญ์ใต้เงาจันทร์',like:'tower',gift:'ได้ EXP เพิ่ม 30%',say:['จดชื่อท่านไว้ในตำราเล่มหนึ่ง','สงสัยว่าชั้นบนสุดของหอคอยมีอะไร']},
 {id:'flame',n:'ราชันเปลวอัคคี',like:'boss',gift:'พลังต่อสู้เพิ่ม 15%',say:['อยากเห็นท่านล้มบอสอีกตัว','บ่นว่าการต่อสู้ครั้งนี้สั้นเกินไป']},
 {id:'mother',n:'มารดาแห่งดาวแรกเกิด',like:'kind',gift:'ฟื้นพลังชีวิตเร็วขึ้นสองเท่า',say:['มองท่านด้วยความเป็นห่วง','ยิ้มเมื่อท่านช่วยคนอื่น']},
 {id:'gambler',n:'นักพนันตาเดียว',like:'luck',gift:'โชค +10',say:['วางเดิมพันว่าท่านจะรอดเดือนนี้','ทอยลูกเต๋าอยู่เงียบ ๆ']},
 {id:'judge',n:'ผู้พิพากษาเงียบ',like:'good',gift:'ได้ชื่อเสียงเพิ่มสองเท่า',say:['บันทึกการกระทำของท่านไว้','ไม่พอใจกับคนที่ทิ้งเพื่อน']},
 {id:'serpent',n:'อสรพิษแห่งเหวลึก',like:'evil',gift:'พลังต่อสู้เพิ่ม 25% แต่กรรมลดทุกเดือน',say:['กระซิบว่าคนอื่นเป็นแค่บันได','รอวันที่ท่านตกลงมา']}];
const GATE_MODS=[{n:'ปกติ',d:1,r:1,w:65,pc:'blue'},{n:'เกตคู่',d:1.3,r:1.6,w:12,pc:'blue',twin:1},{n:'หมอกหนา',d:1.15,r:1.3,w:10,pc:'mist'},
 {n:'เกตแดง',d:1.6,r:3,w:5,red:1,pc:'red'},{n:'เกตที่หลับใหล',d:.8,r:.7,w:5,pc:'dim'},{n:'เกตทองคำ',d:1.1,r:2.2,w:3,pc:'gold'}];
const MON_BY_RANK=[['slime_g','slime_b'],['slime_r','skel_w'],['skel_s','skel_a'],['wolf_w','skel_w'],['wolf_b','skel_a'],['wolf_r']];
const MON_N={slime_g:'สไลม์เขียว',slime_b:'สไลม์น้ำ',slime_r:'สไลม์เพลิง',skel_w:'โครงกระดูกนักรบ',skel_s:'โครงกระดูกทวน',skel_a:'โครงกระดูกนักธนู',wolf_w:'มนุษย์หมาป่าขาว',wolf_b:'มนุษย์หมาป่าดำ',wolf_r:'มนุษย์หมาป่าเลือด'};
const WORLDS=['w_forest','w_green','w_snow','w_mount','w_autumn','w_desert','w_rocks','w_ruin'];
const WORLD_N={w_forest:'ป่าราตรี',w_green:'ป่าดึกดำบรรพ์',w_snow:'ป่าหิมะ',w_mount:'ภูเขามืด',w_autumn:'ป่าใบไม้แดง',w_desert:'ทะเลทราย',w_rocks:'เกาะหินลอย',w_ruin:'สถานีร้าง',gatered:'ดินแดนสีเลือด',tower:'หอคอย'};
const WORLD_PC={w_forest:'green',w_green:'green',w_snow:'ice',w_mount:'violet',w_autumn:'amber',w_desert:'sand',w_rocks:'blue',w_ruin:'rust'};
const SHOP=[{id:'potion',n:'ยาฟื้นพลัง',d:'ฟื้นพลังชีวิตเต็ม',c:3},{id:'fruit',n:'ผลไม้ดาว',d:'ค่าพลังสุ่ม +3',c:8},{id:'mark',n:'ตราสัญญาชีวิต',d:'รอดตายได้ 1 ครั้ง',c:20},{id:'years',n:'น้ำค้างแห่งกาล',d:'อายุขัย +5 ปี',c:30}];
const WEAPONS=[{n:'มีดสั้นเหล็ก',p:12,c:150},{n:'อาวุธมานาเกรด D',p:30,c:600},{n:'อาวุธผลึกเกรด C',p:70,c:2200},{n:'อาวุธเขี้ยวอสูรเกรด B',p:150,c:7000},{n:'อาวุธเงาจันทร์เกรด A',p:300,c:20000},{n:'อาวุธไร้นามเกรด S',p:600,c:70000}];
const ARMORS=[{n:'เสื้อหนังกันมีด',h:40,c:120},{n:'เกราะเบาเกรด D',h:110,c:550},{n:'เกราะผลึกเกรด C',h:260,c:2000},{n:'เกราะเกล็ดอสูรเกรด B',h:550,c:6500},{n:'เกราะเงาจันทร์เกรด A',h:1100,c:19000},{n:'เกราะไร้นามเกรด S',h:2400,c:65000}];
const TITLES=[
 {id:'red',n:'ผู้รอดจากเกตแดง'},{id:'hero',n:'วีรชนประจำย่าน'},{id:'top',n:'ที่หนึ่งของรุ่น'},
 {id:'tower30',n:'นักไต่หอคอย',c:p=>p.best>=30},{id:'rich',n:'เศรษฐีหินมานา',c:p=>p.gold>=30000},{id:'chosen',n:'ผู้ถูกดวงดาวเลือก',c:p=>!!p.sponsor},
 {id:'saint',n:'นักบุญแห่งสมาคม',c:p=>p.karma>=60},{id:'demon',n:'ฮันเตอร์ปีศาจ',c:p=>p.karma<=-60},{id:'star',n:'ดาราข่าวเช้า',c:p=>p.fame>=150},{id:'rankS',n:'จุดสูงสุดของมนุษย์',c:p=>p.rank===5}];
const RARE=['ธรรมดา','ไม่ธรรมดา','หายาก','หายากมาก','ชะตากรรม'];
const DIFF={sure:[-999,'แน่นอน'],easy:[10,'ง่าย'],mid:[22,'ปานกลาง'],hard:[36,'ยาก'],ext:[55,'ยากมาก']};
const NAMES_M=['ธาม','คิน','ภูผา','วายุ','ตะวัน','ศิลา','พายุ','กันต์','เมฆา','ราม','ชนะ','ภาคิน','ก้อง','นที'];
const NAMES_F=['รินรดา','พิม','ณิชา','ข้าวหอม','ดาริน','ใบเฟิร์น','มีนา','แพรวา','จันทร์','ลลิน','ขวัญ','ปราง','ฟ้าใส','อิงดาว'];
const SUR=['ศรีวงศ์','ทองดี','แสงเพชร','รัตนกุล','วงศ์ใหญ่','ชัยมงคล','บุญมา','สุขสวัสดิ์'];

// =============== ตัวช่วย ===============
let RNG=Math.random;
const rnd=(a,b)=>a+RNG()*(b-a), ri=(a,b)=>Math.floor(rnd(a,b+1)), pick=a=>a[Math.floor(RNG()*a.length)];
const wpick=(arr,w)=>{let s=w.reduce((x,y)=>x+y,0),r=RNG()*s;for(let i=0;i<arr.length;i++){if((r-=w[i])<0)return arr[i]}return arr[arr.length-1]};
const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const star=id=>STARS.find(s=>s.id===id), cls=()=>CLASSES.find(c=>c.id===P.cls);
let P=null, META={legacy:0,lives:0,best:null}, PENDING=[];
const ageY=p=>Math.floor(p.m/12), mon=p=>p.m%12;
const SEASON=m=>[3,4,5].includes(m%12)?'spring':[6,7,8,9].includes(m%12)?'rain':[10,11].includes(m%12)?'autumn':'winter';
const SEASON_N={spring:'ฤดูร้อน',rain:'ฤดูฝน',autumn:'ปลายฝนต้นหนาว',winter:'ฤดูหนาว'};
const person=id=>P.people.find(x=>x.id===id);
const pn=id=>{const x=person(id);return x?`${x.n} (${x.role})`:''};
const pname=id=>person(id)?.n||'';

function mkPerson(role,sex,extra={}){
 const ids=sex==='f'?['g1','g2','g3']:['m1','m2','m3'];
 const p={id:'p'+(P.pid=(P.pid||0)+1),n:pick(sex==='f'?NAMES_F:NAMES_M),sex,role,look:randomLook(sex),tint:0,aff:ri(20,60),alive:true,hunter:false,rank:-1,...extra};
 P.people.push(p);return p;
}
function newLife(name,sex,look,tint){
 const p={name,sex,look,tint:tint||0,m:15*12,life:ri(72,92),stage:'school',path:null,rank:-1,cls:null,lvl:1,exp:0,
  str:ri(14,26),agi:ri(14,26),int:ri(14,26),vit:ri(14,26),cha:ri(14,26),luk:ri(10,30),
  gold:200,fame:0,karma:0,coin:0,favor:{},sponsor:null,mark:0,wep:-1,arm:-1,titles:[],tr:{brave:0,kind:0,dili:0,loyal:0},
  floor:0,best:0,guild:null,alive:true,log:[],year:{acts:{},d:{}},q:[],flags:{},people:[],party:[],place:'home',
  sys:RNG()<.03,gates:[],gateDone:false,towerDone:false,scen:null,talk:null,cool:0};
 STARS.forEach(s=>p.favor[s.id]=0);
 const L=Math.min(META.legacy,30); for(let i=0;i<L;i++)p[pick(STATS)]++;
 P=p; p.hp=maxHp(p);
 const fam=pick(['ครอบครัวชนชั้นกลาง','ครอบครัวยากจน','ครอบครัวพ่อค้า','ครอบครัวฮันเตอร์เกษียณ']);p.family=fam;
 if(fam==='ครอบครัวยากจน')p.gold=40; if(fam==='ครอบครัวพ่อค้า')p.gold=600;
 mkPerson('แม่','f',{aff:ri(60,85)});mkPerson('พ่อ','m',{aff:ri(50,85),hunter:fam==='ครอบครัวฮันเตอร์เกษียณ'});
 const sib=mkPerson(RNG()<.5?'น้องสาว':'น้องชาย',RNG()<.5?'f':'m',{aff:ri(50,80)});sib.sex=sib.role==='น้องสาว'?'f':'m';sib.look=pick(sib.sex==='f'?['g1','g2','g3']:['m1','m2','m3']);
 const bf=mkPerson('เพื่อนสนิท',RNG()<.5?'f':'m',{aff:ri(55,75)});p.flags.bf=bf.id;
 log(`${p.name} อายุ 15 ปี นักเรียน ม.4 โรงเรียนมัธยมฮันนัม เกิดใน${fam}`,'','home');
 log(`โลกนี้มีเกตเปิดขึ้นมาได้ 20 ปีแล้ว คนที่ตื่นพลังเรียกว่าฮันเตอร์ ส่วนใหญ่ตื่นพลังตอนอายุ 18`,'mut');
 if(L)log(`ความทรงจำจากชีวิตก่อนไหลกลับมา ค่าพลังรวม +${L}`,'c-star');
 schedule('pathSchool',0);
 return p;
}
const maxHp=p=>Math.round((60+p.vit*6+p.lvl*5+(p.arm>=0?ARMORS[p.arm].h:0))*(1+(p.mul?.hp||0)));
const expNeed=p=>Math.floor(60*Math.pow(p.lvl,1.45));
function log(t,c='',sc){P.log.unshift({y:ageY(P),mo:mon(P),t,c});if(sc)P.scene=sc;if(P.log.length>400)P.log.length=400}
function luk(p){return p.luk+(p.sponsor==='gambler'?10:0)}
function power(p){
 if(p.rank<0)return Math.round((p.str+p.agi+p.vit)*.6);
 const c=CLASSES.find(x=>x.id===p.cls);
 let v=p[c.m]*1.5+(p.str+p.agi+p.int+p.vit)*.4+p.lvl*3+p.rank*40+(p.mana||0)*.8+(p.wep>=0?WEAPONS[p.wep].p:0);
 v+=P.party.reduce((s,id)=>{const x=person(id);return s+(x&&x.alive?20+x.rank*25+x.aff*.2:0)},0);
 if(p.sponsor==='flame')v*=1.15; if(p.sponsor==='serpent')v*=1.25;
 if(ageY(p)>50)v*=Math.max(.35,1-(ageY(p)-50)*.015);
 return Math.max(1,Math.round(v));
}
const winChance=diff=>{const r=power(P)/diff;return clamp(1/(1+Math.pow(1/r,3))+luk(P)*.002,.02,.98)};
const deathRisk=diff=>{const r=power(P)/diff;return .35/Math.pow(r,1.5)*1.2*1.5*maxHp(P)>P.hp*.9};
function addFavor(like,n){STARS.filter(s=>s.like===like).forEach(s=>{P.favor[s.id]+=n})}
function trait(k,v){P.tr[k]=clamp(P.tr[k]+v,-100,100)}
// ใช้ผลลัพธ์และคืนข้อความ (กาย+1, เงิน+50)
function fx(d){
 if(!d)return '';const out=[];
 for(const k in d){const v=d[k];if(!v)continue;
  if(k==='aff'){for(const [id,x] of v){const p=person(id);if(p){p.aff=clamp(p.aff+x,-100,100);out.push(`สนิท${x>0?'+':''}${x}`)}}continue}
  if(k==='tr'){for(const t in v)trait(t,v[t]);continue}
  if(k==='fav'){for(const t in v)addFavor(t,v[t]);continue}
  if(k==='hp'){if(v<0){if(d.cause)hurt(-v,d.cause);else scratch(-v)}else heal(v/maxHp(P));out.push(`พลังชีวิต${v>0?'+':''}${v}`);continue}
  if(k==='exp'){gainExp(v);out.push(`EXP+${v}`);continue}
  if(k==='fame'){addFame(v);out.push(`ชื่อเสียง${v>0?'+':''}${v}`);continue}
  if(k==='cause')continue;
  if(k in SN){const v2=k==='gold'&&v>0?Math.round(v*(1+(P.mul?.gold||0))):v;P[k]+=v2;if(k==='gold'&&P.gold<0)P.gold=0;out.push(`${SN[k]}${v2>0?'+':''}${v2}`)}
 }
 return out.length?` (${out.join(', ')})`:'';
}
function heal(f){f*=1+(P.mul?.heal||0);P.hp=Math.min(maxHp(P),Math.round(P.hp+maxHp(P)*f))}
function scratch(d){P.hp=Math.max(1,P.hp-Math.round(d))}
function hurt(d,cause){P.hp-=Math.round(d);if(P.hp<=0){if(P.mark){P.mark--;P.hp=1;log('ตราสัญญาชีวิตแตกออก ท่านรอดมาได้อย่างหวุดหวิด','c-star');return}die(cause)}}
function gainExp(n){
 if(P.rank<0)return;if(P.sponsor==='sage')n*=1.3;n*=1+(P.mul?.exp||0);n=Math.round(Math.min(n,expNeed(P)*2));P.exp+=n;
 while(P.exp>=expNeed(P)){P.exp-=expNeed(P);P.lvl++;const c=cls();P[c.m]+=2;P[pick(['str','agi','int','vit'])]+=1;
  log(`เลเวลอัป ตอนนี้เลเวล ${P.lvl}`,'c-good');if(P.sys){P[pick(STATS)]++;log('[ระบบ] ได้รับแต้มค่าพลังเพิ่ม 1','c-sys')}}
}
function addFame(n){if(P.sponsor==='judge'&&n>0)n*=2;if(n>0)n=Math.round(n*(1+(P.mul?.fame||0)));P.fame=Math.max(0,P.fame+n)}
function title(id){if(P.titles.includes(id))return;P.titles.push(id);log(`ผู้คนเริ่มเรียกท่านว่า「${TITLES.find(t=>t.id===id).n}」`,'c-gold')}
function schedule(k,after,data){P.q.push({k,due:P.m+after,data:data||{}})}
function say(who,line,sc){P.talk={who,line,until:P.m+1};if(sc)P.scene=sc}

// =============== ระบบเหตุการณ์ ===============
// ev = {title, rare, chain, text, sc, who, opts:[{t, chk:[stat,diff], fight:{diff,mon,world}, cost:{gold}, warn, need, ok:{r,d,then}, no:{r,d,then}}]}
function ask(ev){PENDING.push(ev)}
function chance(o){
 if(o.fight)return winChance(o.fight.diff);
 if(!o.chk)return 1;const [s,df]=o.chk;if(df==='sure')return 1;
 const v=s==='luk'?luk(P):P[s],off=P.rank>=0?18+P.rank*12:0;return clamp(.5+(v-DIFF[df][0]-off)/30+(P.chk?.[s]||0),.05,.97);
}
function optInfo(o){
 const r=[];
 if(o.chk)r.push(`${SN[o.chk[0]]} · ${DIFF[o.chk[1]][1]} (${Math.round(chance(o)*100)}%)`);
 if(o.fight)r.push(`ต่อสู้ · โอกาสชนะ ${Math.round(chance(o)*100)}%`);
 if(o.cost)r.push(`ใช้เงิน ${o.cost.gold}`);
 if(o.warn)r.push('⚠ '+o.warn);
 if(o.fight&&!o.fight.safe&&deathRisk(o.fight.diff))r.push('☠ อาจตาย');
 const nd=o.no&&typeof o.no==='object'&&o.no.d;if(nd&&nd.cause&&nd.hp&&-nd.hp>=P.hp*.8)r.push('☠ อาจตาย');
 return r;
}
const canPick=o=>(!o.cost||P.gold>=o.cost.gold)&&(!o.need||o.need());
function answer(i){
 const ev=PENDING.shift();let o=ev.opts[i];
 if(i==='fate'||o===undefined){const ok=ev.opts.filter(canPick);o=pick(ok.length?ok:ev.opts)}
 if(!canPick(o)){PENDING.unshift(ev);return}
 if(o.cost)P.gold-=o.cost.gold;
 let pass=RNG()<chance(o);
 if(o.fight){const f=fight(o.fight.diff);pass=f.ok;P.lastFight={mon:o.fight.mon||pick(MON_BY_RANK[Math.max(0,P.rank)]),win:f.ok,ratio:f.ratio,boss:!!o.fight.boss,world:o.fight.world||P.scene||'city',foe:o.fight.foe};
  if(f.ok||o.fight.safe)scratch(f.dmg*.5);else hurt(f.dmg*.8,o.fight.cause||ev.title)}
 const res=typeof (pass?o.ok:(o.no||o.ok))==='function'?(pass?o.ok:(o.no||o.ok))():(pass?o.ok:(o.no||o.ok))||{};
 const dtx=fx(res.d);
 if(ev.who&&res.line)say(ev.who,res.line);
 if(P.alive)log(`${ev.title}: ${o.t} → ${res.r||''}${dtx}`,res.c||(o.chk||o.fight?(pass?'c-good':'c-bad'):''),res.sc);
 if(res.then)res.then();
}

function fireE(){const st=P.stage;const pool=E.filter(e=>(e.st===st||e.st==='any')&&!(e.once&&P.flags['o_'+e.once]));
 const w=pool.map(e=>(e.w||1)*(e.pl===P.place?3:1)*(e.pa===P.path?3:1));const e=wpick(pool,w);
 if(e){const d=e.fn();if(!d.c||d.c()){if(e.once)P.flags['o_'+e.once]=1;if(e.pl&&!d.sc)d.sc=e.pl;ask(d);return true}}return false}
// --- เหตุการณ์ที่ให้เลือก (st: school/hunter/any, pl: สถานที่ที่ทำให้เกิดบ่อยขึ้น, pa: วิถีที่ทำให้เกิดบ่อยขึ้น) ---
const E=[];
const ev=(meta,fn)=>E.push({...meta,fn,src:fn.toString()});
const bf=()=>P.flags.bf, rv=()=>P.flags.rival;
// ---- ช่วงเรียน ----
ev({st:'school',pl:'school',pa:'study',w:3},()=>({title:'สอบกลางภาค',sc:'school',text:'ข้อสอบคณิตศาสตร์ยากกว่าที่คิด เพื่อนข้าง ๆ เลื่อนกระดาษคำตอบมาให้ดูครึ่งแผ่น ครูกำลังหันหลังเขียนกระดาน',opts:[
 {t:'ตั้งใจทำเอง',chk:['int','mid'],ok:{r:'ทำได้เกือบเต็ม ครูชมหน้าห้อง',d:{int:2,fame:1,tr:{dili:5}}},no:{r:'คะแนนกลาง ๆ แต่ภูมิใจที่ทำเอง',d:{int:1,tr:{dili:3}}}},
 {t:'แอบลอกคำตอบ',chk:['agi','mid'],ok:{r:'ได้คะแนนสูงโดยไม่มีใครรู้',d:{tr:{loyal:-5}}},no:{r:'ครูจับได้ ถูกเรียกพบผู้ปกครอง',d:{cha:-1,tr:{loyal:-5}}}},
 {t:'ส่งกระดาษเปล่าแล้วนอน',ok:{r:'ตื่นมาอีกทีห้องว่างแล้ว',d:{vit:1,tr:{dili:-8}}}}]}));
ev({st:'school',pl:'school',w:2,once:'club'},()=>({title:'ชมรมเปิดรับสมัคร',rare:1,sc:'school',text:'ต้นเทอมแต่ละชมรมตั้งโต๊ะเรียกสมาชิกเต็มโถงอาคาร ชมรมไหนก็ได้เลือกแค่ชมรมเดียว',opts:[
 {t:'ชมรมเคนโด้',ok:{r:'ได้ดาบไม้มาหนึ่งเล่ม ซ้อมจนมือพอง',d:{str:3},then:()=>P.flags.club='kendo'}},
 {t:'ชมรมยิงธนู',ok:{r:'ยิงเข้าเป้าตั้งแต่ลูกแรก รุ่นพี่ตาโต',d:{agi:3},then:()=>P.flags.club='archery'}},
 {t:'ชมรมวิทยาศาสตร์ที่ศึกษาเกต',ok:{r:'ได้จับเศษแกนอสูรของจริงเป็นครั้งแรก',d:{int:3},then:()=>P.flags.club='science'}},
 {t:'ชมรมอาสาพยาบาล',ok:{r:'เรียนปฐมพยาบาลจนพันแผลได้คล่อง',d:{vit:2,cha:1,tr:{kind:5}},then:()=>P.flags.club='nurse'}}]}));
ev({st:'school',pl:'school',w:2,once:'bully',c:()=>!P.flags.rival},()=>{const r=mkPerson('คู่อริ',RNG()<.5?'m':'f',{aff:-20});P.flags.rival=r.id;return {title:'ถูกลูกคนรวยเหยียดหยาม',rare:1,chain:'คู่อริ',who:r.id,sc:'school',text:`${r.n} ลูกชายเจ้าของบริษัทอุปกรณ์ฮันเตอร์ เทนมใส่กระเป๋าท่านต่อหน้าทั้งห้อง แล้วหัวเราะว่า "คนจน ๆ อย่างแกตื่นพลังได้ก็แค่แรงก์ E"`,opts:[
 {t:'ต่อยกลับ',chk:['str','mid'],ok:{r:`${r.n}ล้มก้นจ้ำเบ้า ทั้งห้องเงียบกริบ`,d:{str:1,fame:2,tr:{brave:8}},line:'แก...จำไว้เลย'},no:{r:'ท่านถูกเพื่อนของเขารุมจนเลือดกำเดาไหล',d:{hp:-15,tr:{brave:5}},line:'อ่อนแอจริง ๆ'}},
 {t:'ก้มหน้าเก็บของ',ok:{r:'ท่านกลืนความอายไว้ทั้งวัน',d:{vit:1,tr:{brave:-5}},line:'ฮ่า ๆ ขี้ขลาด'}},
 {t:'จดจำไว้ แล้วสักวันจะเอาคืน',ok:{r:'ท่านไม่พูดอะไร แต่จ้องหน้าเขานานจนเขาหลบตาก่อน',d:{tr:{brave:3}},then:()=>schedule('rival1',ri(18,30))}},
 {t:'ไปฟ้องครูประจำชั้น',chk:['cha','easy'],ok:{r:'ครูเรียกเขาไปตักเตือน แต่เขามองท่านด้วยสายตาแค้น',d:{tr:{loyal:3}}},no:{r:'ครูบอกว่าเป็นเรื่องเด็ก ๆ อย่าคิดมาก',d:{}}}]}});
ev({st:'school',pa:'social',w:2,once:'letter'},()=>({title:'จดหมายในล็อกเกอร์',rare:1,sc:'school',text:'มีซองสีฟ้าเสียบอยู่ในล็อกเกอร์ ข้างในเขียนว่า "หลังเลิกเรียน ดาดฟ้า" ไม่ได้ลงชื่อ',opts:[
 {t:'ขึ้นไปตามนัด',ok:()=>{const x=mkPerson('คนที่แอบชอบ',P.sex==='f'?'m':'f',{aff:60});return {r:`คนที่รออยู่คือ${x.n} รุ่นเดียวกันห้องข้าง ๆ หน้าแดงจนพูดไม่ออก`,d:{cha:2}}}},
 {t:'พาเพื่อนสนิทไปด้วย',ok:{r:`${pname(bf())}แซวท่านทั้งทางจนลืมไปว่ามานัดใคร คนที่รอหนีไปก่อน`,d:{aff:[[bf(),5]]}}},
 {t:'ไม่ไป',ok:{r:'วันต่อมาซองฟ้าหายไปจากล็อกเกอร์',d:{tr:{brave:-2}}}}]}));
ev({st:'school',pa:'work',w:3},()=>({title:'โจรในร้านสะดวกซื้อ',rare:1,sc:'city',text:'กะดึกที่ร้านสะดวกซื้อ ชายสวมหมวกไหมพรมยื่นมีดข้ามเคาน์เตอร์ สั่งให้เปิดลิ้นชักเงิน',opts:[
 {t:'แย่งมีด',chk:['agi','hard'],ok:{r:'ท่านบิดข้อมือเขาจนมีดหล่น ตำรวจมาถึงพอดี เจ้าของร้านให้โบนัส',d:{gold:120,fame:3,tr:{brave:10}}},no:{r:'มีดเฉี่ยวแขนเป็นแผลยาว',d:{hp:-25,tr:{brave:6}}}},
 {t:'ส่งเงินให้แล้วกดปุ่มฉุกเฉิน',chk:['int','easy'],ok:{r:'ตำรวจจับเขาได้ที่ปากซอย',d:{int:1}},no:{r:'ปุ่มเสีย เขาหนีไปได้ เจ้าของร้านหักเงินเดือน',d:{gold:-60}}},
 {t:'ชวนคุย ถามว่าเดือดร้อนเรื่องอะไร',chk:['cha','mid'],ok:{r:'เขาร้องไห้ บอกว่าลูกป่วยหนัก แล้ววางมีดเดินออกไปเอง',d:{cha:2,karma:4,tr:{kind:8}}},no:{r:'เขาตะคอกให้หุบปากแล้วกวาดเงินไป',d:{gold:-40}}}]}));
ev({st:'school',w:2,once:'cat'},()=>({title:'แมวดำใต้สะพาน',rare:1,chain:'แมวดำ',sc:'city',text:'ลูกแมวดำตัวหนึ่งขาเจ็บ นอนตัวสั่นอยู่ใต้สะพานลอย ดวงตาของมันสีม่วงแปลก ๆ',opts:[
 {t:'อุ้มกลับบ้านไปรักษา',ok:{r:'แม่บ่นแต่ก็ยอมให้เลี้ยง ท่านตั้งชื่อมันว่า "ราตรี"',d:{karma:3,tr:{kind:8}},then:()=>{P.flags.cat=1;schedule('cat2',ri(30,40))}}},
 {t:'ซื้อนมให้แล้วจากไป',ok:{r:'มันมองตามหลังท่านจนลับตา',d:{karma:1}}},
 {t:'เดินผ่านไป',ok:{r:'คืนนั้นท่านฝันถึงดวงตาสีม่วง',d:{tr:{kind:-3}}}}]}));
ev({st:'school',pl:'school',w:2,once:'festival'},()=>({title:'งานโรงเรียน',sc:'school',text:'ห้องของท่านต้องเลือกว่าจะจัดอะไรในงานโรงเรียนปลายปี ทุกคนหันมามองท่าน',opts:[
 {t:'เสนอบ้านผีสิงธีมเกตแดง',chk:['int','mid'],ok:{r:'คิวยาวที่สุดในงาน ห้องได้รางวัลที่หนึ่ง',d:{fame:3,cha:1},then:()=>title('top')},no:{r:'ฉากพังกลางงาน แต่ทุกคนหัวเราะกันจนท้องแข็ง',d:{cha:1}}},
 {t:'ร้านกาแฟคอสเพลย์ฮันเตอร์',chk:['cha','mid'],ok:{r:'ท่านแต่งเป็นฮันเตอร์แรงก์ S ลูกค้าขอถ่ายรูปไม่หยุด',d:{cha:3,gold:80}},no:{r:'ชุดคับเกินไปจนต้องยืนนิ่งทั้งวัน',d:{cha:1}}},
 {t:'ขอเป็นฝ่ายแบกของ',ok:{r:'แขนล้าแต่เพื่อนทุกคนขอบคุณ',d:{str:2,tr:{loyal:4}}}}]}));
ev({st:'school',pl:'home',w:2},()=>({title:'พ่อกับแม่ทะเลาะกัน',sc:'home',text:'พ่ออยากเอาเงินเก็บไปลงทุนกับเพื่อนที่เปิดร้านขายแกนอสูร แม่บอกว่าเงินก้อนนั้นคือค่าเรียนของลูก ทั้งคู่หันมาถามความเห็นท่าน',opts:[
 {t:'อยู่ข้างแม่',ok:{r:'พ่อเงียบไปหลายวัน',d:{aff:[[P.people[0].id,8],[P.people[1].id,-10]]}}},
 {t:'อยู่ข้างพ่อ',ok:()=>RNG()<.5?{r:'ร้านของเพื่อนพ่อขายดี พ่อแบ่งกำไรให้ท่านด้วย',d:{gold:150,aff:[[P.people[1].id,8]]}}:{r:'ร้านเจ๊งในสามเดือน บ้านเงียบไปทั้งปี',d:{gold:-50,aff:[[P.people[0].id,-8]]}}},
 {t:'บอกว่าจะหาเงินค่าเรียนเอง',chk:['cha','easy'],ok:{r:'ทั้งคู่หยุดทะเลาะแล้วหันมากอดท่าน',d:{aff:[[P.people[0].id,5],[P.people[1].id,5]],tr:{dili:5}}},no:{r:'แม่บอกว่าเด็กไม่ต้องยุ่ง',d:{}}}]}));
ev({st:'school',w:2},()=>({title:'เพื่อนชวนแอบเข้าเขตเกต',rare:1,who:bf(),sc:'gatezone',text:`${pname(bf())}กระซิบว่ารั้วกั้นเกตแรงก์ E หลังตลาดมีช่องโหว่ อยากเข้าไปถ่ายคลิปลงโซเชียล`,opts:[
 {t:'ไปด้วย',chk:['luk','mid'],warn:'คนธรรมดาเจอสัตว์อสูรอาจบาดเจ็บหนัก',ok:{r:'ทั้งคู่ได้คลิปหน้าเกตเรืองแสง ยอดวิวทะลุแสน',d:{fame:4,aff:[[bf(),6]],tr:{brave:6}},line:'ไวรัลแล้วเว้ย!'},no:{r:'สไลม์ตัวหนึ่งพุ่งออกมา ท่านลากเพื่อนหนีจนแขนถลอก',d:{hp:-30,aff:[[bf(),10]],tr:{brave:6}},line:'ขอบใจนะ...'}},
 {t:'ห้ามเพื่อน',chk:['cha','mid'],ok:{r:'เพื่อนยอมกลับบ้าน',d:{aff:[[bf(),2]],tr:{loyal:3}}},no:{r:'เพื่อนไปคนเดียว กลับมาพร้อมแผลที่ขา',d:{aff:[[bf(),-5]]}}},
 {t:'แจ้งยามสมาคม',ok:{r:'ยามปิดช่องโหว่ เพื่อนโกรธท่านไปหนึ่งสัปดาห์',d:{karma:2,aff:[[bf(),-6]]}}}]}));
ev({st:'school',pa:'sport',w:3},()=>({title:'แข่งกรีฑาระดับเขต',sc:'train',text:'ท่านถูกส่งลงแข่งวิ่ง 400 เมตรแทนเพื่อนที่ขาพลิก แมวมองจากสมาคมนั่งอยู่บนอัฒจันทร์',opts:[
 {t:'ออกตัวแรงตั้งแต่ต้น',chk:['agi','mid'],ok:{r:'เข้าเส้นชัยเป็นอันดับหนึ่ง แมวมองจดชื่อท่านไว้',d:{agi:2,fame:3,tr:{brave:4}}},no:{r:'หมดแรงช่วงโค้งสุดท้าย ได้ที่ห้า',d:{vit:1}}},
 {t:'เก็บแรงไว้ช่วงท้าย',chk:['vit','mid'],ok:{r:'แซงสามคนในร้อยเมตรสุดท้าย ได้ที่สอง',d:{vit:2,fame:2}},no:{r:'แซงไม่ทัน ได้ที่สี่',d:{vit:1}}},
 {t:'วิ่งเป็นเพื่อนคนที่ล้ม',ok:{r:'ไม่ได้เหรียญแต่ภาพนั้นถูกแชร์ทั่วเมือง',d:{cha:2,karma:3,tr:{kind:6}}}}]}));
ev({st:'school',pa:'study',w:2,once:'lib'},()=>({title:'ห้องสมุดตอนดึก',rare:1,sc:'school',text:'ท่านเจอหนังสือเล่มบาง ๆ ไม่มีชื่อผู้แต่ง ชื่อเรื่องว่า "บันทึกก่อนเกตแรกเปิด" ซ่อนอยู่หลังชั้นวาง',opts:[
 {t:'อ่านจนจบในคืนเดียว',chk:['int','hard'],ok:{r:'เนื้อหาบอกว่าเกตเปิดตามจังหวะของดวงดาว ท่านจดไว้ทุกบรรทัด',d:{int:3,coin:1},then:()=>P.flags.lore=1},no:{r:'ตัวอักษรเลือนจนอ่านไม่ออก ปวดหัวไปสามวัน',d:{int:1}}},
 {t:'ยืมกลับบ้าน',ok:{r:'วันรุ่งขึ้นหนังสือหายไปจากกระเป๋า',d:{luk:1}}},
 {t:'ส่งให้บรรณารักษ์',ok:{r:'บรรณารักษ์หน้าซีดแล้วรีบเก็บเข้าห้องด้านใน',d:{karma:1}}}]}));
ev({st:'school',w:1,once:'scout'},()=>({title:'ข่าวลือเรื่องแมวมอง',sc:'city',text:'มีข่าวว่ากิลด์ใหญ่ส่งคนมาดูตัวนักเรียน ม.6 ที่มีแววจะตื่นพลังแรงก์สูง หลายคนเริ่มไปฟิตเนส',opts:[
 {t:'ฝึกหนักทุกเช้า',ok:{r:'กล้ามเนื้อเริ่มแน่น',d:{str:2,vit:1,tr:{dili:6}}}},
 {t:'อ่านเรื่องฮันเตอร์ให้มากที่สุด',ok:{r:'ท่านรู้ชื่อมอนสเตอร์ทุกตัวในฐานข้อมูลสมาคม',d:{int:2}}},
 {t:'ไม่สน ตื่นได้ก็ตื่น',ok:{r:'ชีวิตยังเหมือนเดิม',d:{luk:1,tr:{dili:-3}}}}]}));
// ---- หลังตื่นพลัง ----
ev({st:'hunter',pl:'guild',w:3},()=>({title:'ปาร์ตี้แปลกหน้าชวนลงเกต',sc:'guild',text:'ฮันเตอร์สามคนชวนท่านลงเกตที่สูงกว่าแรงก์หนึ่งขั้น แต่ขอส่วนแบ่ง 70%',opts:[
 {t:'ไปด้วย',fight:{diff:GATE_DIFF[Math.min(5,P.rank+1)]*.8,world:pick(WORLDS)},ok:()=>{const g=Math.round(GATE_DIFF[Math.min(5,P.rank+1)]*1.2);return {r:`ทีมเคลียร์เกตได้ ส่วนของท่านคือ ${g} ทอง`,d:{gold:g,exp:GATE_DIFF[P.rank]*.6,fav:{risk:5}}}},no:{r:'ทีมแตกกระเจิง ท่านหนีออกมาได้',d:{}}},
 {t:'ต่อรองขอ 50%',chk:['cha','hard'],ok:{r:'หัวหน้าทีมยอม แต่สีหน้าไม่พอใจ',d:{gold:GATE_DIFF[P.rank]*2|0,exp:GATE_DIFF[P.rank]*.5}},no:{r:'พวกเขาหัวเราะแล้วไปชวนคนอื่น',d:{}}},
 {t:'ปฏิเสธ',ok:{r:'สัปดาห์ต่อมาได้ข่าวว่าทีมนั้นกลับมาไม่ครบ',d:{luk:1}}}]}));
ev({st:'hunter',pl:'gatezone',pa:'hunt',w:3},()=>({title:'เพื่อนร่วมทีมกับหินมานา',rare:1,sc:'dungeon',text:'เพื่อนร่วมทีมบาดเจ็บหนักอยู่กลางดันเจี้ยน ข้างตัวเขามีหินมานาก้อนใหญ่ ฝูงอสูรกำลังวนกลับมา',opts:[
 {t:'แบกเขาออกมา',chk:['str','mid'],ok:{r:'ท่านแบกเขาออกมาได้ ข่าวนี้แพร่ไปทั่วสมาคม',d:{fame:4,karma:8,fav:{kind:5,good:8},tr:{loyal:10,kind:6}}},no:{r:'ท่านพาเขาออกมาได้แต่โดนกรงเล็บเต็มหลัง',d:{hp:-maxHp(P)*.3|0,karma:8,fav:{good:6},tr:{loyal:10},cause:'ตายระหว่างช่วยเพื่อน'}}},
 {t:'เก็บหินแล้วทิ้งเขาไว้',ok:{r:'ไม่มีใครเห็น ยกเว้นดวงดาว',d:{gold:GATE_DIFF[P.rank]*3|0,karma:-12,fav:{evil:12,good:-10},tr:{loyal:-15,kind:-8}}}},
 {t:'ยิงพลุขอความช่วยเหลือแล้วยันไว้',fight:{diff:GATE_DIFF[P.rank]},ok:{r:'ทีมกู้ภัยมาถึงทันเวลา ทั้งคู่รอด',d:{fame:2,karma:5,tr:{brave:8}}},no:{r:'ทีมกู้ภัยมาช้า เพื่อนร่วมทีมเสียชีวิต',d:{karma:-2}}}]}));
ev({st:'hunter',pl:'city',w:2},()=>({title:'บริษัทเครื่องดื่มชูกำลัง',sc:'city',c:()=>P.fame>=10,text:'บริษัทเครื่องดื่มเสนอให้ท่านเป็นพรีเซนเตอร์ ค่าตัวสูงกว่ารายได้จากเกตสามเดือน',opts:[
 {t:'รับงาน',ok:{r:'หน้าท่านอยู่บนป้ายโฆษณาทั่วเมือง',d:{gold:250*(P.rank+1),fame:5}}},
 {t:'ขอเพิ่มค่าตัว',chk:['cha','hard'],ok:{r:'เขายอมเพิ่มให้อีกครึ่งหนึ่ง',d:{gold:380*(P.rank+1),fame:5}},no:{r:'เขาไปจ้างฮันเตอร์คนอื่นแทน',d:{}}},
 {t:'ปฏิเสธ',ok:{r:'ท่านไม่ชอบถ่ายแบบ',d:{tr:{loyal:2}}}}]}));
ev({st:'hunter',pl:'gatezone',w:2},()=>({title:'ห้องลับในดันเจี้ยน',rare:2,sc:'dungeon',text:'หลังกำแพงที่พังมีประตูหินสลักตัวอักษรที่ไม่มีใครอ่านออก ลมเย็นพัดออกมาจากร่องประตู',opts:[
 {t:'เปิดเข้าไปคนเดียว',chk:['luk','hard'],warn:'อาจมีกับดัก',ok:()=>{const k=pick(['str','agi','int','vit']);return {r:'ข้างในมีคัมภีร์สกิลเก่า',d:{[k]:4,fav:{risk:4}}}},no:{r:'กับดักลูกดอกพุ่งใส่',d:{hp:-maxHp(P)*.35|0,cause:'กับดักในห้องลับ'}}},
 {t:'ถอดรหัสตัวอักษรก่อน',chk:['int','hard'],ok:{r:'ท่านปลดกลไกได้ ได้แกนอสูรหายากมาขาย',d:{gold:GATE_DIFF[P.rank]*4|0,coin:2}},no:{r:'อ่านไม่ออก ประตูปิดตายไปเอง',d:{int:1}}},
 {t:'รายงานสมาคม',ok:{r:'สมาคมส่งทีมวิจัยมา จ่ายค่าข้อมูลให้ท่าน',d:{gold:GATE_DIFF[P.rank],karma:2}}}]}));
ev({st:'hunter',pl:'casino',pa:'dark',w:3},()=>({title:'งานขนของข้ามเกต',rare:1,sc:'casino',text:'ชายใส่สูทในบ่อนจ้างให้ขนกล่องปิดผนึกผ่านเกตแรงก์ C ไปส่งอีกฝั่ง ไม่ถามว่าข้างในมีอะไร',opts:[
 {t:'รับงาน',chk:['agi','mid'],ok:{r:'ส่งของถึงมือ ได้เงินก้อนโตใส่ซองสีดำ',d:{gold:GATE_DIFF[P.rank]*5|0,karma:-6,fav:{evil:6}}},no:{r:'ทีมตรวจของสมาคมเกือบจับได้ ท่านต้องทิ้งกล่องแล้วหนี',d:{fame:-5,karma:-4}}},
 {t:'แอบเปิดดูก่อน',chk:['luk','mid'],ok:{r:'ข้างในเป็นไข่สัตว์อสูรที่ยังมีชีวิต ท่านแจ้งสมาคม',d:{karma:6,fame:3,fav:{good:5}}},no:{r:'กล่องมีระบบป้องกัน ระเบิดเป็นควันพิษ',d:{hp:-40}}},
 {t:'ปฏิเสธ',ok:{r:'เขายิ้มแล้วจำหน้าท่านไว้',d:{}}}]}));
ev({st:'hunter',w:2,once:'dark'},()=>({title:'เสียงในความฝัน',rare:3,sc:'sky',text:'เสียงทุ้มต่ำดังขึ้นในหัว "ข้าให้พลังเจ้าได้ แลกกับเวลาของเจ้าเพียงสิบปี"',opts:[
 {t:'ตกลง',ok:{r:'พลังมืดไหลเข้าตัว ค่าพลังทุกอย่างเพิ่มขึ้น',d:{str:6,agi:6,int:6,vit:6,fav:{evil:10}},then:()=>{P.life-=10}}},
 {t:'ถามว่าเป็นใคร',chk:['int','hard'],ok:{r:'มันหัวเราะ แล้วบอกชื่อกลุ่มดาวที่ไม่มีอยู่ในบันทึกใด',d:{coin:3,int:2}},no:{r:'เสียงนั้นเงียบไปพร้อมความหนาวเย็น',d:{hp:-10}}},
 {t:'ปฏิเสธ',ok:{r:'ท่านตื่นมาพร้อมเหงื่อเต็มตัว',d:{fav:{good:4},tr:{loyal:3}}}}]}));
ev({st:'hunter',pl:'gatezone',w:2,c:()=>P.rank<4},()=>({title:'ทีมสำรวจเกตแรงก์ S',rare:3,sc:'gatezone',text:'สมาคมรับสมัครคนแบกของให้ทีมสำรวจเกตแรงก์ S ค่าจ้างสูงที่สุดที่ท่านเคยเห็น แต่ทีมก่อนกลับมาแค่ครึ่ง',opts:[
 {t:'สมัคร',fight:{diff:GATE_DIFF[5]*.5,world:'gatered',boss:true,cause:'ตายระหว่างสำรวจเกตแรงก์ S'},ok:{r:'ท่านรอดกลับมาพร้อมค่าจ้าง 5000 ทอง',d:{gold:5000,exp:400,fame:8,fav:{risk:10}}},no:{r:'ท่านหนีออกมาได้ทั้งที่เลือดท่วมตัว',d:{}}},
 {t:'สมัครเป็นหน่วยแพทย์ด้านนอก',chk:['int','mid'],ok:{r:'ท่านช่วยชีวิตคนเจ็บได้สิบกว่าคน',d:{gold:1200,karma:6,fame:4}},no:{r:'คนเจ็บเยอะเกินไป ท่านทำได้ไม่เต็มที่',d:{gold:600}}},
 {t:'ไม่สมัคร',ok:{r:'คืนนั้นกิลด์กลางประกาศรายชื่อผู้เสียชีวิตยาวเหยียด',d:{}}}]}));
ev({st:'hunter',pl:'city',w:2},()=>({title:'เสียงร้องในซอยมืด',sc:'city',text:'ฮันเตอร์นอกกฎหมายสามคนรุมรีดไถพ่อค้าแผงลอยในซอยหลังตลาด',opts:[
 {t:'เข้าไปจัดการ',fight:{diff:GATE_DIFF[P.rank]*.6,foe:'thug',safe:1},ok:{r:'พวกมันวิ่งหนีกระเจิง พ่อค้าก้มหัวขอบคุณไม่หยุด',d:{karma:5,fame:2,fav:{kind:4},tr:{brave:6}}},no:{r:'พวกมันมีหลายคนเกินไป ท่านต้องถอย',d:{tr:{brave:2}}}},
 {t:'ถ่ายคลิปแจ้งสมาคม',chk:['agi','easy'],ok:{r:'สมาคมจับได้ทั้งแก๊ง',d:{karma:3,int:1}},no:{r:'ถูกจับได้ว่าถ่ายคลิป ต้องวิ่งหนี',d:{hp:-10}}},
 {t:'เดินผ่านไป',ok:{r:'ท่านไม่อยากยุ่ง',d:{tr:{kind:-4}}}}]}));
ev({st:'hunter',pl:'hospital',w:2},()=>({title:'ผู้ป่วยไร้ญาติ',sc:'hospital',text:'เด็กหญิงที่รอดจาก Dungeon Break นอนอยู่เตียงข้าง ๆ ไม่มีใครมาเยี่ยม ค่ารักษายังค้างอยู่ก้อนใหญ่',opts:[
 {t:'จ่ายค่ารักษาให้',cost:{gold:300},ok:{r:'นางยิ้มครั้งแรกตั้งแต่เข้าโรงพยาบาล',d:{karma:8,fav:{kind:8},tr:{kind:8}}}},
 {t:'อยู่เป็นเพื่อนคุย',ok:{r:'นางเล่าว่าอยากเป็นฮันเตอร์เหมือนท่าน',d:{cha:2,karma:3}}},
 {t:'ขอย้ายเตียง',ok:{r:'ท่านอยากพักผ่อนเงียบ ๆ',d:{vit:1,tr:{kind:-3}}}}]}));
ev({st:'hunter',pa:'research',w:3},()=>({title:'แกนอสูรที่ยังเต้น',rare:2,sc:'guild',text:'แกนอสูรที่ส่งมาให้ห้องวิจัยยังเต้นเป็นจังหวะเหมือนหัวใจ หัวหน้าห้องวิจัยอยากผ่าดูทันที',opts:[
 {t:'ช่วยผ่า',chk:['int','hard'],ok:{r:'ท่านค้นพบโครงสร้างใหม่ในแกน ได้ชื่อในรายงานวิจัย',d:{int:3,fame:4,coin:3}},no:{r:'แกนระเบิดเป็นละอองพิษ',d:{hp:-35,int:1}}},
 {t:'เสนอให้รอดูว่ามันจะเติบโตเป็นอะไร',chk:['luk','mid'],ok:{r:'แกนฟักเป็นภูตแสงตัวเล็ก ๆ แล้วเกาะไหล่ท่าน',d:{luk:3,coin:2},then:()=>P.flags.pet=P.flags.pet||'ภูตแสง'},no:{r:'มันหยุดเต้นในสามวัน',d:{}}},
 {t:'แอบเอาไปขายตลาดมืด',ok:{r:'ได้เงินก้อนใหญ่ แต่ห้องวิจัยเริ่มสงสัย',d:{gold:GATE_DIFF[P.rank]*4|0,karma:-6}}}]}));
ev({st:'hunter',pa:'guild',pl:'guild',w:3},()=>({title:'ภารกิจคุ้มกันผู้ว่าการ',sc:'guild',text:'สมาคมมอบหมายให้คุ้มกันผู้ว่าการเมืองระหว่างเยี่ยมย่านเกต มีข่าวว่ากลุ่มต่อต้านฮันเตอร์จะก่อเหตุ',opts:[
 {t:'ตรวจเส้นทางล่วงหน้า',chk:['int','mid'],ok:{r:'ท่านเจอระเบิดใต้รถก่อนออกเดินทาง',d:{fame:6,gold:500}},no:{r:'ระเบิดดังกลางขบวน ผู้ว่าการรอดแต่ท่านเจ็บ',d:{hp:-30,gold:250}}},
 {t:'ยืนประกบตัวตลอดทาง',chk:['vit','mid'],ok:{r:'ท่านใช้ตัวบังกระสุนลูกหลง ผู้ว่าการจับมือขอบคุณ',d:{fame:5,gold:400,tr:{brave:5}}},no:{r:'ท่านโดนกระสุนเข้าไหล่',d:{hp:-45,gold:400}}},
 {t:'ขอเปลี่ยนเป็นงานอื่น',ok:{r:'หัวหน้าสมาคมจดชื่อท่านไว้ในแฟ้มสีเหลือง',d:{fame:-2}}}]}));
ev({st:'hunter',w:2},()=>({title:'นักข่าวขอสัมภาษณ์',sc:'city',text:'นักข่าวช่องดังขอสัมภาษณ์เรื่องเกตล่าสุดที่ท่านเคลียร์ เธอถามว่าท่านคิดอย่างไรกับฮันเตอร์ที่ทิ้งชาวบ้านระหว่าง Dungeon Break',opts:[
 {t:'ตอบตรง ๆ ว่าคนแบบนั้นไม่ควรเป็นฮันเตอร์',ok:{r:'คลิปถูกแชร์ทั่วประเทศ กิลด์ใหญ่บางแห่งไม่พอใจ',d:{fame:6,karma:2,tr:{brave:5}}}},
 {t:'ตอบกลาง ๆ',chk:['cha','easy'],ok:{r:'ทุกฝ่ายพอใจ',d:{fame:2,cha:1}},no:{r:'คำตอบฟังดูเลี่ยง คนดูไม่ชอบ',d:{fame:-1}}},
 {t:'ปฏิเสธการสัมภาษณ์',ok:{r:'ท่านเดินหนีกล้อง',d:{}}}]}));
ev({st:'hunter',pl:'casino',w:3},()=>({title:'โต๊ะเดิมพันผลการล่า',sc:'casino',text:'เจ้ามือเปิดให้แทงว่าทีมไหนจะเคลียร์เกตแดงที่เพิ่งเปิดได้ก่อน มีชื่อท่านอยู่ในกระดานด้วย',opts:[
 {t:'แทงทีมตัวเองชนะ',cost:{gold:200},chk:['luk','mid'],ok:{r:'ทีมของท่านชนะ ได้เงินคืนสามเท่า',d:{gold:600,fav:{luck:6}}},no:{r:'เสียเงินไปเปล่า ๆ',d:{fav:{luck:3}}}},
 {t:'แทงทีมคู่แข่ง',cost:{gold:200},chk:['luk','hard'],ok:{r:'คู่แข่งชนะ ท่านได้เงินแต่เพื่อนร่วมทีมมองแปลก ๆ',d:{gold:800,karma:-4}},no:{r:'เสียเงินและเสียหน้า',d:{}}},
 {t:'ไม่เล่น',ok:{r:'ท่านสั่งเครื่องดื่มแล้วนั่งฟังข่าวลือ',d:{int:1}}}]}));
ev({st:'hunter',w:2},()=>({title:'ชาวบ้านชายแดนขอความช่วยเหลือ',sc:'w_green',text:'หมู่บ้านชายแดนมีสัตว์อสูรหลุดออกจากเกตที่ไม่มีใครดูแล ชาวบ้านมีเงินจ่ายแค่ข้าวกับไข่ไก่',opts:[
 {t:'ไปช่วย',fight:{diff:GATE_DIFF[P.rank]*.7},ok:{r:'หมู่บ้านจัดงานเลี้ยงให้ท่านทั้งคืน',d:{karma:8,fame:2,fav:{kind:6,good:4}}},no:{r:'ท่านไล่มันไปได้ แต่เจ็บไม่น้อย',d:{karma:4}}},
 {t:'บอกให้ไปจ้างกิลด์',ok:{r:'ชาวบ้านมองท่านด้วยสายตาผิดหวัง',d:{karma:-2}}},
 {t:'ขอเงินค่าจ้างก่อน',chk:['cha','mid'],ok:{r:'ชาวบ้านรวมเงินกันได้ก้อนหนึ่ง',d:{gold:200,karma:-1}},no:{r:'ชาวบ้านไล่ท่านออกจากหมู่บ้าน',d:{fame:-2}}}]}));
ev({st:'hunter',w:1,once:'egg'},()=>({title:'พ่อค้าไข่สีดำ',rare:2,sc:'city',text:'พ่อค้าลึกลับเสนอขายไข่สีดำที่เต้นเป็นจังหวะ ราคา 800 ทอง',opts:[
 {t:'ซื้อ',cost:{gold:800},chk:['luk','mid'],ok:()=>{P.flags.pet=pick(['หมาป่าเงา','นกไฟ','งูผลึก']);return {r:`ไข่ฟักเป็น${P.flags.pet}ตัวเล็ก มันเดินตามท่านไปทุกที่`,d:{str:2,agi:2}}},no:{r:'ไข่แตกออกมาเป็นหินธรรมดา พ่อค้าหายไปแล้ว',d:{}}},
 {t:'ใช้สกิลประเมินของ',chk:['int','hard'],ok:{r:'ท่านรู้ว่าเป็นของปลอม แล้วแจ้งตำรวจจับ',d:{karma:3,fame:1}},no:{r:'ดูไม่ออก ท่านจึงเดินผ่านไป',d:{}}},
 {t:'ไม่ซื้อ',ok:{r:'ท่านไม่ไว้ใจพ่อค้าคนนี้',d:{}}}]}));
ev({st:'hunter',w:2},()=>{const x=person(bf());return {title:'เพื่อนเก่าที่ไม่ได้ตื่นพลัง',who:bf(),sc:'city',c:()=>x&&x.alive&&!x.hunter,text:`${x?.n} ทำงานเป็นพนักงานบริษัท นัดกินข้าวแล้วบ่นว่าชีวิตคนธรรมดาไม่มีความหมาย`,opts:[
 {t:'ชวนมาทำงานฝ่ายสนับสนุนในทีม',chk:['cha','mid'],ok:{r:'เพื่อนตาเป็นประกาย ลาออกจากงานในสัปดาห์นั้น',d:{aff:[[bf(),15]]},line:'ขอบใจนะ จะไม่ทำให้ผิดหวัง',then:()=>{x.role='ผู้จัดการทีม'}},no:{r:'เพื่อนบอกว่าไม่อยากเป็นภาระ',d:{aff:[[bf(),3]]}}},
 {t:'เลี้ยงข้าวแล้วฟังจนจบ',cost:{gold:100},ok:{r:'คืนนั้นทั้งคู่คุยกันจนร้านปิด',d:{aff:[[bf(),8]],cha:1},line:'แกยังเป็นแกเหมือนเดิม'}},
 {t:'บอกว่าตัวเองยุ่ง',ok:{r:'เพื่อนยิ้มฝืน ๆ',d:{aff:[[bf(),-8]]},line:'อือ...เข้าใจ'}}]}});
const PASSIVE=[
 {st:'school',f:()=>['ครูประจำชั้นชมการบ้านของท่านหน้าห้อง',{int:1}]},
 {st:'school',f:()=>['ท่านนั่งดูข่าวฮันเตอร์แรงก์ S ล้มบอสบนทีวีจนดึก',{int:1}]},
 {st:'school',f:()=>[`กินข้าวกลางวันกับ${pname(bf())} แบ่งไข่ดาวกันคนละครึ่ง`,{aff:[[bf(),2]]}]},
 {st:'school',f:()=>['เล่นบาสหลังเลิกเรียนจนฟ้ามืด',{str:1}]},
 {st:'school',f:()=>['โทรศัพท์ตกน้ำ ต้องเก็บเงินซื้อใหม่',{gold:-40}]},
 {st:'school',f:()=>['น้อง ๆ ในซอยมาขอให้สอนการบ้าน',{cha:1,karma:1}]},
 {st:'school',f:()=>['เครื่องวัดพลังที่โรงเรียนกะพริบแปลก ๆ ตอนท่านเดินผ่าน',{luk:1}]},
 {st:'school',f:()=>['ฝนตกหนัก ท่านเดินลุยน้ำกลับบ้าน ไข้ขึ้นสองวัน',{hp:-10}]},
 {st:'any',f:()=>{const g=ri(20,60)*(Math.max(0,P.rank)+1);return [`เจอเศษหินมานาข้างทาง ขายได้ ${g} ทอง`,{gold:g}]}},
 {st:'any',f:()=>[pick(['ข่าว: เกตแรงก์ S เปิดกลางทะเล ประเทศใกล้เคียงประกาศภาวะฉุกเฉิน','ข่าว: กิลด์ใหญ่สองแห่งแย่งสิทธิ์เกต A กันกลางเมือง','ข่าว: มีคนเห็นเงาคนยืนบนยอดหอคอย','ข่าว: ราคาหินมานาตกต่ำที่สุดในรอบ 5 ปี','ข่าว: รัฐบาลออกกฎหมายจดทะเบียนฮันเตอร์ฉบับใหม่']),null]},
 {st:'any',f:()=>['แมวจรตัวหนึ่งมานอนหน้าห้องทุกคืน',{luk:1}]},
 {st:'any',f:()=>{const x=P.people[0];return [`${x.n} (แม่) ห่อกับข้าวมาให้เต็มกล่อง`,{hp:15,aff:[[x.id,2]]}]}},
 {st:'hunter',f:()=>['ค่าซ่อมอุปกรณ์แพงกว่าที่คิด',{gold:-ri(50,150)}]},
 {st:'hunter',f:()=>['เด็กในละแวกบ้านขอลายเซ็น',{fame:1}]},
 {st:'hunter',f:()=>['ท่านอ่านบันทึกของฮันเตอร์รุ่นเก่าจนดึก',{int:1}]},
 {st:'hunter',f:()=>['ดาวตกพาดผ่านท้องฟ้า มีดาวเหรียญตกอยู่ที่ระเบียง',{coin:1}]},
 {st:'hunter',f:()=>P.flags.pet?[`${P.flags.pet}คาบหินสีรุ้งมาให้`,{luk:1}]:['ท่านนั่งดูดาวคนเดียวบนดาดฟ้า',null]},
 {st:'hunter',f:()=>['ฝึกท่าเดิมซ้ำพันครั้งจนร่างกายจำได้เอง',{[cls()?.m||'str']:1}]},
];

// --- เรื่องต่อเนื่อง (คิวตามเวลา) ---
const QUESTS={
 pathSchool:()=>ask({title:'ชีวิต ม.ปลายเริ่มต้นขึ้น',rare:0,sc:'school',text:'อีกสามปีจะถึงวันตื่นพลัง จะทุ่มเทเวลาให้กับอะไร',opts:PATHS.school.map(p=>({t:p.n,sub:p.d,ok:{r:`ท่านเลือก${p.n}`,then:()=>{P.path=p.id}}}))}),
 rival1:()=>{const r=person(rv());if(!r)return;ask({title:'คู่อริกลับมา',rare:2,chain:'คู่อริ',who:r.id,sc:P.stage==='hunter'?'guild':'school',text:`${r.n} ${P.stage==='hunter'?`ตื่นพลังเป็นแรงก์ ${RANKS[Math.max(0,P.rank)]} เหมือนกัน เขายืนขวางทางที่สมาคมแล้วยิ้มเยาะ`:'ดักรอท่านหน้าประตูโรงเรียนพร้อมลูกน้องสองคน'} "จำวันนั้นได้ไหม"`,opts:[
  {t:'ท้าดวลตัวต่อตัว',fight:{diff:P.stage==='hunter'?GATE_DIFF[P.rank]*.9:60,foe:'rival',world:P.stage==='hunter'?'train':'school',safe:1},ok:{r:`${r.n}แพ้ต่อหน้าทุกคน เขาก้มหัวขอโทษเป็นครั้งแรก`,d:{fame:5,aff:[[r.id,20]],tr:{brave:8}},line:'...ข้ายอมรับ',then:()=>schedule('rival2',ri(24,40))},no:{r:'ท่านแพ้ราบคาบ เขาเหยียบดาบไม้ของท่านหักต่อหน้าคนดู',d:{aff:[[r.id,-5]]},line:'ยังอ่อนเหมือนเดิม',then:()=>schedule('rival1',ri(18,30))}},
  {t:'ยื่นมือขอคืนดี',chk:['cha','hard'],ok:{r:'เขาชะงักไปนาน แล้วจับมือท่านอย่างเก้อ ๆ',d:{aff:[[r.id,30]],karma:4,tr:{kind:6}},line:'...เรื่องเก่าก็ช่างมัน',then:()=>schedule('rival2',ri(24,40))},no:{r:'เขาปัดมือท่านทิ้ง',d:{aff:[[r.id,-10]]},line:'อย่ามาทำเป็นคนดี'}},
  {t:'ปล่อยวาง เดินผ่านไป',ok:{r:'เขาตะโกนตามหลัง แต่ท่านไม่หันกลับไป',d:{vit:1,tr:{brave:-2,kind:2}}}}]})},
 rival2:()=>{const r=person(rv());if(!r||!r.alive||P.stage!=='hunter')return;ask({title:'คำขอของคู่อริ',rare:3,chain:'คู่อริ',who:r.id,sc:'gatered',text:`${r.n}โทรมาตอนตีสอง เสียงสั่น "ทีมข้าติดอยู่ในเกตแดง ไม่มีใครยอมเข้าไป ข้ารู้ว่าไม่มีสิทธิ์ขอ แต่..."`,opts:[
  {t:'เข้าไปช่วย',fight:{diff:GATE_DIFF[P.rank]*1.4,world:'gatered',boss:true,cause:'ตายในเกตแดงระหว่างช่วยคู่อริ'},ok:{r:`ท่านพา${r.n}กับทีมออกมาได้ครบ เขาสาบานจะติดตามท่านไปทุกเกต`,d:{fame:8,karma:8,aff:[[r.id,50]],fav:{risk:8,good:6}},then:()=>{r.role='เพื่อนร่วมทีม';r.hunter=true;r.rank=Math.max(0,P.rank);title('red')}},no:{r:`ท่านพาได้แค่${r.n}ออกมา ลูกทีมของเขาไม่รอด`,d:{aff:[[r.id,25]]}}},
  {t:'ติดต่อกิลด์ใหญ่ให้',chk:['cha','mid'],ok:{r:'กิลด์ใหญ่ยอมส่งทีมเข้าไป ทุกคนรอด',d:{aff:[[r.id,20]],karma:3}},no:{r:'ไม่มีกิลด์ไหนรับสาย',d:{aff:[[r.id,-5]]}}},
  {t:'เมินสาส์นนั้น',ok:{r:'เช้ามากิลด์กลางประกาศชื่อของเขาในรายชื่อผู้สูญหาย',d:{karma:-6,fav:{evil:4}},then:()=>{r.alive=false}}}]})},
 cat2:()=>{if(!P.flags.cat)return;ask({title:'ราตรีไม่ใช่แมวธรรมดา',rare:3,chain:'แมวดำ',sc:'home',text:'คืนพระจันทร์เต็มดวง ราตรีลอยขึ้นกลางอากาศ ดวงตาสีม่วงส่องสว่าง แล้วมีเสียงในหัว "ข้ารอให้เจ้าโตพอมานานแล้ว"',opts:[
  {t:'ยื่นมือให้มัน',chk:['luk','mid'],ok:{r:'ราตรีกลายเป็นสัตว์พันธสัญญา พลังของท่านพุ่งขึ้น',d:{agi:5,luk:5},then:()=>{P.flags.pet='ราตรี (แมวเงา)'}},no:{r:'ราตรีมองท่านนาน แล้วหายไปในเงา ทิ้งขนสีดำไว้หนึ่งเส้น',d:{luk:2}}},
  {t:'ถามว่ามันมาจากไหน',chk:['int','mid'],ok:{r:'มันเล่าเรื่องโลกหลังเกตที่ไม่มีใครรู้',d:{int:4,coin:3}},no:{r:'มันหาวแล้วนอนต่อ',d:{}}},
  {t:'วิ่งหนีออกจากห้อง',ok:{r:'วันรุ่งขึ้นราตรีกลับมาเป็นแมวธรรมดาเหมือนไม่มีอะไรเกิดขึ้น',d:{}}}]})},
 awaken:()=>{
  const top=['str','agi','int','vit'].sort((a,b)=>P[b]-P[a]);
  const by={str:['sword','tank'],agi:['bow','assassin'],int:['mage','healer'],vit:['tank','sword']};
  const club={kendo:'sword',archery:'bow',science:'mage',nurse:'healer'}[P.flags.club];
  const opts=[...new Set([...by[top[0]],...by[top[1]],club].filter(Boolean))].slice(0,4);
  const mana=P.mana??25;
  const w=[40,28,17,9,4.5,1.5].map((x,i)=>x*Math.pow(1+mana/80,i));
  const r=RANKS.indexOf(wpick(RANKS,w));
  ask({title:'วันตื่นพลัง',rare:3,sc:'awaken',text:`ท่านวางมือลงบนลูกแก้วประเมินพลัง แสง${['เทา','เขียว','ฟ้า','ม่วง','ส้ม','ทอง'][r]}พุ่งขึ้นเต็มห้อง เจ้าหน้าที่ประกาศว่า "แรงก์ ${RANKS[r]}" พลังในตัวท่านโน้มไปได้หลายทาง จะเลือกเส้นทางไหน`,opts:opts.map(id=>{const c=CLASSES.find(x=>x.id===id);return {t:c.n,sub:c.d,ok:{r:`ท่านตื่นพลังเป็น${c.n}แรงก์ ${RANKS[r]}`,c:r>=4?'c-gold':'c-good',then:()=>awaken(id,r)}}})});
 },
 pathHunter:()=>ask({title:'วิถีฮันเตอร์',sc:'guild',text:'บัตรฮันเตอร์อยู่ในมือแล้ว จากนี้จะใช้ชีวิตแบบไหน',opts:PATHS.hunter.map(p=>({t:p.n,sub:p.d,ok:{r:`ท่านเลือกเป็น${p.n}`,then:()=>{P.path=p.id}}}))}),
 sibling:()=>{const s=P.people[2];if(!s||!s.alive)return;const r=ri(0,Math.max(0,P.rank));s.hunter=true;s.rank=r;
  ask({title:`${s.n}ตื่นพลังแล้ว`,rare:2,who:s.id,sc:'awaken',text:`${s.n} (${s.role}) ตื่นพลังเป็นแรงก์ ${RANKS[r]} แล้วเดินมาขอให้ท่านพาเข้าทีม`,opts:[
  {t:'รับเข้าทีม',ok:{r:`${s.n}ดีใจจนกระโดด`,d:{aff:[[s.id,10]]},line:'พี่ดีที่สุดเลย!',then:()=>{if(P.party.length<2)P.party.push(s.id)}}},
  {t:'ให้ไปเข้ากิลด์ที่ปลอดภัยกว่า',chk:['cha','easy'],ok:{r:`${s.n}เข้าใจและไปสมัครกิลด์ใหญ่`,d:{aff:[[s.id,3]]}},no:{r:`${s.n}งอนไปหนึ่งเดือน`,d:{aff:[[s.id,-5]]}}},
  {t:'ห้ามเป็นฮันเตอร์',ok:{r:`${s.n}ร้องไห้แล้วปิดประตูใส่`,d:{aff:[[s.id,-15]]},line:'พี่ไม่เข้าใจอะไรเลย'}}]})},
 mentor:()=>{if(P.stage!=='hunter')return;const m=mkPerson('อาจารย์',RNG()<.5?'m':'f',{aff:40,hunter:true,rank:4});P.flags.mentor=m.id;
  ask({title:'ร้านซ่อมอาวุธท้ายซอย',rare:2,chain:'อาจารย์',who:m.id,sc:'city',text:`เจ้าของร้านซ่อมอาวุธชื่อ${m.n} ดูอาวุธของท่านแล้วบอกว่า "ท่าฟันของเจ้าเสียแรงเปล่าครึ่งหนึ่ง" รอยแผลเป็นที่แขนเขาบอกว่าไม่ใช่ช่างธรรมดา`,opts:[
  {t:'ขอเป็นศิษย์',chk:['cha','mid'],ok:{r:'เขาถอนหายใจแล้วชี้ไปที่ไม้กวาด "เริ่มจากกวาดร้าน"',d:{aff:[[m.id,15]]},line:'อย่ามาบ่นทีหลังล่ะ',then:()=>schedule('mentor2',ri(10,18))},no:{r:'เขาไล่ท่านออกจากร้าน',d:{},then:()=>schedule('mentor',ri(12,20))}},
  {t:'ท้าให้เขาพิสูจน์',fight:{diff:GATE_DIFF[4]*.5,foe:'mentor',world:'train',safe:1},ok:{r:'ท่านแตะตัวเขาได้หนึ่งครั้ง เขาหัวเราะลั่นแล้วรับเป็นศิษย์',d:{aff:[[m.id,25]]},then:()=>schedule('mentor2',ri(10,18))},no:{r:'ท่านลงไปนอนกับพื้นในสามวินาที',d:{}}},
  {t:'ไม่สนใจ',ok:{r:'ท่านเดินออกจากร้านไป',d:{}}}]})},
 mentor2:()=>{const m=person(P.flags.mentor);if(!m||!m.alive)return;ask({title:'บทเรียนสุดท้ายของอาจารย์',rare:3,chain:'อาจารย์',who:m.id,sc:'train',text:`${m.n}ส่งมอบอาวุธเก่าของเขาให้ "ข้าจะกลับเข้าไปในเกตที่ข้าทิ้งเพื่อนไว้เมื่อยี่สิบปีก่อน เจ้าไม่ต้องตามมา"`,opts:[
  {t:'ตามไปด้วย',fight:{diff:GATE_DIFF[Math.min(5,P.rank+1)],world:'w_mount',boss:true,cause:'ตายในเกตเก่าของอาจารย์'},ok:{r:`ทั้งสองกลับออกมาพร้อมกระดูกของเพื่อนเขา ${m.n}ร้องไห้เป็นครั้งแรก`,d:{exp:500,fame:6,aff:[[m.id,30]],str:3,agi:3}},no:{r:`${m.n}ใช้ร่างกายบังให้ท่านหนีออกมา เขาไม่ได้กลับมาอีก`,d:{},then:()=>{m.alive=false}}},
  {t:'เคารพการตัดสินใจของเขา',ok:{r:`สามวันต่อมามีกล่องส่งมาพร้อมโน้ตลายมือ${m.n} "เจ้าพร้อมแล้ว"`,d:{[cls().m]:5},then:()=>{if(P.wep<1)P.wep=1}}},
  {t:'ขังเขาไว้ในร้าน',chk:['str','hard'],ok:{r:'เขาโกรธท่านไปหนึ่งปี แต่ยังมีชีวิตอยู่',d:{aff:[[m.id,-20]]}},no:{r:'เขาหักประตูออกไปได้ แล้วไม่กลับมาอีก',d:{},then:()=>{m.alive=false}}}]})},
 guildOffer:()=>{if(P.guild||P.stage!=='hunter')return;const n=pick(['ราชาวิหค','ดาบเหล็กดำ','ใบไม้ขาว','เขี้ยวหิมะ']);
  ask({title:`กิลด์${n}ส่งคนมาทาบทาม`,rare:1,sc:'guild',text:'สมาชิกได้ค่าจ้างเพิ่ม 50% รางวัลเกตเพิ่ม 20% และโบนัสรายปี แต่ต้องรับเกตที่กิลด์สั่ง',opts:[
  {t:'เข้าร่วม',ok:{r:`ท่านเซ็นสัญญากับกิลด์${n}`,then:()=>{P.guild=n}}},
  {t:'ต่อรองขอเงินเซ็นสัญญา',chk:['cha','hard'],ok:{r:`กิลด์${n}จ่ายเงินเซ็นสัญญาก้อนโต`,d:{gold:1500},then:()=>{P.guild=n}},no:{r:'กิลด์ถอนข้อเสนอ',d:{}}},
  {t:'อยู่อิสระต่อ',ok:{r:'ท่านอยากเลือกเกตเอง',d:{tr:{brave:2}}}}]})},
};

// =============== ตื่นพลัง ===============
function awaken(id,r){
 P.stage='hunter';P.cls=id;P.rank=r;P.path=null;P.place='guild';P.act=null;
 const c=cls();P[c.m]+=10+r*6;['str','agi','int','vit'].forEach(k=>P[k]+=r*4);P.hp=maxHp(P);
 if(P.sys){log('[ระบบ] ตรวจพบผู้เล่นที่มีคุณสมบัติ เริ่มต้นการเชื่อมต่อ','c-sys');log('[ระบบ] ภารกิจประจำวันจะมอบให้ทุกเดือนที่ท่านฝึกฝน','c-sys')}
 const bfp=person(bf());if(bfp&&RNG()<.4){bfp.hunter=true;bfp.rank=ri(0,2);log(`${bfp.n}ตื่นพลังเป็นแรงก์ ${RANKS[bfp.rank]} เช่นกัน`,'c-good')}
 const rp=person(rv());if(rp){rp.hunter=true;rp.rank=ri(1,3)}
 if(P.flags.heir){P.guild='ราชาวิหค';log('ท่านเข้ากิลด์ราชาวิหคของตระกูลตามธรรมเนียม','c-gold')}if(P.talents?.includes('starlove'))STARS.forEach(s=>P.favor[s.id]+=10);
 refreshGates();schedule('pathHunter',0);schedule('mentor',ri(8,20));schedule('guildOffer',ri(14,30));schedule('sibling',ri(24,48));
}

// =============== เกต หอคอย ===============
function refreshGates(){
 if(P.rank<0)return;P.gates=[];
 for(let i=0;i<3;i++){const r=clamp(P.rank+wpick([-2,-1,0,1,2],[10,30,35,18,7]),0,5),mod=wpick(GATE_MODS,GATE_MODS.map(g=>g.w));
  const world=mod.red?'gatered':pick(WORLDS);
  P.gates.push({r,mod:mod.n,diff:Math.round(GATE_DIFF[r]*rnd(.85,1.2)*mod.d),rew:mod.r,red:!!mod.red,pc:mod.pc==='blue'?WORLD_PC[world]||'blue':mod.pc,twin:!!mod.twin,mon:pick(MON_BY_RANK[r]),world})}
}
function fight(diff){
 const pw=power(P),ratio=pw/diff,ok=RNG()<clamp(1/(1+Math.pow(1/ratio,3))+luk(P)*.002,.02,.98);
 return {ok,dmg:Math.round(maxHp(P)*clamp(.35/Math.pow(ratio,1.5)*rnd(.5,1.2)*(ok?1:1.5),.02,1.5)),ratio};
}
const BOSSES=['ราชาก็อบลิน','หมาป่าเงาสามหัว','อัศวินโครงกระดูก','แมงมุมราชินี','ยักษ์หินผลึก','นาคน้ำแข็ง','ลิชผู้หลงทาง','มังกรเถ้าถ่าน'];
function enterGate(i){
 if(P.gateDone||!P.alive||P.rank<0)return;const g=P.gates[i];P.gateDone=true;P.gates.splice(i,1);P.world=g.world;P.mon=g.mon;P.place='gatezone';
 const f=fight(g.diff),boss=RNG()<.35;P.lastFight={mon:g.mon,win:f.ok,ratio:f.ratio,boss,world:g.world,pc:g.pc};
 if(g.r>P.rank)addFavor('risk',6*(g.r-P.rank));
 if(f.ok){let gold=Math.round(g.diff*rnd(1,1.8)*g.rew*(P.guild?1.2:1));if(P.sponsor==='night'&&g.r>P.rank)gold=Math.round(gold*1.3);
  gold=Math.round(gold*(1+(P.mul?.gold||0)));P.gold+=gold;gainExp(g.diff*.6*g.rew);addFame(g.r+1);if(boss)addFavor('boss',5);if(g.red)title('red');
  log(`เกตแรงก์ ${RANKS[g.r]} (${g.mod}) · ${WORLD_N[g.world]}: ${boss?`ล้ม${BOSSES[Math.min(7,g.r+ri(0,2))]}ที่เป็นบอสได้`:`กวาดล้าง${MON_N[g.mon]}จนหมด`} → ขายของได้ ${gold} ทอง`,'c-good','dungeon');
  P.party.forEach(id=>{const x=person(id);if(x)x.aff=clamp(x.aff+2,-100,100)});
  checkScen('gate',g.r);scratch(f.dmg*.6);
 }else{
  log(`เกตแรงก์ ${RANKS[g.r]} (${g.mod}) · ${WORLD_N[g.world]}: ${g.red?'ประตูทางออกปิดลง ต้องสู้จนกว่าจะรอด':`${MON_N[g.mon]}แข็งแกร่งเกินไป ต้องถอยทัพ`}`,'c-bad','dungeon');
  const d=Math.round(f.dmg*(g.red?1.5:1));
  if(!g.red&&d>=P.hp&&RNG()<.6+P.agi*.003){P.hp=1;log('ท่านคลานออกจากเกตมาได้ทั้งที่แทบไม่เหลือแรง','c-bad')}else hurt(d,`ตายในเกตแรงก์ ${RANKS[g.r]}`);
  if(P.alive&&g.red){gainExp(g.diff*.4);P.gold+=Math.round(g.diff*.5);title('red');addFavor('risk',8)}
 }
 starChat(.3);
}
const floorDiff=n=>Math.round(50*Math.pow(1.12,n)*(n%10===0?1.8:1));
function climb(){
 if(P.towerDone||!P.alive||P.rank<0)return;P.towerDone=true;let cleared=0;
 for(let k=0;k<5;k++){const n=P.floor+1,d=floorDiff(n),f=fight(d);if(!f.ok){scratch(f.dmg);break}
  P.floor=n;cleared++;gainExp(d*.3);scratch(f.dmg*.3);if(n%10===0){const k2=pick(['str','agi','int','vit']);P[k2]+=3;addFavor('boss',6)}}
 log(cleared?`หอคอยแห่งการทดสอบ: ไต่ได้ ${cleared} ชั้น → ตอนนี้อยู่ชั้น ${P.floor}`:`หอคอยแห่งการทดสอบ: ล้มเหลวที่ชั้น ${P.floor+1} หอคอยส่งท่านกลับลงมา`,cleared?'c-good':'c-bad','tower');
 if(cleared)addFavor('tower',3*cleared);P.best=Math.max(P.best,P.floor);checkScen('tower',P.floor);
 P.lastFight={mon:(P.floor+1)%10===0?'skel_w':'skel_s',win:cleared>0,boss:false,world:'tower',pc:'violet'};
}
function starChat(ch){if(P.rank<0||RNG()>ch)return;const s=pick(STARS);log(`กลุ่มดาว '${s.n}' ${pick(s.say)}`,'c-star');if(P.favor[s.id]>20&&RNG()<.3){P.coin++;log(`กลุ่มดาว '${s.n}' สนับสนุน 1 ดาวเหรียญ`,'c-star')}}
function checkSponsor(){
 if(P.sponsor||P.rank<0)return;const s=STARS.filter(s=>P.favor[s.id]>=50).sort((a,b)=>P.favor[b.id]-P.favor[a.id])[0];
 if(!s||P.flags['ask_'+s.id])return;P.flags['ask_'+s.id]=1;
 ask({title:`กลุ่มดาว '${s.n}' ต้องการเป็นผู้สนับสนุน`,rare:3,sc:'sky',text:`ข้อความสีทองลอยขึ้นตรงหน้า พร: ${s.gift} เลือกได้แค่ดวงเดียวตลอดชีวิต`,opts:[
  {t:'รับสัญญา',ok:{r:`ท่านทำสัญญากับกลุ่มดาว '${s.n}'`,c:'c-star',then:()=>{P.sponsor=s.id}}},
  {t:'ขอเวลาคิด',ok:{r:'ข้อความหายไป แต่ยังรู้สึกถึงสายตาที่จ้องอยู่',then:()=>{P.flags['ask_'+s.id]=0;P.favor[s.id]-=10}}},
  {t:'ปฏิเสธ',ok:{r:`กลุ่มดาว '${s.n}' ถอยกลับไปอย่างเงียบ ๆ`,then:()=>{P.favor[s.id]-=25}}}]});
}
function buy(id){const it=SHOP.find(x=>x.id===id);if(!it||P.coin<it.c)return;P.coin-=it.c;
 if(id==='potion')P.hp=maxHp(P);if(id==='fruit')for(let i=0;i<3;i++)P[pick(STATS)]++;if(id==='mark')P.mark++;if(id==='years')P.life+=5;log(`ร้านดวงดาว: แลก${it.n}`,'c-star')}
function buyGear(kind,i){const it=(kind==='wep'?WEAPONS:ARMORS)[i];if(P.gold<it.c||P[kind]>=i)return;P.gold-=it.c;P[kind]=i;log(`ร้านสมาคม: ซื้อ${it.n}`,'c-gold')}
function newScen(){const t=RNG()<.5?{type:'gate',r:clamp(P.rank+ri(0,1),0,5)}:{type:'tower',f:P.floor+ri(5,10)};t.until=P.m+8;t.rew=5+P.rank*2;P.scen=t;log(`[ฉากทดสอบ] เหล่าดวงดาวเปิดฉากใหม่: ${scenText(t)} ภายใน 8 เดือน`,'c-sys')}
const scenText=t=>t.type==='gate'?`เคลียร์เกตแรงก์ ${RANKS[t.r]} ขึ้นไป`:`ไต่หอคอยถึงชั้น ${t.f}`;
function checkScen(type,v){const s=P.scen;if(!s||s.type!==type)return;if((type==='gate'&&v>=s.r)||(type==='tower'&&v>=s.f)){P.coin+=s.rew;addFame(3);log(`[ฉากทดสอบ] สำเร็จ ได้ ${s.rew} ดาวเหรียญ`,'c-sys');P.scen=null}}
function goPlace(id){const pl=PLACES.find(x=>x.id===id);if(!pl||(pl.c&&!pl.c(P)))return;P.place=id;P.scene=id==='gatezone'?'gate':id}
function toggleParty(id){const i=P.party.indexOf(id);if(i>=0)P.party.splice(i,1);else{const x=person(id);if(x&&x.hunter&&x.alive&&x.aff>=40&&P.party.length<2)P.party.push(id)}}

// =============== เดินเวลา ===============
function curPath(){return (PATHS[P.stage]||[]).find(x=>x.id===P.path)}
function activity(){
 if(P.hp<maxHp(P)*.35)return {n:'พักรักษาตัว',rest:1};
 if(P.place==='hospital')return {n:'พักฟื้นที่โรงพยาบาล',rest:2};
 const p=curPath();return p?{n:p.act,p}:{n:'ใช้ชีวิตตามปกติ'};
}
function grow(k,v){v*=1+(P.gmul?.[k]||0);if(RNG()<v){P[k]++;P.year.d[k]=(P.year.d[k]||0)+1}}
function tick(){
 if(!P||!P.alive||PENDING.length)return;
 P.m++;P.gateDone=false;P.towerDone=false;if(P.talk&&P.m>P.talk.until)P.talk=null;
 const a=activity();P.act=a.n;P.year.acts[a.n]=(P.year.acts[a.n]||0)+1;
 const reg=P.sponsor==='mother'?2:1;
 if(a.rest)heal((a.rest===2?.6:.35)*reg);else heal(.12*reg);
 if(a.p){const g=a.p.g||{};for(const k in g)grow(k==='main'?cls().m:k,g[k]*(1+P.tr.dili/200));
  if(a.p.gold){const v=Math.round((a.p.gold>3?a.p.gold:a.p.gold*(30+Math.max(0,P.rank)*60))*(P.guild?1.5:1)*(1+(P.mul?.gold||0)));P.gold+=v;P.year.d.gold=(P.year.d.gold||0)+v}
  if(a.p.exp)gainExp(10+P.lvl*2);if(a.p.fame&&RNG()<a.p.fame)addFame(1);if(a.p.karma&&RNG()<-a.p.karma)P.karma--;if(a.p.coin&&RNG()<a.p.coin)P.coin++;
  if(P.sys&&P.path==='train'){P[pick(['str','agi','int','vit'])]++}}
 if(P.guild&&P.m%12===0)P.gold+=150*(P.rank+1);
 if(P.sponsor){P.coin++;if(P.sponsor==='serpent')P.karma--}
 if(P.rank>=0&&P.rank<rankCap(P)&&!P.sys&&RNG()<((P.sys?.012:.001)+P.lvl*.00002)*(P.destiny==='fall'?3:1)){P.rank++;['str','agi','int','vit'].forEach(k=>P[k]+=5);log(`ตื่นพลังครั้งที่สอง! สมาคมประเมินใหม่เป็นแรงก์ ${RANKS[P.rank]}`,'c-gold','awaken');addFame(10)}
 if(P.scen&&P.m>P.scen.until){log('[ฉากทดสอบ] ล้มเหลว ดวงดาวลงโทษท่าน','c-sys');scratch(maxHp(P)*.25);P.scen=null}
 if(P.rank>=0&&!P.scen&&RNG()<.02)newScen();
 if(P.rank>=0&&P.m%2===0)refreshGates();
 // วันเกิด / สรุปปี
 if(mon(P)===0){
  const acts=Object.entries(P.year.acts).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${k} ${v} เดือน`).join(', ');
  const ds=Object.entries(P.year.d).filter(([k,v])=>v).map(([k,v])=>`${SN[k]} ${v>0?'+':''}${v}`).join(', ');
  P.log.unshift({y:ageY(P)-1,mo:12,t:`สรุปปี: ${acts}${ds?` · ทั้งปี: ${ds}`:''}`,c:'sum'});P.year={acts:{},d:{}};
  if(ageY(P)===18&&P.stage==='school')schedule('awaken',0);
 }
 // เรื่องต่อเนื่องที่ถึงเวลา
 const due=P.q.filter(q=>q.due<=P.m);if(due.length&&!PENDING.length){const q=due[0];P.q.splice(P.q.indexOf(q),1);QUESTS[q.k]&&QUESTS[q.k](q.data)}
 // เหตุการณ์สุ่ม ราว 3-5 เรื่องต่อปี
 P.cool--;
 if(!PENDING.length&&P.cool<=0&&P.alive){
  const r=RNG();
  if(P.stage==='hunter'&&r<.012){dungeonBreak();P.cool=3}
  else if(false){const st=P.stage;const pool=E.filter(e=>(e.st===st||e.st==='any')&&!(e.once&&P.flags['o_'+e.once]));
   const w=pool.map(e=>(e.w||1)*(e.pl===P.place?3:1)*(e.pa===P.path?3:1));const e=wpick(pool,w);
   if(e){const d=e.fn();if(!d.c||d.c()){if(e.once)P.flags['o_'+e.once]=1;if(e.pl&&!d.sc)d.sc=e.pl;ask(d);P.cool=2}}}
  else if(r<.42){const pool=PASSIVE.filter(e=>e.st===P.stage||e.st==='any');const [t,d]=pick(pool).f();log(t+fx(d));P.cool=1}
 }
 starChat(.04);checkSponsor();TITLES.forEach(t=>t.c&&t.c(P)&&title(t.id));
 P.people.forEach(x=>{if(x.alive&&(x.role==='พ่อ'||x.role==='แม่')&&ageY(P)>55&&RNG()<.003){x.alive=false;log(`${x.n} (${x.role}) จากไปอย่างสงบ`,'c-bad','home')}});
 if(P.alive&&ageY(P)>=P.life)die('หมดอายุขัยอย่างสงบ');
}
function dungeonBreak(){
 const r=clamp(P.rank+ri(0,1),0,5);
 ask({title:'Dungeon Break',rare:2,sc:'fire',text:`เกตแรงก์ ${RANKS[r]} ในย่านที่ท่านอยู่แตกออก สัตว์อสูรทะลักลงถนน เสียงไซเรนดังทั่วเมือง`,opts:[
  {t:'เข้าไปสู้',fight:{diff:GATE_DIFF[r],world:'fire',mon:'wolf_b',cause:'ตายระหว่างหยุด Dungeon Break'},ok:{r:'ท่านหยุดฝูงอสูรไว้ได้จนทีมสมาคมมาถึง',d:{fame:5+r,karma:5,exp:GATE_DIFF[r],fav:{boss:4,kind:4}},then:()=>title('hero')},no:{r:'ท่านถ่วงเวลาให้ชาวบ้านหนีได้ทัน',d:{karma:3}}},
  {t:'พาชาวบ้านหนีไปที่หลบภัย',chk:['cha','mid'],ok:{r:'ทุกคนในซอยรอดชีวิต',d:{karma:6,fame:2,fav:{kind:4}}},no:{r:'ผู้คนแตกตื่น บางคนไม่รอด',d:{karma:1}}},
  {t:'หนีเอาตัวรอด',ok:{r:'มีคนเห็นท่านวิ่งหนี แล้วเล่าต่อกันทั่วเมือง',d:{karma:-4,fame:-3}}}]});
}
function die(cause){
 if(!P.alive)return;P.alive=false;P.hp=0;P.cause=cause;P.scene='death';
 log(`${P.name} เสียชีวิต: ${cause}`,'c-bad');
 const pts=Math.floor(P.fame/10+P.best/5+P.lvl/5);P.pts=pts;META.legacy=pts;META.lives++;
 if(!META.best||P.lvl>META.best.lvl)META.best={name:P.name,lvl:P.lvl,rank:P.rank,age:ageY(P)};
}
