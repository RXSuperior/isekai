// =============== v6: ทุกค่ามีความหมาย ===============
// มานา → เพดานแรงก์ → เพดานค่าพลัง → อาชีพขั้นสูง | ร่างกาย → เพดานค่าพลังเพิ่ม | ระบบ → เริ่ม E แต่ไร้เพดาน + อาชีพลับ
const MANA_FOR_RANK=[0,0,12,22,35,50]; // มานาขั้นต่ำของเพดานแรงก์ E..S
const STAT_CAP=[60,85,115,150,200,270],PRE_CAP=45,BODY_CAP=[0,10,20,40,999];
const SYS_RANK_LVL=[0,10,22,35,50,70];
function rankCap(p){if(p.sys)return 5;let r=1;for(let i=2;i<=5;i++)if((p.mana||0)>=MANA_FOR_RANK[i])r=i;return r}
function bodyIdx(p){if(p.bodyI!=null)return p.bodyI;const i=BODY.findIndex(b=>b.n===p.bodyN);return i<0?0:i}
function statCap(p){const b=BODY_CAP[bodyIdx(p)];if(b>=999)return 9999;return (p.rank<0?PRE_CAP:STAT_CAP[p.rank])+b+(p.sys&&p.rank>=0?Math.floor(p.lvl*1.5):0)}
MANA.forEach((m,i)=>{if(m.sys)m.d+=' · ตื่นพลังเป็นแรงก์ E เสมอ แต่เลื่อนแรงก์ได้ด้วยเลเวลจนถึง S และเปิดอาชีพลับที่คนอื่นไม่มีวันได้';
 else{let r=1;for(let k=2;k<=5;k++)if(m.v>=MANA_FOR_RANK[k])r=k;m.d+=` · เพดานแรงก์ ${RANKS[r]}${m.v>=30?' · เป็นสายเวทได้':' · สายเวทต้องมานา 30'}`}});
BODY.forEach((b,i)=>b.d+=BODY_CAP[i]>=999?' · ค่าพลังไร้เพดาน':` · เพดานค่าพลัง +${BODY_CAP[i]}`);
TALENTS.find(t=>t.id==='manasense').d='มานาแฝง +15 (อาจดันเพดานแรงก์ขึ้นหนึ่งขั้น)';
const _newLife6=newLife;newLife=function(cfg){const p=_newLife6(cfg);p.bodyI=cfg.body;p.job=null;p.shadows=[];return p};
// ---- คุมเพดานค่าพลัง ----
function enforceCap(){if(!P||!P.alive)return;const c=statCap(P);let hit=false;['str','agi','int','vit'].forEach(k=>{if(P[k]>c){P[k]=c;hit=true}});
 const key='cap'+P.rank;if(hit&&!P.flags[key]){P.flags[key]=1;log(P.rank<0?`ร่างกายคนธรรมดาไปได้แค่นี้ (เพดาน ${c}) ต้องตื่นพลังก่อนถึงจะแข็งแกร่งขึ้นได้อีก`:`ค่าพลังชนเพดานของแรงก์ ${RANKS[P.rank]} (${c}) ต้องเลื่อนแรงก์ก่อนถึงจะโตต่อได้${P.rank>=rankCap(P)?' แต่มานาของท่านไปได้แค่แรงก์นี้ ต้องเพิ่มมานาก่อน':''}`,'c-bad')}}
// ---- อาชีพและการเลื่อนขั้น ----
const JOBS={};CLASSES.forEach(c=>JOBS[c.id]={n:c.n,t:1,d:c.d});
Object.assign(JOBS,{
 knight:{n:'อัศวินดาบ',t:2,from:['sword'],req:{lvl:25,str:75,vit:50},d:'ฟันหนักและทนทาน พลังต่อสู้ ×1.3',tr:{n:'ลานประลองอัศวินร้าง',w:'w_ruin',x:'อัศวินชุดเกราะผุพังสามสิบตนยืนเรียงแถว ทุกตนยกดาบคารวะพร้อมกันเมื่อท่านก้าวเข้ามา'}},
 spellblade:{n:'นักดาบเวท',t:2,from:['sword'],req:{lvl:25,str:60,int:50,mana:30},d:'เคลือบดาบด้วยมานา ต้องมีมานาพอ พลัง ×1.3',tr:{n:'ห้องสมุดดาบที่ลุกไหม้',w:'w_autumn',x:'คัมภีร์ดาบลอยอยู่กลางเปลวไฟ ท่านต้องคว้ามันออกมาโดยไม่ให้มือไหม้'}},
 swordsaint:{n:'ปรมาจารย์ดาบ',t:3,from:['knight','spellblade'],req:{lvl:50,str:150,rank:3,floor:40},d:'ฟันเดียวผ่ากลางเกต พลัง ×1.7',tr:{n:'ยอดเขาพันดาบ',w:'w_mount',x:'ดาบนับพันปักอยู่บนยอดเขา ทุกเล่มเคยเป็นของคนที่มาไม่ถึง'}},
 ranger:{n:'พรานเงาลม',t:2,from:['bow'],req:{lvl:25,agi:75},d:'ยิงสามดอกในลมหายใจเดียว พลัง ×1.3',tr:{n:'ป่าที่ไม่มีเงา',w:'w_green',x:'ในป่านี้ทุกอย่างเคลื่อนไหวเร็วกว่าลูกศร ยกเว้นท่าน'}},
 sniper:{n:'มือสังหารมานา',t:2,from:['bow'],req:{lvl:25,agi:60,int:45,mana:25},d:'ลูกศรมานาทะลุเกราะ พลัง ×1.3',tr:{n:'หอสังเกตการณ์ร้าง',w:'w_ruin',x:'เป้าหมายอยู่ห่างออกไปสองกิโลเมตร และมันมองเห็นท่านแล้ว'}},
 bowsaint:{n:'เทพศรพยัคฆ์',t:3,from:['ranger','sniper'],req:{lvl:50,agi:150,rank:3},d:'ลูกศรเดียวตัดเกตออกเป็นสองท่อน พลัง ×1.7',tr:{n:'ทะเลทรายนกอินทรีทอง',w:'w_desert',x:'นกอินทรีทองบินสูงเกินกว่าตามองเห็น ท่านมีลูกศรดอกเดียว'}},
 elemental:{n:'จอมเวทธาตุ',t:2,from:['mage'],req:{lvl:25,int:75,mana:35},d:'คุมไฟ น้ำแข็ง สายฟ้าพร้อมกัน พลัง ×1.3',tr:{n:'แท่นบูชาสี่ธาตุ',w:'w_snow',x:'แท่นหินสี่ต้นลุกเป็นไฟ น้ำแข็ง ลม และฟ้าผ่า ทุกต้นเรียกชื่อท่าน'}},
 warlock:{n:'ผู้ทำสัญญาเหว',t:2,from:['mage'],req:{lvl:25,int:60,mana:30,karmaMax:-30},d:'ยืมพลังจากเหวลึก แลกกับบางอย่าง พลัง ×1.4',tr:{n:'บ่อน้ำดำใต้สถานีร้าง',w:'w_ruin',x:'เสียงจากก้นบ่อถามว่า ท่านจะจ่ายด้วยอะไร'}},
 archmage:{n:'จอมปราชญ์',t:3,from:['elemental','warlock'],req:{lvl:50,int:155,mana:55,rank:3},d:'เขียนกฎของเกตใหม่ได้ พลัง ×1.7',tr:{n:'หอดาราศาสตร์ลอยฟ้า',w:'w_rocks',x:'ดวงดาวจัดเรียงเป็นโจทย์ที่ไม่มีมนุษย์คนไหนแก้ได้มาสามร้อยปี'}},
 shadowblade:{n:'นักฆ่าเงา',t:2,from:['assassin'],req:{lvl:25,agi:75},d:'ละลายหายไปในเงา พลัง ×1.3',tr:{n:'คฤหาสน์ไร้แสง',w:'w_forest',x:'ไม่มีแสงสักดวงในคฤหาสน์หลังนี้ และมีอะไรบางอย่างหายใจอยู่ข้างหลังท่าน'}},
 nightking:{n:'ราตรีพิฆาต',t:3,from:['shadowblade'],req:{lvl:50,agi:150,rank:3},d:'ศัตรูตายก่อนรู้ตัวว่าถูกโจมตี พลัง ×1.7',tr:{n:'คืนที่ดวงจันทร์ดับ',w:'w_forest',x:'นักฆ่ารุ่นก่อนเจ็ดคนรอท่านอยู่ ทุกคนใส่หน้ากากที่หน้าตาเหมือนท่าน'}},
 priest:{n:'นักบวชศักดิ์สิทธิ์',t:2,from:['healer'],req:{lvl:25,int:70,karma:20},d:'แสงรักษาที่เผาอสูรได้ ต้องมีกรรมดี พลัง ×1.3',tr:{n:'โบสถ์กลางเกตแดง',w:'gatered',x:'ผู้บาดเจ็บสามสิบคนนอนอยู่ในโบสถ์ มานาของท่านพอสำหรับยี่สิบคน'}},
 bloodpriest:{n:'นักบวชโลหิต',t:2,from:['healer'],req:{lvl:25,int:60,karmaMax:-30},d:'ดูดชีวิตศัตรูมารักษาตัวเอง พลัง ×1.4',tr:{n:'แท่นบูชาโลหิต',w:'gatered',x:'แท่นบูชาต้องการเลือด จะเป็นของใครก็ได้'}},
 saint:{n:'นักบุญ',t:3,from:['priest'],req:{lvl:50,int:150,karma:60,rank:3},d:'ปลุกคนที่เพิ่งตายได้หนึ่งคน พลัง ×1.7 และรอดตายได้ปีละครั้ง',tr:{n:'หุบเขาแห่งการชดใช้',w:'w_mount',x:'ทุกคนที่ท่านเคยช่วยไม่ทันยืนเรียงรออยู่ในหุบเขา'}},
 bloodlord:{n:'จ้าวโลหิต',t:3,from:['bloodpriest'],req:{lvl:50,int:150,karmaMax:-60,rank:3},d:'ทุกบาดแผลของศัตรูคือพลังของท่าน พลัง ×1.8',tr:{n:'ทะเลสาบสีแดง',w:'gatered',x:'ทะเลสาบนี้เคยเป็นกองทัพ'}},
 guardian:{n:'ผู้พิทักษ์เหล็ก',t:2,from:['tank'],req:{lvl:25,vit:75},d:'รับการโจมตีแทนทั้งทีม พลัง ×1.3',tr:{n:'กำแพงสุดท้าย',w:'w_snow',x:'หมู่บ้านอยู่ข้างหลังท่าน คลื่นอสูรอยู่ข้างหน้า กำแพงพังไปแล้ว'}},
 titan:{n:'ไททันมนุษย์',t:3,from:['guardian'],req:{lvl:50,vit:150,rank:3,floor:40},d:'ร่างกายที่ดาบแรงก์ S ฟันไม่เข้า พลัง ×1.7',tr:{n:'แท่นหินยักษ์โบราณ',w:'w_rocks',x:'ยักษ์หินสูงร้อยเมตรยื่นมือมาให้ท่านดัน'}},
 necro:{n:'จอมเวทวิญญาณ',t:3,from:'any',req:{sys:1,lvl:40,rank:2},d:'อาชีพลับของผู้เล่น ดึงวิญญาณศัตรูที่ล้มมาเป็นทหารเงา พลัง ×1.6 + ทหารเงา',secret:1},
 monarch:{n:'ราชันเงา',t:4,from:['necro'],req:{sys:1,lvl:75,rank:5,floor:60,shadows:8},d:'ผู้ปกครองความตายทั้งปวง พลัง ×2.6 ทหารเงาแข็งแกร่งขึ้นสองเท่า',secret:1},
});
const TIER_MUL=[1,1,1.3,1.7,2.6],TIER_N=['','ขั้นต้น','ขั้นกลาง','ขั้นสูง','ตำนาน'];
const jobOf=p=>JOBS[p.job||p.cls]||JOBS.sword;
const jobMul=id=>{const j=JOBS[id];if(!j)return 1;const m=(j.d.match(/×([\d.]+)/)||[])[1];return m?+m:TIER_MUL[j.t]};
function nextJobs(p){const cur=p.job||p.cls,t=JOBS[cur]?.t||1;return Object.entries(JOBS).filter(([id,j])=>j.from&&id!==cur&&(j.from==='any'?t<3&&(p.sys||true):j.from.includes(cur)))}
function reqList(req){const out=[],S=(lab,cur,need,ok,hint)=>out.push({lab,cur,need,ok,hint}),c=statCap(P);
 if(req.sys)S('[ระบบ]',P.sys?'มี':'ไม่มี','มี',!!P.sys);
 if(req.lvl)S('เลเวล',P.lvl,req.lvl,P.lvl>=req.lvl);
 if(req.rank!=null)S('แรงก์',RANKS[Math.max(0,P.rank)],RANKS[req.rank],P.rank>=req.rank,req.rank>rankCap(P)?`มานาของท่านไปถึงแค่แรงก์ ${RANKS[rankCap(P)]}`:'');
 ['str','agi','int','vit'].forEach(k=>{if(req[k])S(SN[k],P[k],req[k],P[k]>=req[k],req[k]>c?`เพดานตอนนี้ ${c} ต้องเลื่อนแรงก์ก่อน`:'')});
 if(req.mana)S('มานา',Math.floor(P.mana),req.mana,P.mana>=req.mana);
 if(req.karma!=null)S('กรรม',P.karma,'≥ '+req.karma,P.karma>=req.karma);
 if(req.karmaMax!=null)S('กรรม',P.karma,'≤ '+req.karmaMax,P.karma<=req.karmaMax);
 if(req.floor)S('หอคอยสูงสุด',P.best,'ชั้น '+req.floor,P.best>=req.floor);
 if(req.shadows)S('ทหารเงา',(P.shadows||[]).length,req.shadows,(P.shadows||[]).length>=req.shadows);
 return out}
const reqOk=id=>reqList(JOBS[id].req).every(r=>r.ok)&&!(P.flags['tcd_'+id]>P.m);
function trialDiff(j){const r=Math.max(0,P.rank);return j.t===2?GATE_DIFF[r]*.9:j.t===3?GATE_DIFF[Math.min(5,r+1)]*.75:GATE_DIFF[5]*1.2}
function changeJob(id){const j=JOBS[id];P.job=id;const m=cls().m;P[m]+=8*j.t;P.vit+=3*j.t;addFame(5*j.t);P.hp=maxHp(P);
 log(`[เลื่อนขั้น] ท่านกลายเป็น${j.n} (${TIER_N[j.t]}) · ${j.d}`,'c-gold','awaken');addFavor('risk',5)}
QUESTS.jobTrial=(d)=>{const id=d?.id;const j=JOBS[id];if(!j||!reqOk(id)||P.job===id)return;
 if(id==='necro')return QUESTS.necroQuest();if(id==='monarch')return QUESTS.monarchQuest();
 const diff=trialDiff(j),lethal=j.t>=3;
 ask({title:`ด่านเลื่อนขั้น: ${j.tr.n}`,rare:3,chain:'เลื่อนขั้นอาชีพ',sc:'dungeon',text:`สมาคมออกหนังสือรับรองให้ท่านเข้าด่านเลื่อนขั้นเป็น${j.n} ${j.tr.x}${lethal?' ด่านขั้นสูงไม่มีทางออกจนกว่าจะชนะหรือตาย':' ถ้าแพ้ ผู้คุมด่านจะลากท่านออกมา แต่ต้องรอหนึ่งปีถึงจะท้าใหม่ได้'}`,opts:[
  {t:'เข้าด่าน',sub:j.d,fight:{diff,world:j.tr.w,boss:true,safe:lethal?0:1,cause:`ตายในด่านเลื่อนขั้น${j.n}`},ok:{r:`ท่านผ่าน${j.tr.n}`,c:'c-gold',then:()=>changeJob(id)},no:{r:'ท่านแพ้ ต้องรอหนึ่งปี',then:()=>{P.flags['tcd_'+id]=P.m+12}}},
  {t:'ฝึกให้พร้อมกว่านี้ก่อน',ok:{r:'ท่านเก็บหนังสือรับรองไว้ในลิ้นชัก',then:()=>{P.flags['tcd_'+id]=P.m+4}}}]})};
// ---- อาชีพลับของผู้เล่น ----
const SHADOW_N=['คาร์นิส อัศวินโลหิต','วาร์ก หมาป่าเงา','กรอม ยักษ์หินผลึก','เซเลีย แม่มดผี','ฮาเกน แม่ทัพออร์ค','มอร์ ราชาแมลงดำ','ไอวี่ นาคเหว','เดรค มังกรกระดูก','ทอร์ก นักรบน้ำแข็ง','ลิลิธ นางพญาค้างคาว','บาราน ราชาปีศาจ','ไซลัส อัศวินดำ'];
const shadowPow=p=>(p.shadows||[]).reduce((s,x)=>s+x.p,0)*(p.job==='monarch'?2:1);
QUESTS.necroQuest=()=>ask({title:'[ระบบ] ภารกิจเปลี่ยนอาชีพ',rare:4,chain:'อาชีพลับ',sc:'dungeon',text:'หน้าต่างสีฟ้าผุดขึ้นกลางดึก "ผู้เล่นมีคุณสมบัติครบสำหรับการเปลี่ยนอาชีพ ภารกิจ: เอาชีวิตรอดในดินแดนแห่งความตายจนกว่าอัศวินโลหิตจะล้ม หากล้มเหลว ผู้เล่นจะตาย" ท่านรู้ดีว่าระบบไม่เคยพูดเล่น',opts:[
 {t:'รับภารกิจ',sub:'☠ ระบบไม่มีทางถอย',fight:{diff:trialDiff(JOBS.necro),world:'gatered',boss:true,cause:'ตายในภารกิจเปลี่ยนอาชีพของระบบ'},ok:{r:'อัศวินโลหิตคุกเข่าลง ร่างของมันสลายเป็นควันดำแล้วไหลเข้ามาในเงาของท่าน',c:'c-gold',then:()=>{changeJob('necro');P.shadows.push({n:SHADOW_N[0],p:40+P.rank*15});log('[ระบบ] ได้รับสกิล "สกัดเงา" · ศัตรูที่ล้มลงอาจกลายเป็นทหารของท่าน','c-sys');log(`${SHADOW_N[0]}ลุกขึ้นจากเงา คุกเข่าต่อหน้าท่าน`,'c-star')}},no:{r:'ท่านเกือบตาย ระบบลงโทษแล้วยืดเวลาให้อีกครั้ง',d:{hp:-30},then:()=>{P.flags.tcd_necro=P.m+6}}},
 {t:'ปฏิเสธ',sub:'ระบบจะลงโทษ',ok:{r:'[ระบบ] บทลงโทษ: ดินแดนลงทัณฑ์ 4 ชั่วโมง ท่านรอดมาได้ด้วยแผลเต็มตัว',d:{hp:-25,vit:2},then:()=>{P.flags.tcd_necro=P.m+8}}}]});
QUESTS.monarchQuest=()=>ask({title:'บัลลังก์ที่ว่างเปล่า',rare:4,chain:'อาชีพลับ',sc:'dungeon',text:'ทหารเงาทุกตนหันไปทางเดียวกันพร้อมกัน ประตูสีดำบานหนึ่งเปิดอยู่กลางห้องนอนของท่าน ข้างในมีบัลลังก์ว่างตัวหนึ่ง และเสียงที่บอกว่ามันรอท่านมานานกว่าหนึ่งพันปี',opts:[
 {t:'นั่งลงบนบัลลังก์',sub:'☠ ผู้ปกครองคนก่อนจะมาทวงคืน',fight:{diff:trialDiff(JOBS.monarch),world:'gatered',boss:true,cause:'ตายบนบัลลังก์แห่งเงา'},ok:{r:'ผู้ปกครองคนก่อนยิ้มให้ก่อนสลายหายไป "ตอนนี้มันเป็นของเจ้าแล้ว"',c:'c-gold',then:()=>{changeJob('monarch');P.life+=200;log('อายุขัยของท่านไม่ใช่ของมนุษย์อีกต่อไป','c-star')}},no:{r:'ท่านถูกโยนกลับออกมา ทหารเงาครึ่งหนึ่งแตกสลาย',then:()=>{P.shadows.length=Math.ceil(P.shadows.length/2);P.flags.tcd_monarch=P.m+12}}},
 {t:'ปิดประตู',ok:{r:'ประตูหายไป แต่ท่านรู้ว่ามันจะกลับมา',then:()=>{P.flags.tcd_monarch=P.m+12}}}]});
function tryExtract(bossName){if(!['necro','monarch'].includes(P.job)||P.shadows.length>=SHADOW_N.length)return;if(RNG()>.4)return;
 const n=SHADOW_N.find(x=>!P.shadows.some(s=>s.n===x))||bossName;P.shadows.push({n,p:30+P.rank*18+ri(0,20)});log(`"ลุกขึ้น" · ${bossName}ที่ล้มลงกลายเป็นทหารเงา: ${n}`,'c-sys')}
// ---- ผูกเข้ากับระบบเดิม ----
const _power6=power;power=function(p){if(p.rank<0)return _power6(p);return Math.round(_power6(p)*jobMul(p.job||p.cls)+shadowPow(p))};
const _gain6=gainExp;gainExp=function(n){const l0=P.lvl;_gain6(n);if(P.lvl>l0){
 for(let L=l0+1;L<=P.lvl;L++)if(L%5===0){P.mana+=P.sys?2:1}
 if(P.sys)while(P.rank<5&&P.lvl>=SYS_RANK_LVL[P.rank+1]){P.rank++;['str','agi','int','vit'].forEach(k=>P[k]+=4);log(`[ระบบ] ประเมินใหม่: สมาคมยืนยันว่าท่านตอนนี้เป็นแรงก์ ${RANKS[P.rank]} ทั้งที่เคยเป็นแรงก์ E ที่อ่อนแอที่สุด`,'c-gold','awaken');addFame(12)}}};
const _enter6=enterGate;enterGate=function(i){const g=P.gates[i];_enter6(i);if(P.lastFight?.win&&P.lastFight.boss&&g)tryExtract(BOSSES[Math.min(7,g.r+ri(0,2))])};
const _tick6=tick;tick=function(){if(P&&!P.shadows)P.shadows=[];const was=P&&P.m;_tick6();if(!P||!P.alive||P.m===was)return;enforceCap();
 if(P.path==='research'&&RNG()<.08)P.mana+=1;
 if(P.rank>=0&&!PENDING.length&&!P.q.some(q=>q.k==='jobTrial')&&P.m%3===0){const n=nextJobs(P).find(([id])=>reqOk(id)&&!(P.flags['toff_'+id]>P.m));if(n){P.flags['toff_'+n[0]]=P.m+12;schedule('jobTrial',0,{id:n[0]})}}};
const _ans6=answer;answer=function(i){_ans6(i);enforceCap()};
// ตื่นพลังใหม่: มานากำหนดเพดาน สายเวทต้องมีมานา ระบบเริ่มที่ E
QUESTS.awaken=()=>{
 const top=['str','agi','int','vit'].sort((a,b)=>P[b]-P[a]);
 const by={str:['sword','tank'],agi:['bow','assassin'],int:['mage','healer'],vit:['tank','sword']};
 const club={kendo:'sword',archery:'bow',science:'mage',nurse:'healer'}[P.flags.club];
 const opts=[...new Set([...by[top[0]],...by[top[1]],club].filter(Boolean))].slice(0,4);
 const cap=rankCap(P),mana=P.mana??25;let r;
 if(P.sys)r=0;else{const w=[40,28,17,9,4.5,1.5].map((x,i)=>i>cap?0:x*Math.pow(1+mana/80,i));r=RANKS.indexOf(wpick(RANKS,w))}
 const magic=id=>['mage','healer'].includes(id);
 const text=P.sys?'ลูกแก้วประเมินพลังเปล่งแสงสีเทาจาง ๆ เจ้าหน้าที่หัวเราะออกมา "แรงก์ E" คนในห้องหันมามอง แต่ในหัวของท่านมีเสียงหนึ่งพูดขึ้น [ระบบ] "ผู้เล่นไม่มีเพดาน เริ่มต้นการเติบโต" ท่านจะเลือกเส้นทางไหน':
  `ท่านวางมือลงบนลูกแก้วประเมินพลัง แสง${['เทา','เขียว','ฟ้า','ม่วง','ส้ม','ทอง'][r]}พุ่งขึ้นเต็มห้อง เจ้าหน้าที่ประกาศว่า "แรงก์ ${RANKS[r]}" ${r<cap?`มานาของท่านยังไปได้ถึงแรงก์ ${RANKS[cap]} ถ้าโชคดีจะตื่นพลังครั้งที่สอง`:'นี่คือจุดสูงสุดที่มานาของท่านรับไหว ถ้าอยากไปไกลกว่านี้ต้องเพิ่มมานา'} พลังในตัวท่านโน้มไปได้หลายทาง`;
 ask({title:'วันตื่นพลัง',rare:3,sc:'awaken',text,opts:opts.map(id=>{const c=CLASSES.find(x=>x.id===id),lock=magic(id)&&mana<30;
  return {t:c.n,sub:lock?`🔒 ต้องมีมานา 30 (ท่านมี ${Math.floor(mana)})`:c.d,need:()=>!lock,ok:{r:`ท่านตื่นพลังเป็น${c.n}แรงก์ ${RANKS[r]}`,c:r>=4?'c-gold':'c-good',then:()=>{awaken(id,r);P.job=id}}}})});
};
