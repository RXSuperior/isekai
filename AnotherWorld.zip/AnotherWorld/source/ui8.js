// ---- v8: เมนูสามขีด ----
const HOWTO=`<p>เกมจำลองชีวิตในต่างโลก เริ่มตอนอายุ 15 เวลาเดินเองทีละเดือน ได้รับพรจากเทพ (ตื่นพลัง) ตอนอายุ 18</p><p>เลือก <b>วิถีชีวิต</b> (ปุ่มขวาบน) เพื่อกำหนดว่าแต่ละเดือนทำอะไร ไปที่ไหนในแท็บ <b>แผนที่</b> เหตุการณ์ของที่นั่นจะเกิดบ่อยขึ้น</p><p>ตัวเลือกบอกค่าพลังที่ใช้และโอกาสสำเร็จ ☠ คืออาจตาย</p><p>เป้าหมายหลักคือปราบจอมมาร หลังจากนั้นผู้ที่มาจากโลกเดิมจะได้เลือกว่าจะกลับหรืออยู่ต่อ</p>`;
const GUIDE=`<p><b>มานา</b> กำหนดแรงก์สูงสุดที่ไปถึงได้ แรงก์กำหนดเพดานค่าพลัง เพดานค่าพลังกำหนดว่าเลื่อนขั้นอาชีพได้ถึงไหน มานาเพิ่มทุก 5 เลเวล</p><p><b>อาชีพ</b> มี 3 ขั้น ต้องผ่านด่านเลื่อนขั้น เงื่อนไขดูได้ในแท็บอาชีพ ผู้มี [ระบบ] มีอาชีพลับ</p><p><b>ร่างกาย</b> เพิ่มเพดานค่าพลัง <b>ดวงชะตา</b> เปลี่ยนเหตุการณ์ที่จะเจอ <b>พรสวรรค์</b> มี 5 ระดับตามสี</p><p><b>เหล่าเทพ</b> เฝ้าดูท่าน ทำสิ่งที่เทพองค์ไหนชอบ ความชอบจะเพิ่ม ถึง 50 จะเสนอเป็นผู้อุปถัมภ์</p><p><b>จอมมาร</b> มีแม่ทัพสี่ตน ต้องล้มแม่ทัพให้ครบก่อนบุกปราสาทจอมมาร</p>`;
let MENU_SPEED=0;
function menuModal(re){if(!P)return;if(re!==true){MENU_SPEED=speed;setSpeed(0)}
 $('#modal').innerHTML=`<div class="modal"><div class="panel menu"><button class="mclose" id="mx">✕</button><h2>เมนู</h2>
  <label class="row" style="font-size:14px"><input type="checkbox" id="mfate" ${SET.fate?'checked':''} style="width:auto"> ให้ชะตาเลือกแทนเมื่อไม่ได้กดภายใน ${SET.fateWait} วินาที</label>
  <button class="mbtn" id="mguide">คู่มือระบบ</button><button class="mbtn" id="mhow">วิธีเล่น</button><button class="mbtn" id="msave">บันทึกเกม</button>
  <button class="mbtn" id="medit">แต่งตัวใหม่</button><button class="mbtn" id="mhome">กลับหน้าหลัก</button><button class="mbtn" id="mclose">ปิด</button></div></div>`;
 const close=()=>{$('#modal').innerHTML='';setSpeed(MENU_SPEED);render()};
 $('#mx').onclick=close;$('#mclose').onclick=close;
 $('#mfate').onchange=e=>{SET.fate=e.target.checked;save()};
 $('#mguide').onclick=()=>infoModal('คู่มือระบบ',GUIDE,()=>setTimeout(()=>menuModal(true)));$('#mhow').onclick=()=>infoModal('วิธีเล่น',HOWTO,()=>setTimeout(()=>menuModal(true)));
 $('#msave').onclick=()=>{save();$('#msave').textContent='บันทึกแล้ว ✓'};
 $('#medit').onclick=()=>{$('#modal').innerHTML='';startWizard('edit')};
 $('#mhome').onclick=()=>{save();$('#modal').innerHTML='';P=null;startScreen()};
}
const _bh8=bindHead;bindHead=function(){_bh8();const m=$('#menu');if(m)m.onclick=menuModal};
