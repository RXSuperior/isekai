// =============== ระบบตัวละครโมดูลาร์ ชั้นภาพจริง (PNG) ทับบนร่างเดิม ===============
// ลำดับชั้น: ร่าง > กางเกง/กระโปรง > รองเท้า > เสื้อ > ผม > [ชุด PNG] > [ของจากโค้ดเดิม] > [อาวุธ PNG]
const EXT_LAYERS={};function extLayer(n){let e=EXT_LAYERS[n];if(!e){e=EXT_LAYERS[n]={img:new Image(),data:null};e.img.src='a/art/char/'+n+'.png'}
 if(!e.data&&e.img.complete&&e.img.naturalWidth){const c=document.createElement('canvas');c.width=800;c.height=448;const g=c.getContext('2d');g.drawImage(e.img,0,0);e.data=g.getImageData(0,0,800,448).data}return e.data}
const OUTFITS_PNG={6:'tunic'};OUTFIT_N.push('ทูนิกนักผจญภัย');GEAR_OPTS.outfit=OUTFIT_N.length;
const WEP_PNG={mage:'staff',healer:'staff'};
['outfit_tunic_m','outfit_tunic_f','wep_staff_m','wep_staff_f'].forEach(extLayer);
// ย้อมชั้นเทา: R 60/110/165/220 = เงา กลาง สว่าง ไฮไลต์
function paintExt(o,d,ramp){for(let p=0;p<800*448;p++){if(d[p*4+3]<10)continue;const r=d[p*4],g=d[p*4+1],b=d[p*4+2];let c=[r,g,b];
 if(ramp&&r===g&&g===b&&r>=50&&r<=230){c=ramp[r<85?0:r<140?1:r<195?2:3]}o[p*4]=c[0];o[p*4+1]=c[1];o[p*4+2]=c[2];o[p*4+3]=255}}
const _gs13=getSheet;getSheet=function(L0,wep,cls){const L=normLook(L0),ofn=OUTFITS_PNG[L.outfit],wn=WEP_PNG[cls];
 const base=_gs13(ofn?{...L0,outfit:0}:L0,wep&&!wn);if(!ofn&&!wn)return base;if(!base)return null;
 const key='x.'+lookKey(L,wep)+'.'+(wn||'');if(SHEET_CACHE[key])return SHEET_CACHE[key];
 const ds=[ofn&&extLayer(`outfit_${ofn}_${L.sex}`),wn&&extLayer(`wep_${wn}_${L.sex}`)];if(ds.some((d,i)=>[ofn,wn][i]&&!d))return base;
 const c=document.createElement('canvas');c.width=800;c.height=448;const g=c.getContext('2d');g.drawImage(base,0,0);const im=g.getImageData(0,0,800,448);
 if(ofn)paintExt(im.data,ds[0],ramp4(OUT_COLORS[L.topC][1]));if(wn)paintExt(im.data,ds[1],null);g.putImageData(im,0,0);return SHEET_CACHE[key]=c};
// ตัวควบคุมแอนิเมชัน: สถานะ -> แถว/เฟรมใน sheet เดิม (ท่าที่ยังไม่มีภาพเฉพาะ ยืมท่าใกล้เคียงและระบุไว้)
const ANIM={idle:{r:0,f:[0,1,2,3,4],sp:3},walk:{r:1,f:[0,1,2,3,4,5,6,7],sp:1},run:{r:2,f:[0,1,2,3,4,5,6,7],sp:1},
 attack:{r:5,f:[1,3,5],sp:1,once:1},hurt:{r:6,f:[1],sp:1},death:{r:6,f:[0,1,2,3,4,5,6,7,8,9],sp:2,once:1},dead:{r:6,f:[9],sp:1},
 cast:{r:5,f:[0,1,1,1],sp:3,borrow:'attack'},interact:{r:5,f:[0,1,0],sp:4,borrow:'attack'},work:{r:5,f:[0,1,2,1],sp:3,borrow:'attack'},
 talk:{r:0,f:[0,1,0,2],sp:4,borrow:'idle'},sleep:{r:6,f:[9],sp:1,borrow:'death'},sit:{r:0,f:[0],sp:1,borrow:'idle',todo:1}};
pickFrame=function(name,t){const a=ANIM[name]||ANIM.idle,i=Math.floor(t/a.sp);return [a.r,a.f[a.once?Math.min(i,a.f.length-1):i%a.f.length]]};
// ช่วงวัย
function lifeStage(age){return age==null?'adult':age<13?'child':age<18?'teen':age<26?'young':age<45?'adult':age<60?'middle':'elder'}
const STAGE_SC={child:1,teen:.9,young:1,adult:1,middle:1,elder:.96};
const _dh13=drawHuman;drawHuman=function(g,L,name,t,x,y,sc=2,flip=false,alpha=1,wep){if(!L)return;const st=L.stage||'adult',s=getSheet(L,!!SWORD_CLS[wep],wep);if(!s)return;
 const [r,c]=pickFrame(name,t),k=Math.max(1,Math.round(sc*1.5*(STAGE_SC[st]||1)));g.save();g.globalAlpha=alpha;g.imageSmoothingEnabled=false;g.translate(Math.round(x),Math.round(y));if(!flip)g.scale(-1,1);
 g.drawImage(s,c*FW,r*FH,FW,FH,-39.5*k,-FH*k,FW*k,FH*k);g.restore()};
// รูปลักษณ์ NPC: สุ่มจาก seed ของคน คงที่หลังเซฟ (look ถูกบันทึกในเซฟอยู่แล้ว) · ตัวละครเรื่องกำหนด preset ได้ผ่าน look
function applyAge(L,age){L.stage=lifeStage(age);if(L.stage==='elder'&&!L.aged){L.aged=1;L.hairC=7+((L.skin|0)%3)}return L}
const CHAR_PRESETS={hero_m:{sex:'m',skin:1,hair:0,hairC:2,top:0,topC:6,botC:3,shoe:0,outfit:6},hero_f:{sex:'f',skin:1,hair:3,hairC:10,top:0,topC:6,botC:3,shoe:0,outfit:6}};
if(typeof ensureNpc==='function'){const _en13=ensureNpc;ensureNpc=function(x){_en13(x);if(x.look&&typeof x.look==='object')applyAge(x.look,x.age);return x}}
if(typeof tick==='function'){const _t13=tick;tick=function(){_t13();if(P&&P.look&&typeof P.look==='object')applyAge(P.look,ageY(P))}}
