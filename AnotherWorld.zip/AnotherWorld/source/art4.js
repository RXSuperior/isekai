// =============== ภาพและฉาก ===============
const MF=/*MANIFEST*/;
const IMG={};
function img(src){if(!IMG[src]){IMG[src]=new Image();IMG[src].src=src}return IMG[src]}
Object.values(MF.bg).flat().forEach(img);
[...Object.values(MF.chars).flatMap(c=>Object.values(c.an)),...Object.values(MF.mons).flatMap(m=>Object.values(m)),...Object.values(MF.fx),MF.npc.trader].forEach(s=>img(s.src));
const W=1152,H=324,FEET=306;
const SCENE_CAP={home:'บ้านพัก',school:'ห้องเรียน ม.ปลาย',city:'ย่านใจกลางเมือง',guild:'โถงสมาคมฮันเตอร์',gate:'ย่านเกต',gatezone:'ย่านเกต',hospital:'โรงพยาบาลฮันเตอร์',casino:'บ่อนใต้ดิน',
 awaken:'ห้องประเมินพลัง',train:'ลานฝึก',tower:'หอคอยแห่งการทดสอบ',sky:'ห้วงดวงดาว',fire:'Dungeon Break',death:'ทุ่งสุดท้าย',gatered:'ดินแดนสีเลือด'};
const FX_OF={sword:'sword',bow:'bow',mage:'mage',assassin:'assassin',healer:'healer',tank:'tank'};
// ---- เปลี่ยนสีชุด (หมุนเฉดสีเฉพาะพิกเซลที่ไม่ใช่ผิว) ----
const TINTS=[0,40,95,150,205,260,315];
const TCACHE={};
function rgb2hsv(r,g,b){r/=255;g/=255;b/=255;const mx=Math.max(r,g,b),mn=Math.min(r,g,b),d=mx-mn;let h=0;if(d){h=mx===r?((g-b)/d)%6:mx===g?(b-r)/d+2:(r-g)/d+4;h*=60;if(h<0)h+=360}return [h,mx?d/mx:0,mx]}
function hsv2rgb(h,s,v){const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let [r,g,b]=h<60?[c,x,0]:h<120?[x,c,0]:h<180?[0,c,x]:h<240?[0,x,c]:h<300?[x,0,c]:[c,0,x];return [(r+m)*255,(g+m)*255,(b+m)*255]}
function tinted(s,t){
 if(!t)return IMG[s.src];const k=s.src+'|'+t;if(TCACHE[k])return TCACHE[k];const im=IMG[s.src];if(!im||!im.complete)return im;
 const c=document.createElement('canvas');c.width=im.width;c.height=im.height;const g=c.getContext('2d');g.drawImage(im,0,0);
 const d=g.getImageData(0,0,c.width,c.height),a=d.data;
 for(let i=0;i<a.length;i+=4){if(!a[i+3])continue;const [h,s2,v]=rgb2hsv(a[i],a[i+1],a[i+2]);
  const skin=(h<=50||h>=335)&&s2>.08&&s2<.78&&v>.28;if(skin||s2<.22||v<.12)continue;
  const [r,g2,b]=hsv2rgb((h+TINTS[t])%360,Math.min(1,s2*1.05),v);a[i]=r;a[i+1]=g2;a[i+2]=b}
 g.putImageData(d,0,0);TCACHE[k]=c;return c;
}
function spr(g,s,f,x,y,sc=2,flip=false,alpha=1,tint=0){
 if(!s)return;const im=tint?tinted(s,tint):IMG[s.src];if(!im||(im.complete===false))return;
 const fr=((f%s.n)+s.n)%s.n,sz=s.h;g.save();g.globalAlpha=alpha;g.translate(x,y);if(flip)g.scale(-1,1);
 g.drawImage(im,fr*sz,0,sz,sz,-sz*sc/2+(s.dx||0)*sc,-(sz-(s.oy||0))*sc,sz*sc,sz*sc);g.restore();
}
function shadow(g,x,y,w=34){g.fillStyle='rgba(0,0,0,.28)';g.beginPath();g.ellipse(x,y+1,w,6,0,0,7);g.fill()}
const anim=(look,name)=>{const a=(MF.chars[look]||MF.chars.g1).an;if(name==='Hurt')return a.Hurt||a.Protection;if(name==='Dead')return a.Dead||a.Protection;return a[name]||a.Idle};
const PN={Idle:'idle',Walk:'walk',Attack:'attack',Hurt:'hurt',Dead:'hurt'};
const CLERK={sex:'f',skin:1,hair:3,hairC:3,top:1,topC:0,botC:3,shoe:0};
const THUG={sex:'m',skin:3,hair:1,hairC:0,top:0,topC:3,botC:10,shoe:0};
function person4(g,look,tint,name,f,x,flip,label,sc=2,wep){if(!look||typeof look!=='object')return;shadow(g,x,FEET);const n=PN[name]||'idle';drawHuman(g,look,n,n==='attack'?Math.floor((f%9)/3):f,x,FEET,sc,flip,1,wep);if(label)tag(g,label,x,FEET-CH*sc-2)}
function tag(g,t,x,y){g.font='600 13px Sarabun, sans-serif';const w=g.measureText(t).width+12;g.fillStyle='rgba(15,18,30,.78)';g.fillRect(x-w/2,y-16,w,20);g.fillStyle='#e8ecf8';g.textAlign='center';g.fillText(t,x,y-1)}
function bubble(g,t,x,y){g.font='14px Sarabun, sans-serif';const w=Math.min(300,g.measureText(t).width+20);g.fillStyle='#fffdf5';g.strokeStyle='#2a2a38';g.lineWidth=2;
 g.beginPath();g.roundRect?g.roundRect(x-w/2,y-26,w,26,6):g.rect(x-w/2,y-26,w,26);g.fill();g.stroke();g.beginPath();g.moveTo(x-6,y);g.lineTo(x,y+8);g.lineTo(x+6,y);g.fill();g.fillStyle='#222';g.textAlign='center';g.fillText(t,x,y-8)}
const R=(g,x,y,w,h,c)=>{g.fillStyle=c;g.fillRect(x|0,y|0,w|0,h|0)};
const hr=i=>{const x=Math.sin(i*127.1+311.7)*43758.5453;return x-Math.floor(x)};
function drawLayers(g,key,t,move){const L=MF.bg[key]||MF.bg.city;L.forEach((src,i)=>{const im=IMG[src];if(!im||!im.complete)return;if(/castle/.test(src)){g.drawImage(im,W/2-im.width/2+120,0);return}const sp=move?i*i*.06:0,w=im.width,off=-((t*sp)%w);for(let x=off;x<W;x+=w)g.drawImage(im,Math.floor(x),0,w,im.height)})}
// พื้นที่ตัวละครยืน
const GROUND={city:['#3b3e4e','#555a6e','tile'],gate:['#2a2d38','#d8b23a','hazard'],train:['#6b5236','#88a24e','grass'],tower:['#3a3550','#57507a','tile'],
 w_forest:['#1c2a3a','#2c4a5a','grass'],w_green:['#24361c','#4f7a2c','grass'],w_snow:['#dfe8f2','#ffffff','snow'],w_mount:['#1d2236','#2f3756','rock'],w_autumn:['#5a3418','#a8582a','leaf'],
 w_desert:['#c9a36a','#e0c088','sand'],w_rocks:['#c2b08a','#9fd0e0','sand'],w_ruin:['#3a3a34','#5a5a4a','tile'],gatered:['#2a0c0c','#5a1a14','rock'],fire:['#2a1410','#6a2a18','rock'],sky:['#0a0c1c','#1c2244','tile']};
function ground(g,key,t){const s=GROUND[key];if(!s)return;const [c1,c2,ty]=s;R(g,0,FEET-4,W,H-FEET+4,c1);
 if(ty==='tile'){R(g,0,FEET-4,W,3,c2);for(let x=0;x<W;x+=48)R(g,x,FEET,2,H,c2)}
 if(ty==='hazard'){for(let x=-((t*2)%40);x<W;x+=40){R(g,x,FEET-4,20,5,c2);R(g,x+20,FEET-4,20,5,'#1a1a1a')}}
 if(ty==='grass'||ty==='leaf'){R(g,0,FEET-4,W,4,c2);for(let i=0;i<70;i++)R(g,hr(i)*W,FEET-6-hr(i*3)*4,2,4+hr(i*5)*4,c2)}
 if(ty==='snow'){R(g,0,FEET-6,W,6,c2)}
 if(ty==='sand'){for(let i=0;i<60;i++)R(g,hr(i)*W,FEET+hr(i*7)*16,3,1,c2)}
 if(ty==='rock'){for(let i=0;i<30;i++)R(g,hr(i)*W,FEET+hr(i*7)*14,6,3,c2)}}
// ---- ฉากในอาคาร (วาดเอง) ----
function room(g,wall,wall2,floor,floor2){R(g,0,0,W,H,wall);for(let x=0;x<W;x+=24)R(g,x,0,2,FEET-40,wall2);R(g,0,FEET-40,W,8,floor2);R(g,0,FEET-32,W,H,floor);for(let x=0;x<W;x+=64)R(g,x,FEET-32,2,H,floor2)}
function win(g,x,y,w,h,day){R(g,x-4,y-4,w+8,h+8,'#5a3d2a');R(g,x,y,w,h,day?'#8fd0ff':'#16204a');if(!day){R(g,x+w-22,y+8,10,10,'#f6f0c8')}R(g,x+w/2-1,y,3,h,'#5a3d2a');R(g,x,y+h/2-1,w,3,'#5a3d2a')}
const INDOOR={
 school:(g,t,day)=>{room(g,'#e9e1cf','#ddd3bd','#b88a5a','#9a7046');R(g,150,40,280,120,'#2f4a3a');R(g,146,36,288,6,'#7a5a3a');g.fillStyle='#e8f0e8';g.font='18px Sarabun';g.textAlign='left';g.fillText('เกตแรงก์ E–S คืออะไร',176,90);g.fillText('สอบปลายภาค 12 มี.ค.',176,122);
  win(g,470,50,80,90,day);for(let i=0;i<4;i++){R(g,40+i*140,FEET-40,90,12,'#c9a06a');R(g,48+i*140,FEET-28,6,26,'#8a6a46');R(g,118+i*140,FEET-28,6,26,'#8a6a46')}},
 home:(g,t,day)=>{room(g,'#d9c7a8','#cdb994','#8a6040','#6e4a30');win(g,250,46,110,100,day);R(g,30,FEET-90,150,58,'#d7d2e6');R(g,30,FEET-104,46,18,'#fff');R(g,24,FEET-96,8,64,'#6e4a30');
  R(g,420,FEET-100,120,12,'#7a5236');R(g,430,FEET-88,8,56,'#6e4a30');R(g,522,FEET-88,8,56,'#6e4a30');R(g,450,FEET-112,30,12,'#7a3a2a');R(g,452,FEET-110,26,3,'#e8d8b0');R(g,486,FEET-128,4,16,'#f0e6c0');R(g,485,FEET-134,6,6,'#ffcf6b');R(g,90,40,70,50,'#eee');R(g,96,46,58,38,'#9ac')},
 guild:(g,t,day)=>{room(g,'#3a2c24','#46352a','#5a4030','#4a3426');R(g,40,30,160,110,'#6b4a2a');R(g,46,36,148,98,'#8a6a3c');for(let i=0;i<6;i++)R(g,54+(i%3)*46,44+(i/3|0)*44,36,34,['#efe6d0','#f6d6a0','#d9ecff'][i%3]);
  R(g,330,FEET-96,220,64,'#6e4a2c');R(g,330,FEET-100,220,8,'#8a6a3c');g.fillStyle='#ffd36b';g.font='bold 16px Mitr';g.textAlign='center';g.fillText('สมาคมฮันเตอร์',440,60);
  [[260,40],[540,40]].forEach(([x,y])=>{R(g,x,y,10,10,'#ffcf6b');g.fillStyle=`rgba(255,200,100,${.12+(t%8)/70})`;g.beginPath();g.arc(x+5,y+5,30,0,7);g.fill()})},
 hospital:(g,t,day)=>{room(g,'#e6eef6','#d8e2ee','#b9c7d6','#a4b4c6');win(g,60,46,100,90,day);R(g,330,FEET-92,200,40,'#fff');R(g,330,FEET-104,50,16,'#f4f8ff');R(g,326,FEET-52,8,20,'#8899aa');R(g,526,FEET-52,8,20,'#8899aa');
  R(g,250,30,40,40,'#fff');R(g,265,34,10,32,'#e04050');R(g,254,45,32,10,'#e04050');R(g,200,FEET-130,6,90,'#aab');R(g,190,FEET-136,26,12,'#cde')},
 casino:(g,t,day)=>{room(g,'#2a0f1e','#33142a','#3a1424','#4a1a30');for(let i=0;i<6;i++)R(g,30+i*92,26,60,6,(t+i)%4<2?'#ff4fb0':'#ffd36b');R(g,300,FEET-72,240,36,'#0f5a2a');R(g,296,FEET-76,248,6,'#8a5a2a');
  for(let i=0;i<5;i++)R(g,320+i*44,FEET-66,12,6,i%2?'#fff':'#ff3b3b');R(g,60,FEET-160,90,120,'#1a0a14');R(g,70,FEET-150,70,40,'#6fd3ff')},
 awaken:(g,t,day)=>{R(g,0,0,W,H,'#0d1430');for(let i=0;i<7;i++)R(g,30+i*80,0,30,H,'#ffffff07');room(g,'#121a3c','#18224a','#20284a','#2a3460');R(g,0,0,W,FEET-40,'#141c40');
  for(let i=0;i<7;i++)R(g,30+i*80,0,24,FEET-40,'#1a2450');R(g,370,FEET-100,50,68,'#3a3f60');R(g,360,FEET-36,70,6,'#555c86');
  const p=(t%20)/20;g.fillStyle=`rgba(120,200,255,${.45+p*.4})`;g.beginPath();g.arc(395,FEET-120,22+p*4,0,7);g.fill();R(g,388,FEET-130,6,6,'#fff')},
};
// ---- ประตูเกตแบบพิกเซล ----
const PCOL={blue:['#0b2a6b','#1a5bd0','#3f8cff','#9fd0ff'],red:['#2a0408','#8a1020','#ff3b4b','#ffb0a0'],gold:['#4a3005','#a87a10','#ffd36b','#fff3b0'],green:['#08301a','#1a7a3a','#4fd18b','#c0ffd0'],
 ice:['#1a3a5a','#6fa8d8','#cfe8ff','#ffffff'],sand:['#5a3a10','#b07a30','#f0c070','#fff0c0'],rust:['#2a1a10','#6a4a2a','#b0805a','#e0c0a0'],violet:['#1a0a3a','#5a2ab0','#b48cff','#efe0ff'],
 mist:['#3a4a5a','#7a8a9a','#b0c0d0','#e8f0f8'],dim:['#1a1f2a','#3a4050','#606878','#9098a8']};
const PCACHE={};
function portalCanvas(pc,t){
 const k=pc+'|'+(t%12);if(PCACHE[k])return PCACHE[k];const c=document.createElement('canvas');c.width=44;c.height=84;const g=c.getContext('2d');const col=PCOL[pc]||PCOL.blue;
 for(let y=0;y<84;y++)for(let x=0;x<44;x++){const dx=(x-22)/20,dy=(y-42)/40,r=Math.sqrt(dx*dx+dy*dy);if(r>1.02)continue;
  const ang=Math.atan2(dy,dx),sw=(ang*3+r*9-t*.55)%(Math.PI*2);const band=Math.floor(((Math.sin(sw)+1)/2)*3.99);
  let ci=r>.9?3:r<.35?0:[1,2,1,0][band];if(r>.86&&(x+y+t)%3===0)ci=3;if(r<.25)ci=0;g.fillStyle=col[ci];g.fillRect(x,y,1,1)}
 for(let i=0;i<6;i++){const a=t*.3+i;const px=22+Math.cos(a)*21,py=42+Math.sin(a*1.3)*40;g.fillStyle=col[3];g.fillRect(px|0,py|0,2,2)}
 PCACHE[k]=c;return c;
}
function portal(g,pc,x,y,sc,t){const c=portalCanvas(pc,t);g.save();g.imageSmoothingEnabled=false;g.shadowColor=(PCOL[pc]||PCOL.blue)[2];g.shadowBlur=24;g.drawImage(c,x-22*sc,y-84*sc,44*sc,84*sc);g.restore()}
// ---- ฤดูกาลและกลางวันกลางคืน ----
function weather(g,season,t,outdoor){if(!outdoor)return;
 const n=season==='winter'?70:season==='rain'?90:season==='spring'?25:35;
 for(let i=0;i<n;i++){const x=(hr(i)*W+t*(season==='rain'?3:1)*(1+hr(i*2)))%W,y=(hr(i*3)*H+t*(season==='rain'?14:season==='winter'?2:1.5)*(1+hr(i*5)))%H;
  if(season==='rain')R(g,x,y,1,8,'rgba(170,200,255,.55)');else if(season==='winter')R(g,x,y,2,2,'rgba(255,255,255,.85)');else if(season==='spring')R(g,x,y,3,2,'rgba(255,170,200,.8)');else R(g,x,y,3,3,'rgba(210,120,50,.8)')}}
function nightTint(g,night){if(night){g.fillStyle='rgba(10,16,60,.38)';g.fillRect(0,0,W,H)}}
// ---- วาดฉากหลัก ----
const OUT_BG={city:'city',gate:'gate',gatezone:'gate',train:'train',tower:'tower',sky:'sky',fire:'fire',death:'death'};
function sceneKey(sc){if(sc==='dungeon')return (P&&P.world)||'w_forest';if(sc==='gatezone')return 'gate';return sc}
function drawScene(cv,sc,P,t,night){
 if(!cv)return;const g=cv.getContext('2d');g.imageSmoothingEnabled=false;
 const key=sceneKey(sc);const indoor=INDOOR[key];
 if(indoor)indoor(g,t,!night);else{drawLayers(g,MF.bg[key]?key:'city',t,!P||key==='road');ground(g,key,t)}
 if(key==='gate')portal(g,'blue',440,FEET-6,1.9,t);
 if(key==='gatered')portal(g,'red',470,FEET-6,1.6,t);
 if(key==='sky'){g.strokeStyle='rgba(180,140,255,.6)';g.beginPath();[[280,60],[330,36],[380,70],[440,40],[500,78]].forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.stroke()}
 if(!P){weather(g,'spring',t,true);return}
 if(key==='death'){R(g,270,236,36,70,'#4a4f5a');R(g,256,252,64,12,'#4a4f5a');nightTint(g,night);return}
 const walk=key==='road';
 const hero=key==='train'?'Attack':walk?'Walk':'Idle';
 let hx=indoor?200:170;
 // คู่หูเดินตามหลัง
 P.party.forEach((id,i)=>{const x=person(id);if(x&&x.alive)person4(g,x.look,x.tint,walk?'Walk':'Idle',t+i*3,hx-70-i*60,false,null,1.8)});
 person4(g,P.look,P.tint,hero,t,hx,false,P.name,2,P.cls);
 if(key==='guild')person4(g,CLERK,0,'Idle',t,470,true,'เจ้าหน้าที่สมาคม');
 const mon=key==='fire'?'wolf_b':(sc==='dungeon'||key==='gatered')?P.mon:null;
 if(mon&&MF.mons[mon]){shadow(g,420,FEET,40);spr(g,MF.mons[mon].Idle,t,420,FEET,2,true)}
 weather(g,SEASON(P.m),t,!indoor);nightTint(g,night);
 if(P.talk){const x=person(P.talk.who);if(x)talkInset(g,x,P.talk.line,t,indoor?key:'city',night)}
}
// หน้าต่างเล็กตอนคุยกับคน
function talkInset(g,x,line,t,key,night){
 const ix=300,iy=12,iw=264,ih=190;g.save();g.fillStyle='#2a2238';g.fillRect(ix-4,iy-4,iw+8,ih+8);g.fillStyle='#f0e6d0';g.fillRect(ix-2,iy-2,iw+4,ih+4);
 g.beginPath();g.rect(ix,iy,iw,ih);g.clip();g.translate(ix,iy);g.scale(iw/W,ih/H);
 const draw=INDOOR[key];if(draw)draw(g,t,!night);else{drawLayers(g,'city',0,false);ground(g,'city',0)}
 person4(g,P.look,P.tint,'Idle',t,200,false,P.name);person4(g,x.look,x.tint,'Idle',t+4,380,true,`${x.n} (${x.role})`);
 if(line)bubble(g,line,380,FEET-160);g.restore();
}
// ---- ฉากต่อสู้ ----
let BATTLE=null;
function drawBattle(cv,P,B){
 const g=cv.getContext('2d');g.imageSmoothingEnabled=false;const key=B.world==='tower'?'tower':B.world;
 bgWide(g,key,B.t<10?B.t:10,true,true);g.save();g.translate(CX,0);
 const t=B.t,foe=B.foe,M=foe?null:MF.mons[B.mon],sc=B.boss?2.6:2,fx=MF.fx[FX_OF[P.cls]||'wind'],cl=P.cls||'sword';
 let hx=150+Math.min(t,10)*10,ha='Walk',hf=t,ma='Idle',mf=t,mal=1,mx=430,hflip=false,shake=0;
 if(t>=10&&t<22){ha='Attack';hf=Math.min(2,Math.floor((t-10)/3));
  if(cl==='assassin'){hx=t<13?250:mx+60;hflip=t>=13} if(cl==='sword'||cl==='tank')hx=Math.min(330,250+(t-10)*20);
  if(t>=14){ma='Hurt';mf=t-14;shake=t%2?3:-3}}
 if(t>=22){ha=B.win?'Idle':(t<26?'Idle':'Hurt');hf=B.win?t:t-26;if(cl==='assassin'&&t<24){hx=mx+60;hflip=true}
  if(B.win){ma='Dead';mf=Math.min(t-22,(M?M.Dead.n:3)-1);mal=t<30?1:Math.max(0,1-(t-30)/6)}else{ma='Attack';mf=t-22}}
 // คู่หู
 P.party.forEach((id,i)=>{const x=person(id);if(x&&x.alive)person4(g,x.look,x.tint,t>=12&&t<22?'Attack':'Idle',t+i*2,hx-80-i*55,false,null,1.8)});
 // มอนสเตอร์หรือคน
 shadow(g,mx,FEET,44);
 if(M)spr(g,ma==='Attack'?M.Attack_1:M[ma],mf,mx+shake,FEET,sc,true,mal);
 else{const look=B.foeLook||THUG;drawHuman(g,look,ma==='Attack'?'attack':ma==='Dead'||ma==='Hurt'?'hurt':'idle',ma==='Attack'?Math.min(2,mf):mf,mx+shake,FEET,2,true,mal,'sword')}
 shadow(g,hx,FEET);drawHuman(g,P.look,PN[ha]||'idle',hf,hx,FEET,2,hflip,1,P.cls);
 // ท่าโจมตีตามอาชีพ
 const p=(t-12)/6;
 if(cl==='bow'&&t>=12&&t<18){const x=hx+40+(mx-hx-40)*p;R(g,x,FEET-70,26,2,'#e8d8b0');R(g,x+26,FEET-72,5,6,'#cfd8e8')}
 if(cl==='mage'&&t>=12&&t<18){const x=hx+40+(mx-hx-40)*p;g.fillStyle='rgba(255,140,40,.9)';g.beginPath();g.arc(x,FEET-80,12,0,7);g.fill();g.fillStyle='#fff3b0';g.beginPath();g.arc(x,FEET-80,5,0,7);g.fill()}
 if(cl==='healer'&&t>=10&&t<22){for(let i=0;i<10;i++){const a=i/10*6.28+t*.4;R(g,hx+Math.cos(a)*40,FEET-60+Math.sin(a)*40,3,3,'#9fffc8')}}
 if(cl==='tank'&&t>=10&&t<16){g.strokeStyle='rgba(120,200,255,.8)';g.lineWidth=4;g.beginPath();g.arc(hx+20,FEET-60,50,-1.2,1.2);g.stroke()}
 if(fx.px){if(t>=13&&t<26){const im=IMG[fx.src],fr=Math.min(fx.n-1,Math.floor((t-13)*fx.n/13)),S=2.6;if(im&&im.complete)g.drawImage(im,fr*fx.w,fx.y,fx.w,fx.h,mx-fx.px*S,FEET-55-fx.py*S,fx.w*S,fx.h*S)}}else if(t>=14&&t<14+fx.n){const im=IMG[fx.src];if(im.complete)g.drawImage(im,(t-14)*fx.w,0,fx.w,fx.h,mx-115,FEET-200,fx.w*1.15,fx.h*1.15)}
 g.restore();
 // หลอดเลือด
 const hpP=Math.max(0,P.hp/maxHp(P)),mhp=t<14?1:t<22?.55:B.win?0:.4;
 hb(g,20,64,'ท่าน',hpP,'#4fd18b');hb(g,W-220,64,B.foe?B.foeName:MON_N[B.mon]||'ผู้พิทักษ์',mhp,'#ff5d6c');
 if(t>=30){g.font='bold 40px Mitr, sans-serif';g.textAlign='center';g.lineWidth=7;g.strokeStyle='#000';const s=B.win?'ชนะ!':'ถอยทัพ';g.strokeText(s,W/2,110);g.fillStyle=B.win?'#ffd36b':'#ff5d6c';g.fillText(s,W/2,110)}
}
function hb(g,x,y,n,v,c){R(g,x,y,200,22,'rgba(0,0,0,.6)');R(g,x+3,y+14,194,5,'#222');R(g,x+3,y+14,194*v,5,c);g.font='12px Sarabun';g.fillStyle='#fff';g.textAlign='left';g.fillText(n,x+5,y+11)}
