// =============== v8: คนรอบตัวแก่ลงและจากไป (แบบ WoX) ===============
function guessAge(x){const a=ageY(P),r=x.role||'';if(/แม่|พ่อ|ผอ|แม่ชี|ป้า|ลุง|อาจารย์/.test(r))return a+ri(24,34);if(/น้อง/.test(r))return Math.max(1,a-ri(1,4));if(/พี่/.test(r))return a+ri(1,4);return a+ri(-2,6)}
const isKin=x=>/แม่|พ่อ|น้อง|พี่|แม่ชี|ผอ|อาจารย์|เพื่อนสนิท|คู่/.test(x.role||'');
QUESTS.kinDying=(d)=>{const x=person(d.id);if(!x||!x.alive)return;ask({title:'ผู้ใกล้ชิดใกล้สิ้นอายุขัย',rare:2,chain:'ครอบครัว',who:x.id,sc:'home',text:`${x.n} (${x.role}) อายุ ${x.age} ปี ผมขาวโพลน ลุกเดินช้าลงทุกวัน ท่านรู้ในใจว่าเวลาที่เหลืออยู่ด้วยกันมีไม่มากแล้ว ผลไม้พันปีจากตลาดประมูลอาจยื้อเวลาได้อีกหลายปี`,opts:[
 {t:'อยู่ข้าง ๆ ทุกวันที่เหลือ',ok:{r:'ท่านพาไปดูทะเลสาบที่ชอบ เล่าเรื่องเก่า ๆ จนดึก',d:{aff:[[x.id,15]],tr:{kind:8}},line:'ขอบใจนะ ที่ยังจำได้'}},
 {t:'ซื้อผลไม้พันปี',cost:{gold:3000},sub:'ยื้อเวลาได้ราว 6-10 ปี',ok:{r:'สีหน้าของเขาดีขึ้นในสามวัน',d:{aff:[[x.id,10]]},then:()=>{x.dying=null;x.age-=ri(6,10)}}},
 {t:'ไปทำงานต่อ ส่งเงินกลับบ้านแทน',ok:{r:'ท่านส่งเงินกลับบ้านทุกเดือน แต่ไม่ได้กลับไปเอง',d:{gold:-200,aff:[[x.id,-5]]}}}]})};
QUESTS.kinFuneral=(d)=>{const x=person(d.id);if(!x)return;ask({title:`งานศพของ${x.n}`,rare:2,chain:'ครอบครัว',who:x.id,sc:'home',text:`${x.n} (${x.role}) จากไปอย่างสงบตอนอายุ ${x.age} ปี คนในหมู่บ้านมากันเต็มลาน`,opts:[
 {t:'กล่าวคำอำลา',chk:['cha','easy'],ok:{r:'ทุกคนร้องไห้ตามคำพูดของท่าน',d:{fame:2,tr:{kind:5}}},no:{r:'ท่านพูดได้แค่ประโยคเดียวแล้วเสียงก็หายไป',d:{}}},
 {t:'เก็บของที่ระลึกไว้หนึ่งชิ้น',ok:{r:'ท่านได้ปิ่นไม้เก่า ๆ มาพกติดตัว',d:{luk:2}}},
 {t:'กลับไปฝึกทันทีหลังงานจบ',ok:{r:'ท่านฝึกจนมือแตก เพราะไม่อยากคิดถึงอะไร',d:{str:2,tr:{kind:-5}}}}]})};
const _tick9b=tick;tick=function(){const was=P&&P.m;_tick9b();if(!P||!P.alive||P.m===was)return;
 P.people.forEach(x=>{if(x.age==null)x.age=guessAge(x)});
 if(mon(P)!==0)return;
 P.people.forEach(x=>{if(!x.alive)return;x.age++;
  if(x.dying&&P.m>=x.dying){x.alive=false;x.dying=null;P.party=P.party.filter(id=>id!==x.id);log(`${x.n} (${x.role}) จากไปด้วยอายุ ${x.age} ปี`,'c-bad');if(isKin(x)&&x.aff>=20)schedule('kinFuneral',0,{id:x.id});return}
  if(!x.dying&&!x.immortal&&x.age>=62&&RNG()<(x.age-58)/220){x.dying=P.m+ri(6,14);if(isKin(x)&&x.aff>=20)schedule('kinDying',ri(0,2),{id:x.id})}})};
