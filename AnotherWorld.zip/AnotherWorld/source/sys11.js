// =============== v10: วิชา · กิลด์ · ความสัมพันธ์ลึก · เรื่องของเหล่าเทพ ===============
// ---------- วิชา ----------
const ELEM={fire:['ไฟ','#ff7a4a'],water:['น้ำ','#4ab0f0'],wind:['ลม','#7ad0a0'],earth:['ดิน','#c8a060'],thunder:['สายฟ้า','#b48cff'],light:['แสง','#ffd36b'],dark:['มืด','#9a7ab8']};
const SKILL_SLOTS=[['core','วิชาฝึกมานา'],['atk1','วิชาต่อสู้ 1'],['atk2','วิชาต่อสู้ 2'],['move','วิชาตัวเบา'],['def','วิชาป้องกันกาย'],['sup','วิชาสนับสนุน']];
const TIER_PW=[3,6,10,16,25];
const SKILLS=[
 // ฝึกมานา: EXP และมานา
 {id:'c_breath',n:'ลมหายใจสามจังหวะ',slot:'core',el:'wind',t:0,ic:'🌬️',d:'EXP +5% มานาโตเร็วขึ้นเล็กน้อย'},
 {id:'c_ember',n:'คัมภีร์ถ่านไฟในทรวง',slot:'core',el:'fire',t:1,ic:'📜',d:'EXP +10%'},
 {id:'c_tide',n:'คัมภีร์น้ำขึ้นน้ำลง',slot:'core',el:'water',t:2,ic:'📜',d:'EXP +15% ฟื้นพลังชีวิตเร็วขึ้น'},
 {id:'c_star',n:'คัมภีร์ดาราหมุนเวียน',slot:'core',el:'light',t:3,ic:'🌟',d:'EXP +22% มานา +1 ทุกปี'},
 {id:'c_abyss',n:'คัมภีร์เหวลึกกลืนกิน',slot:'core',el:'dark',t:4,ic:'🌑',d:'EXP +35% แต่กรรมลดทุกปี'},
 // ต่อสู้
 {id:'a_slash',n:'ดาบตัดสายลม',slot:'atk',el:'wind',t:0,ic:'🗡️',d:'พลังต่อสู้ +3%'},
 {id:'a_fireball',n:'ลูกไฟพื้นฐาน',slot:'atk',el:'fire',t:0,ic:'🔥',d:'พลังต่อสู้ +3%'},
 {id:'a_stone',n:'หมัดหินผา',slot:'atk',el:'earth',t:1,ic:'👊',d:'พลังต่อสู้ +6%'},
 {id:'a_frost',n:'หอกน้ำแข็งพันดอก',slot:'atk',el:'water',t:1,ic:'❄️',d:'พลังต่อสู้ +6%'},
 {id:'a_thunder',n:'สายฟ้าเก้าสาย',slot:'atk',el:'thunder',t:2,ic:'⚡',d:'พลังต่อสู้ +10%'},
 {id:'a_crescent',n:'ดาบจันทร์เสี้ยวคืนสูญ',slot:'atk',el:'dark',t:2,ic:'🌘',d:'พลังต่อสู้ +10%'},
 {id:'a_sun',n:'หมื่นดาบคืนสู่หนึ่ง',slot:'atk',el:'light',t:3,ic:'☀️',d:'พลังต่อสู้ +16%'},
 {id:'a_dragon',n:'เพลิงมังกรเผาฟ้า',slot:'atk',el:'fire',t:3,ic:'🐉',d:'พลังต่อสู้ +16%'},
 {id:'a_god',n:'ดาบเทพสังหารมาร',slot:'atk',el:'light',t:4,ic:'⚔️',d:'พลังต่อสู้ +25% ต่อจอมมารและแม่ทัพ +15%'},
 // ตัวเบา
 {id:'m_step',n:'ก้าวใบไม้ร่วง',slot:'move',el:'wind',t:0,ic:'🍃',d:'ความเร็วในการทดสอบ +5%'},
 {id:'m_shadow',n:'เงาไร้รอยเท้า',slot:'move',el:'dark',t:2,ic:'👣',d:'ความเร็วในการทดสอบ +12%'},
 {id:'m_cloud',n:'เหินเมฆาเจ็ดชั้น',slot:'move',el:'wind',t:3,ic:'☁️',d:'ความเร็วในการทดสอบ +18%'},
 // ป้องกัน
 {id:'d_skin',n:'หนังเหล็กพื้นฐาน',slot:'def',el:'earth',t:0,ic:'🛡️',d:'พลังชีวิตสูงสุด +5%'},
 {id:'d_ice',n:'เกราะน้ำแข็งนิรันดร์',slot:'def',el:'water',t:2,ic:'🧊',d:'พลังชีวิตสูงสุด +15%'},
 {id:'d_gold',n:'กายทองคำไม่แตกสลาย',slot:'def',el:'light',t:3,ic:'🟡',d:'พลังชีวิตสูงสุด +25%'},
 {id:'d_primal',n:'กายาปฐมกาล',slot:'def',el:'earth',t:4,ic:'🪨',d:'พลังชีวิตสูงสุด +40%'},
 // สนับสนุน
 {id:'s_herb',n:'ตำราสมุนไพรเบื้องต้น',slot:'sup',el:'earth',t:0,ic:'🌿',d:'ฟื้นพลังชีวิตเร็วขึ้น 20%'},
 {id:'s_tongue',n:'ศิลปะการเจรจาของพ่อค้า',slot:'sup',el:'wind',t:1,ic:'💬',d:'เสน่ห์ในการทดสอบ +8% เงิน +10%'},
 {id:'s_rune',n:'ยันต์อัสนีเก้าชั้น',slot:'sup',el:'thunder',t:2,ic:'🧧',d:'ปัญญาในการทดสอบ +10%'},
 {id:'s_forge',n:'ตำราหลอมอาวุธฟ้าดิน',slot:'sup',el:'fire',t:3,ic:'🔨',d:'พลังต่อสู้ +8%'},
 {id:'s_bless',n:'บทสวดของเหล่าเทพ',slot:'sup',el:'light',t:3,ic:'🙏',d:'ความชอบของเทพทุกองค์เพิ่มเร็วขึ้น'}];
const SK=id=>SKILLS.find(s=>s.id===id);
function learnSkill(id,src){const s=SK(id);if(!s)return;P.skills=P.skills||[];if(P.skills.includes(id))return;P.skills.push(id);log(`ได้เรียนวิชา "${s.n}" (${TIERS[s.t].n} · ธาตุ${ELEM[s.el][0]})${src?' จาก'+src:''}`,'c-gold');autoEquip()}
function slotOk(s,slot){return s.slot===slot||(s.slot==='atk'&&(slot==='atk1'||slot==='atk2'))}
function skillVal(s){return TIER_PW[s.t]*(P.elem===s.el?1.5:1)}
function autoEquip(){P.equip=P.equip||{};SKILL_SLOTS.forEach(([slot])=>{const used=Object.entries(P.equip).filter(([k])=>k!==slot).map(([,v])=>v);const best=(P.skills||[]).map(SK).filter(s=>s&&slotOk(s,slot)&&!used.includes(s.id)).sort((a,b)=>skillVal(b)-skillVal(a))[0];if(best&&(!P.equip[slot]||!SK(P.equip[slot])||skillVal(best)>skillVal(SK(P.equip[slot]))))P.equip[slot]=best.id});applySkillMods()}
function eqSkills(){return Object.values(P.equip||{}).map(SK).filter(Boolean)}
function skillPow(){return eqSkills().filter(s=>s.slot==='atk').reduce((a,s)=>a+skillVal(s),0)/100}
function skillHp(){return eqSkills().filter(s=>s.slot==='def').reduce((a,s)=>a+[5,10,15,25,40][s.t]*(P.elem===s.el?1.5:1),0)/100}
function skillExp(){return eqSkills().filter(s=>s.slot==='core').reduce((a,s)=>a+[5,10,15,22,35][s.t]*(P.elem===s.el?1.5:1),0)/100}
const _pw11=power;power=function(p){const v=_pw11(p);return p===P&&p.rank>=0?Math.round(v*(1+skillPow()+(Object.values(P.equip||{}).includes('s_forge')?.08:0))):v};
const SK_MOD={core:{},atk:{},move:{agi:[.05,.08,.12,.18,.25]},def:{},sup:{}};
function applySkillMods(){P.mul=P.mul||{};P.chk=P.chk||{};const o=P.skApplied||{hp:0,heal:0,agi:0,cha:0,int:0};
 const n={hp:skillHp(),heal:0,agi:0,cha:0,int:0};const eq=Object.values(P.equip||{});
 eqSkills().forEach(s=>{if(s.slot==='move')n.agi+=[.05,.08,.12,.18,.25][s.t]});
 if(eq.includes('s_herb'))n.heal+=.2;if(eq.includes('c_tide'))n.heal+=.2;if(eq.includes('s_tongue'))n.cha+=.08;if(eq.includes('s_rune'))n.int+=.1;
 P.mul.hp=(P.mul.hp||0)-o.hp+n.hp;P.mul.heal=(P.mul.heal||0)-o.heal+n.heal;['agi','cha','int'].forEach(k=>P.chk[k]=(P.chk[k]||0)-o[k]+n[k]);P.skApplied=n}
const _af11=addFavor;addFavor=function(like,n){_af11(like,n>0&&P&&Object.values(P.equip||{}).includes('s_bless')?Math.round(n*1.4):n)};
const _ge11=gainExp;gainExp=function(n){_ge11(n*(1+skillExp()))};
// ---------- กิลด์ ----------
const GUILDS=[
 {id:'phoenix',n:'ราชาวิหค',el:'wind',big:1,need:2,base:.35,d:'กิลด์อันดับหนึ่งของอาณาจักร รับยาก แต่คลังวิชาลึกที่สุด',sk:['m_cloud','a_sun','c_star']},
 {id:'iron',n:'ดาบเหล็กดำ',el:'earth',need:1,base:.55,d:'นักรบเกราะหนัก ชอบคนที่ทนเจ็บได้',sk:['d_gold','a_stone','d_primal']},
 {id:'leaf',n:'ใบไม้ขาว',el:'light',need:0,base:.6,d:'กิลด์นักรักษาและนักบวช ต้องมีกรรมดี',sk:['s_bless','c_tide','d_ice'],karma:5},
 {id:'fang',n:'เขี้ยวหิมะ',el:'water',need:1,base:.55,d:'นักล่าสัตว์อสูรทางเหนือ ทำงานเป็นฝูง',sk:['a_frost','d_ice','m_step']},
 {id:'night',n:'กลีบราตรี',el:'dark',need:1,base:.5,d:'กิลด์ใต้ดิน รับงานที่กิลด์อื่นไม่รับ ต้องมีกรรมต่ำ',sk:['m_shadow','a_crescent','c_abyss'],karmaMax:-10}];
const G_RANKS=['สมาชิกฝึกหัด','สมาชิก','สมาชิกอาวุโส','แกนนำ','ผู้อาวุโส','รองหัวหน้า','หัวหน้ากิลด์'],G_NEED=[0,40,120,260,500,900,1500],G_RANKREQ=[0,0,1,2,3,4,4];
const GU=()=>GUILDS.find(g=>g.n===P.guild);
function examChance(g,gift){let c=g.base+(P.rank-g.need)*.12+P.fame/400+(gift?.3:0);if(g.karma!=null&&P.karma<g.karma)c-=.4;if(g.karmaMax!=null&&P.karma>g.karmaMax)c-=.5;return clamp(c,.03,.95)}
function guildExam(id,gift){const g=GUILDS.find(x=>x.id===id);if(!g||P.guild||P.rank<0||(P.flags['gex_'+id]>P.m))return;const cost=gift?(g.big?300:150):0;if(P.gold<cost)return;P.gold-=cost;
 const c=examChance(g,gift);ask({title:`สอบเข้ากิลด์${g.n}`,rare:2,chain:'กิลด์',sc:'guild',text:`ผู้คุมสอบของกิลด์${g.n}พาท่านเข้าห้องทดสอบ ${g.d}`,opts:[
  {t:'เข้ารับการทดสอบ',sub:`โอกาสผ่าน ${Math.round(c*100)}%`,ok:()=>RNG()<c?{r:`ท่านผ่านการทดสอบ ได้เป็น${G_RANKS[0]}ของกิลด์${g.n}`,c:'c-gold',then:()=>{P.guild=g.n;P.gRank=0;P.contrib=0;const f=SKILLS.filter(x=>x.el===g.el&&x.t<=1&&!(P.skills||[]).includes(x.id));if(f.length)learnSkill(pick(f).id,'กิลด์'+g.n)}}:{r:'ท่านสอบตก ต้องรอหนึ่งปีถึงสอบใหม่ได้',c:'c-bad',then:()=>{P.flags['gex_'+id]=P.m+12}}}]})}
const guildStock=()=>{const g=GU();return g?[...new Set([...SKILLS.filter(x=>x.el===g.el).map(x=>x.id),...g.sk])]:[]};
const skCost=s=>[20,60,160,400,900][s.t];
function guildStore(id){if(!guildStock().includes(id))return;const g=GU();if(!g)return;const s=SK(id);const cost=skCost(s);if(P.contrib<cost||(P.skills||[]).includes(id))return;if(s.t>=3&&P.gRank<2)return;P.contrib-=cost;learnSkill(id,'คลังกิลด์')}
function leaveGuild(){if(!P.guild)return;log(`ท่านลาออกจากกิลด์${P.guild}`,'c-bad');P.guild=null;P.gRank=0;P.contrib=0}
QUESTS.guildPromo=()=>{const g=GU();if(!g)return;const r=(P.gRank||0)+1;if(r>=G_RANKS.length)return;
 ask({title:`สอบเลื่อนขั้นเป็น${G_RANKS[r]}`,rare:2,chain:'กิลด์',sc:'guild',text:`แต้มผลงานของท่านในกิลด์${g.n}ถึงเกณฑ์แล้ว ผู้อาวุโสสามคนรอดูฝีมืออยู่ในลานประลอง`,opts:[
  {t:'ประลองกับผู้อาวุโส',fight:{diff:GATE_DIFF[Math.min(5,Math.max(0,P.rank))]*.8,world:'train',safe:1,foe:'thug'},ok:{r:`ท่านได้เป็น${G_RANKS[r]}`,c:'c-gold',d:{fame:3+r},then:()=>{P.gRank=r;if(r>=3&&g.sk[1])learnSkill(g.sk[1],'การเลื่อนขั้นในกิลด์');if(r===6)log(`ท่านคือหัวหน้ากิลด์${g.n}`,'c-gold')}},no:{r:'ยังไม่ผ่าน ลองใหม่ปีหน้า',then:()=>{P.flags.gpcd=P.m+12}}},
  {t:'เสนอผลงานแทนการประลอง',chk:['cha','mid'],ok:{r:`สภากิลด์ยอมรับผลงานของท่าน ได้เป็น${G_RANKS[r]}`,then:()=>{P.gRank=r}},no:{r:'สภากิลด์ยังไม่พอใจ',then:()=>{P.flags.gpcd=P.m+12}}}]})};
QUESTS.guildCouncil=()=>{const g=GU();if(!g||P.gRank<5)return;ask({title:`สภากิลด์${g.n}ประจำปี`,rare:2,chain:'กิลด์',sc:'guild',text:'ผู้อาวุโสทุกคนรอคำสั่งของท่านสำหรับปีนี้',opts:[
 {t:'เปิดรับสมาชิกใหม่ทั่วอาณาจักร',ok:{r:'ลานกิลด์เต็มไปด้วยหน้าใหม่',d:{fame:6,gold:-300}}},
 {t:'ส่งทีมไปกวาดดันเจี้ยนชายแดน',ok:{r:'คลังกิลด์เต็มขึ้น แต่สมาชิกสองคนไม่กลับมา',d:{gold:1200,karma:-3}}},
 {t:'แจกข้าวและยาแก่ชาวเมือง',ok:{r:'ชาวเมืองยกย่องกิลด์ของท่าน',d:{karma:6,gold:-400},then:()=>addTF(10)}},
 {t:'แอบยักยอกคลังกิลด์',ok:{r:'ไม่มีใครรู้ ยกเว้นเหล่าเทพ',d:{gold:800,karma:-10,fav:{evil:8}}}}]})};
// ---------- ความสัมพันธ์ ----------
const REL_N={friend:'เพื่อน',bond:'สหายสนิท',lover:'คนรัก',fiance:'คู่หมั้น',spouse:'คู่ครอง'};
const isFamily=x=>x.fam===0?false:/^(แม่|พ่อ|น้อง|พี่|ลูกชาย|ลูกสาว|ผอ|แม่ชี|ปู่|ย่า)/.test(x.role||'');
function relLabel(x){if(x.rel&&REL_N[x.rel])return REL_N[x.rel];const a=x.aff;return a>=60?'สหายสนิท':a>=30?'เพื่อน':a>=0?'คนรู้จัก':a>-40?'ไม่ถูกกัน':'ศัตรู'}
function affGain(x,n){if(n>0&&x.aff>=59&&!x.bond&&!isFamily(x)&&!x.rel){if(!P.q.some(q=>q.k==='bondTest'&&q.data.id===x.id)&&!(x.bondCd>P.m))schedule('bondTest',ri(1,4),{id:x.id});return}x.aff=clamp(x.aff+Math.round(n*(x.aff>60?.6:1)),-100,100)}
function canRomance(x){return x.alive&&!isFamily(x)&&ageY(P)>=16&&(x.age||18)>=16&&!(P.people.some(y=>y.rel==='spouse')&&x.rel!=='spouse')}
function interact(id,act){const x=person(id);if(!x||!x.alive||PENDING.length)return;P.talked=P.talked||{};const key=act+id;if(['talk','drink','spar','court'].includes(act)&&P.talked[key]===P.m)return;P.talked[key]=P.m;
 const say=l=>{P.talk={who:x.id,line:l,until:P.m+1}};
 if(act==='talk'){affGain(x,ri(2,5));log(`คุยกับ${x.n}จนดึก`);say(pick(['วันนี้เป็นยังไงบ้าง','ได้ยินข่าวลือเรื่องดันเจี้ยนใหม่ไหม','อย่าหักโหมนักล่ะ','มีเรื่องจะเล่าให้ฟังเยอะเลย']))}
 if(act==='gift'){if(P.gold<50)return;P.gold-=50;affGain(x,ri(5,9));log(`ให้ของขวัญ${x.n} (เงิน-50)`,'c-good');say('ให้ข้าจริงเหรอ')}
 if(act==='drink'){if(P.gold<10)return;P.gold-=10;affGain(x,ri(3,6));log(`ดื่มกับ${x.n}ที่โรงเตี๊ยม`);if(RNG()<.25)x.spark=(x.spark||0)+(canRomance(x)?1:0);say('อีกจอก!')}
 if(act==='spar'){const ok=RNG()<.5+(power(P)-((x.rank+1)*60))/400;affGain(x,3);if(P.rank>=0)gainExp(20+P.lvl*3);log(`ประลองกับ${x.n} ${ok?'ท่านชนะ':'ท่านแพ้'}`,ok?'c-good':'');say(ok?'ฝีมือดีขึ้นเยอะนะ':'ยังอ่อนหัดอยู่')}
 if(act==='court'&&canRomance(x)){if(P.gold<20)return;P.gold-=20;const ok=RNG()<.45+P.cha/250+x.aff/300;if(ok){x.spark=(x.spark||0)+1;affGain(x,3);log(`ท่านพา${x.n}ไปเดินริมทะเลสาบ หัวใจเต้นแรงทั้งคู่ (ประกายรัก ${x.spark})`,'c-star');say('...ไปเดินด้วยกันอีกนะ')}else{affGain(x,-2);log(`${x.n}ดูไม่ค่อยสนใจ`);say('ข้ายังไม่พร้อม')}}
 if(act==='confess'&&canRomance(x)&&(x.spark||0)>=1&&x.aff>=40&&!x.rel){const ok=RNG()<.4+x.aff/150+x.spark*.08;if(ok){x.rel='lover';x.aff=Math.min(100,x.aff+10);log(`${x.n}ตอบรับคำสารภาพรักของท่าน`,'c-gold');say('ข้ารอคำนี้มานานแล้ว')}else{x.aff-=8;log(`${x.n}ปฏิเสธอย่างสุภาพ`,'c-bad');say('ขอโทษนะ')}}
 if(act==='propose'&&x.rel==='lover'&&(x.spark||0)>=3&&x.aff>=60){const ok=RNG()<.5+x.aff/200;if(ok){x.rel='fiance';log(`${x.n}รับแหวนหมั้นของท่าน`,'c-gold');say('ใช่ ข้าตกลง')}else{log(`${x.n}ขอเวลาคิดอีกสักพัก`);say('ขอเวลาอีกนิด')}}
 if(act==='marry'&&x.rel==='fiance'&&P.gold>=500)schedule('wedding',0,{id:x.id});
 if(act==='party'){if(P.party.includes(x.id))P.party=P.party.filter(i=>i!==x.id);else if(P.party.length<3&&x.hunter&&x.aff>=40)P.party.push(x.id)}}
QUESTS.wedding=(d)=>{const x=person(d.id);if(!x||x.rel!=='fiance'||P.gold<500)return;ask({title:`งานแต่งงานกับ${x.n}`,rare:3,chain:'คู่ครอง',who:x.id,sc:'shrine',text:`วิหารแห่งทวยเทพประดับดอกไม้ขาวเต็มทางเดิน ${x.n}ในชุดแต่งงานยืนรออยู่ปลายทาง แขกที่มาร่วมงานส่งเสียงเชียร์ เหล่าเทพหลายองค์แอบมองลงมา`,opts:[
 {t:'จัดงานใหญ่เชิญทั้งเมือง',cost:{gold:500},ok:{r:'งานเลี้ยงยาวสามวันสามคืน ทั้งเมืองพูดถึงไปอีกปี',c:'c-gold',d:{fame:5,fav:{kind:8}},then:()=>marry(x)}},
 {t:'จัดเล็ก ๆ เฉพาะคนสนิท',cost:{gold:500},ok:{r:'คืนนั้นมีแค่เสียงหัวเราะของคนที่รักท่านจริง ๆ',c:'c-gold',d:{karma:3},then:()=>marry(x)}},
 {t:'สาบานกันใต้ต้นไม้ใหญ่ ไม่ต้องมีงาน',ok:{r:'มีแค่ท่าน เขา และนกสองตัวเป็นพยาน',c:'c-gold',then:()=>marry(x)}}]})};
function marry(x){x.rel='spouse';x.aff=Math.min(100,x.aff+15);P.homeMark={k:'wedding',until:P.m+3};log(`ท่านแต่งงานกับ${x.n}`,'c-gold')}
QUESTS.bondTest=(d)=>{const x=person(d.id);if(!x||!x.alive||x.bond)return;const kind=RNG()<.15?'loan':pick(['secret','side']);
 const T={loan:{text:`${x.n}มาหาท่านกลางดึก หน้าซีด "ข้าติดหนี้กิลด์โจร ถ้าไม่จ่ายภายในสามวัน..."`,o:[{t:'ให้ยืม 300 ทอง',cost:{gold:300},ok:{r:`${x.n}คุกเข่าขอบคุณ สองปีต่อมาเขาคืนเงินพร้อมดอกเบี้ย`,then:()=>bondPass(x,true)}},{t:'ไปคุยกับกิลด์โจรด้วยกัน',chk:['cha','mid'],ok:{r:'พวกมันยอมยืดเวลาให้',then:()=>bondPass(x,true)},no:{r:'การเจรจาล้มเหลว เขาต้องหนีออกจากเมือง',then:()=>bondPass(x,false)}},{t:'ปฏิเสธ',ok:{r:`${x.n}เดินจากไปเงียบ ๆ`,then:()=>bondPass(x,false)}}]},
  secret:{text:`${x.n}เล่าความลับที่ไม่เคยบอกใคร เขาเคยขโมยของจากวิหารตอนเด็กเพื่อเลี้ยงน้อง แล้ววันนี้นักบวชคนหนึ่งเริ่มสงสัย`,o:[{t:'สาบานว่าจะเก็บความลับ',ok:{r:'สายตาที่เขามองท่านเปลี่ยนไปตลอดกาล',then:()=>bondPass(x,true)}},{t:'แนะนำให้ไปสารภาพ',chk:['cha','easy'],ok:{r:'นักบวชให้อภัย และเขาโล่งใจที่สุดในชีวิต',then:()=>bondPass(x,true)},no:{r:'เขาคิดว่าท่านไม่เข้าใจ',then:()=>bondPass(x,false)}}]},
  side:{text:`${x.n}มีเรื่องกับนักผจญภัยแรงก์สูงกว่าในโรงเตี๊ยม ทุกคนหันมามองว่าท่านจะยืนข้างใคร`,o:[{t:'ยืนข้างเพื่อน',fight:{diff:GATE_DIFF[Math.max(0,Math.min(5,P.rank+1))]*.6,foe:'thug',world:'city',safe:1},ok:{r:'ทั้งคู่เดินออกจากโรงเตี๊ยมอย่างผู้ชนะ',then:()=>bondPass(x,true)},no:{r:'แพ้ แต่ไม่ทิ้งกัน',then:()=>bondPass(x,true)}},{t:'ห้ามทั้งสองฝ่าย',chk:['cha','mid'],ok:{r:'ทุกคนนั่งลงดื่มด้วยกัน',then:()=>bondPass(x,true)},no:{r:'เพื่อนรู้สึกว่าท่านไม่อยู่ข้างเขา',then:()=>bondPass(x,false)}}]}}[kind];
 ask({title:`บททดสอบมิตรภาพ: ${x.n}`,rare:2,chain:'มิตรภาพ',who:x.id,sc:'tavern',text:T.text,opts:T.o})};
function bondPass(x,ok){if(ok){x.bond=1;x.aff=Math.min(100,x.aff+10);log(`${x.n}กลายเป็นสหายสนิทของท่าน`,'c-gold')}else{x.aff-=15;x.bondCd=P.m+36}}
// คนในใจ: ช่วงอายุ 16-35 พบคนใหม่ที่อาจเป็นคู่ครอง
const LOVE_MEET=[['งานเทศกาลโคมลอย','lake','ท่านกับคนแปลกหน้าคว้าโคมลอยดวงเดียวกันพร้อมกัน แล้วต่างคนต่างหัวเราะ'],['ร้านหนังสือเก่า','market','มือของท่านกับอีกคนแตะตำราเล่มเดียวกันบนชั้นบนสุด'],['ลานฝึกของกิลด์','guild','คู่ซ้อมคนใหม่ฟันดาบไม้ใส่ท่านแรงจนดาบหัก แล้วยื่นมือมาช่วยดึงท่านลุก'],['ท่าเรือข้ามฟาก','lake','ฝนตกหนัก ท่านกับอีกคนติดอยู่ใต้หลังคาท่าเรือเดียวกันทั้งคืน']];
QUESTS.loveMeet=()=>{if(ageY(P)>40||P.people.some(y=>y.rel==='spouse'))return;const [where,sc,txt]=pick(LOVE_MEET);const x=mkPerson('คนที่พบที่'+where,P.sex==='f'?'m':'f',{aff:ri(15,30),hunter:RNG()<.5,rank:ri(0,2)});x.age=ageY(P)+ri(-3,4);
 ask({title:`พบกันที่${where}`,rare:2,chain:'คนในใจ',who:x.id,sc,text:`${txt} เขาแนะนำตัวว่าชื่อ${x.n}`,opts:[
  {t:'ชวนคุยต่อ',chk:['cha','easy'],ok:{r:`${x.n}ยิ้ม ทั้งคู่คุยกันจนฟ้าสาง`,d:{aff:[[x.id,15]]},line:'พรุ่งนี้มาที่นี่อีกไหม',then:()=>{x.spark=1}},no:{r:'บทสนทนาจบลงอย่างเก้อเขิน',d:{aff:[[x.id,3]]}}},
  {t:'ขอตัวไปก่อน',ok:{r:'แต่ใบหน้านั้นยังติดอยู่ในหัวทั้งคืน',d:{aff:[[x.id,5]]}}}]})};
const _tick11=tick;tick=function(){const was=P&&P.m;_tick11();if(!P||!P.alive||P.m===was)return;
 if(!P.skills){P.skills=[];P.equip={}}
 if(P.guild){P.contrib=(P.contrib||0)+(P.path==='guild'?4:1);const r=(P.gRank||0)+1;if(r<G_RANKS.length&&P.contrib>=G_NEED[r]&&P.rank>=G_RANKREQ[r]&&!(P.flags.gpcd>P.m)&&!P.q.some(q=>q.k==='guildPromo')){P.flags.gpcd=P.m+6;schedule('guildPromo',ri(1,3))}
  if(mon(P)===3&&P.gRank>=5)schedule('guildCouncil',0);if(mon(P)===0)P.gold+=40*((P.gRank||0)+1)}
 if(mon(P)===6){const a=ageY(P);if(a>=16&&a<=35&&RNG()<.35&&!P.q.some(q=>q.k==='loveMeet'))schedule('loveMeet',ri(0,6));
  const sp=P.people.find(y=>y.rel==='spouse'&&y.alive);if(sp){P.gold+=60;const kids=P.people.filter(y=>/^ลูก(ชาย|สาว)/.test(y.role)).length;if(kids<4&&a<50&&RNG()<.15){const c=mkPerson(RNG()<.5?'ลูกชาย':'ลูกสาว',RNG()<.5?'m':'f',{aff:80});c.sex=c.role==='ลูกชาย'?'m':'f';c.look=randomLook(c.sex);c.age=0;P.homeMark={k:'baby',until:P.m+3};log(`${sp.n}ให้กำเนิด${c.role} ชื่อ${c.n}`,'c-gold')}}}
 if(mon(P)===0&&P.skills.includes('c_abyss')&&P.equip&&Object.values(P.equip).includes('c_abyss'))P.karma-=2;
 if(mon(P)===0&&P.equip&&Object.values(P.equip).includes('c_star'))P.mana+=1};
// วิชาแรกเมื่อตื่นพลัง ธาตุมานา
const CLS_EL={sword:'wind',bow:'wind',mage:'fire',assassin:'dark',healer:'light',tank:'earth'};
const _aw11=awaken;awaken=function(id,r){_aw11(id,r);P.elem=RNG()<.6?CLS_EL[id]:pick(Object.keys(ELEM));log(`ลูกแก้วเผยธาตุมานาของท่าน: ธาตุ${ELEM[P.elem][0]}`,'c-star');learnSkill({sword:'a_slash',bow:'a_slash',mage:'a_fireball',assassin:'a_slash',healer:'s_herb',tank:'d_skin'}[id]);learnSkill('c_breath')};
const _cj11=typeof changeJob==='function'?changeJob:null;if(_cj11)changeJob=function(id){_cj11(id);const j=JOBS[id];const pool=SKILLS.filter(s=>s.t===Math.min(4,j.t+1)&&!(P.skills||[]).includes(s.id));if(pool.length)learnSkill(pick(pool).id,'การเลื่อนขั้นอาชีพ')};
