// =============== v11 UI: หน้าผู้คนแบบจัดกลุ่ม + การ์ดตัวละครละเอียดแบบ WoX ===============
const PGROUPS=[['ครอบครัว',x=>isFamily(x)],['คนรัก',x=>['spouse','fiance','lover'].includes(x.rel)],['สหายและคู่หู',x=>x.bond||P.party.includes(x.id)],['ศัตรูและคู่อริ',x=>x.aff<-10],['เพื่อน',x=>x.aff>=25],['คนรู้จัก',()=>true]];
const groupOf=x=>PGROUPS.find(([,f])=>f(x))[0];
function meter(label,v,hint){const w=Math.min(50,Math.abs(v)/2);return `<div class="pc-meter"><span>${label}</span><div class="cl"><i class="${v>=0?'warm':'cold'}" style="left:${v<0?50-w:50}%;width:${w}%"></i></div><b class="${v>=0?'c-good':'c-bad'}">${v>0?'+':''}${Math.round(v)}</b></div>${hint?`<small class="mut">${hint}</small>`:''}`}
views.people=()=>{P.people.forEach(x=>{if(x.alive)ensureNpc(x)});const alive=P.people.filter(x=>x.alive),dead=P.people.filter(x=>!x.alive);
 const row=x=>{const st=x.alive?stageOf(x):'none';return `<button class="prow" data-pcard="${x.id}"><canvas class="px" width="48" height="48" data-face="${x.id}"></canvas><span class="pinfo"><b>${esc(x.n)}</b> <small class="mut">${esc(x.job||x.role)}${x.age!=null?` · ${x.age} ปี`:''}${x.hunter?` · แรงก์ ${RANKS[Math.max(0,x.rank)]}`:''}</small>
  <small><span class="${x.rel?'c-star':x.aff<0?'c-bad':'c-good'}">${relLabel(x)}</span> · ${TEMPERS[x.tr]?.n||''}${st!=='none'&&st!=='spouse'?` · <span style="color:#ff7aa8">${STAGE_N[st]} ♥${(x.ro||0).toFixed(1)}</span>`:''}${x.interest?' · <span style="color:#ff7aa8">หมายตาไว้</span>':''}${P.acted&&P.acted[x.id]===P.m?' · <span class="mut">พบแล้วเดือนนี้</span>':''}</small></span>
  <span class="paff"><span class="${x.aff>=0?'c-good':'c-bad'}">${x.aff}</span>${bar(x.aff+100,200,x.aff>=0?'#4fd18b':'#ff5d6c')}</span></button>`};
 const groups=PGROUPS.map(([n])=>[n,alive.filter(x=>groupOf(x)===n)]).filter(([,l])=>l.length);
 return `<p class="mut" style="margin-top:0">รู้จัก ${alive.length} คน · กดที่ชื่อเพื่อดูรายละเอียด คุย ให้ของ ประลอง หรือจีบ · พบคนใหม่ได้ตามที่ที่ท่านไปอยู่ (ตลาด โรงเตี๊ยม วิหาร ทุ่งนา ฯลฯ)</p>
 ${groups.map(([n,l])=>`<h4 class="pg">${n} <small class="mut">(${l.length})</small></h4>${l.map(row).join('')}`).join('')}
 ${dead.length?`<h4 class="pg mut">ผู้ที่จากไปแล้ว (${dead.length})</h4>${dead.map(row).join('')}`:''}`};
let PCARD=null,PPAGE='act';
function openCard(id){PCARD=id;renderCard()}
function closeCard(){PCARD=null;const m=document.getElementById('pcard');if(m)m.remove()}
function renderCard(){let m=document.getElementById('pcard');const x=PCARD&&person(PCARD);if(!x){closeCard();return}ensureNpc(x);
 if(!m){m=document.createElement('div');m.id='pcard';m.className='pc-ov';document.body.appendChild(m);m.onclick=e=>{if(e.target===m)closeCard()}}
 const T=TEMPERS[x.tr],st=stageOf(x),chem=chemistry(x),alive=x.alive;
 const info=`<dl class="pc-dl">
  <dt>สถานะ</dt><dd>${alive?'มีชีวิตอยู่':'เสียชีวิตแล้ว'}</dd>${x.age!=null?`<dt>อายุ</dt><dd>${x.age} ปี</dd>`:''}<dt>เพศ</dt><dd>${x.sex==='f'?'หญิง':'ชาย'}</dd>
  <dt>อาชีพ</dt><dd>${esc(x.job||x.role)}</dd>${x.hunter?`<dt>ระดับ</dt><dd>นักผจญภัยแรงก์ ${lvlOf(x)>lvlOf(P)+1?'???':RANKS[Math.max(0,x.rank)]}</dd>`:''}
  <dt>หน้าตา</dt><dd>${charmLabel(x.ch)}</dd><dt>นิสัย</dt><dd><b>${T.n}</b> <small class="mut">${T.d}</small></dd>
  <dt>พรสวรรค์</dt><dd>${TALENT_N[x.tal]} · ${DILI_N[x.dili]}</dd>
  <dt>ของที่ชอบ</dt><dd>${x.knowLike?`${x.like} <small class="mut">(ให้ของขวัญจะได้ผลดีขึ้นมาก)</small>`:'<span class="mut">ยังไม่รู้ (คุยกันบ่อย ๆ จะรู้เอง)</span>'}</dd>
  ${x.knowLike?`<dt>ของที่ไม่ชอบ</dt><dd>${x.dis}</dd>`:''}<dt>ที่อยู่</dt><dd>${spotName(x.home||'city')} · ${typeof TOWN!=='undefined'?TOWN:''}</dd>
  ${bioOf(x)?`<dt>เรื่องของเขา</dt><dd>${bioOf(x)}</dd>`:''}<dt>รู้จักกันเมื่อ</dt><dd>อายุ ${x.met} · พบกัน ${x.nmet} ครั้ง</dd></dl>`;
 const steps=LOVE_STEPS.map((s,i)=>{const order=['none','crush','lover','fiance','spouse'],at=order.indexOf(st),done=at>i,next=at===i;const need=[];if(next){if(s.need.ro)need.push(`ประกายรัก ${(x.ro||0).toFixed(1)}/${s.need.ro}`);if(s.need.aff)need.push(`ความชอบพอ ${x.aff}/${s.need.aff}`);if(s.need.gold)need.push(`เงิน ${P.gold}/${s.need.gold}`)}
  return `<li class="${done?'done':next?'next':''}">${done?'✔ ':next?'▶ ':''}${STAGE_N[s.id]} · ${s.t}${need.length?` <small>— ${need.join(' · ')}</small>`:''}</li>`}).join('');
 const rw=romanceWhy(x);
 const rel=`<p class="pc-stand">${standingWords(x)}</p>
  ${meter('ชอบพอ',x.aff,x.aff>=59&&!x.bond&&!x.rel&&!isFamily(x)?'ติดเพดาน 59: ต้องผ่านบททดสอบมิตรภาพก่อน (เขาจะมาหาท่านเอง)':'')}
  ${meter('ไว้ใจ',trustOf(x),'ไว้ใจ: ช่วยกันยามลำบาก รักษาคำพูด คืนบุญคุณ')}${meter('นับถือ',respOf(x),'นับถือ: ระดับของท่านเทียบกับเขา ชื่อเสียง และสิ่งที่เขาเห็นท่านทำ')}
  ${meter('บุญคุณ',x.fv||0,(x.fv||0)<0?`ท่านติดค้างเขาอยู่ ${-x.fv} แต้ม ค้างนานจะผูกใจเจ็บ (คืนได้ด้วยปุ่มตอบแทนบุญคุณ)`:'แต้มจากการช่วยเขา ให้ของขวัญ หรือช่วยเรื่องเดือดร้อน')}
  ${x.gr?`<p class="c-bad">${x.gr>=2?'แค้นท่านฝังใจ อาจตามมาทวงแค้นสักวัน':'ยังขุ่นเคืองท่านอยู่'}</p>`:''}
  ${!isFamily(x)&&ageY(P)>=14?`<div class="love-road"><h4>เส้นทางรัก${st!=='none'?` · <span style="color:#ff7aa8">${STAGE_N[st]}</span>`:''} · เคมี: <b>${chemLabel(chem)}</b></h4>${rw&&st==='none'?`<p class="mut">${rw}</p>`:`<ol>${steps}</ol><p class="mut" style="font-size:12px">ประกายรักโตจากการชวนเดท คุย และดื่มด้วยกันหลังหมายตาไว้ · ยิ่งเคมีดีประกายรักยิ่งโตเร็ว · สเปกของท่านคือคนนิสัย<b>${TEMPERS[idealType()].n}</b></p>`}</div>`:''}
  ${x.hist.length?`<h4>เรื่องที่ผ่านมาด้วยกัน</h4><ul class="pc-hist">${x.hist.slice().reverse().map(h=>`<li><span class="mut">อายุ ${h.a}</span> ${esc(h.t)}</li>`).join('')}</ul>`:''}`;
 const acts=actOptions(x),why=[...new Set(acts.filter(a=>a.why).map(a=>a.why))];
 const btn=a=>`<button class="btn sm ${['breakup','attack'].includes(a.id)?'danger':['confess','propose','wed','court','interest'].includes(a.id)?'love':''}" data-act2="${a.id}" ${a.why?`disabled title="${esc(a.why)}"`:''}>${a.id==='party'&&P.party.includes(x.id)?'ออกจากทีม':ACT_N[a.id]}${{gift:' (~'+Math.min(80,Math.max(10,Math.round(P.gold*.03)))+')',drink:' (10)',court:' (20)',wed:' (500)',repay:` (${(-(x.fv||0))*5})`,makePeace:' (50)'}[a.id]||''}</button>`;
 const act=alive?`<div class="act-row">${acts.filter(a=>!['breakup','attack'].includes(a.id)).map(btn).join('')}</div>
  ${why.length?`<p class="act-why">${why.join(' · ')}</p>`:''}${x.rel==='spouse'?`<p class="mut">อยู่กินกันแล้ว: ทุกปีมีโอกาสมีลูก${x.wantChild>P.m?' (ปีนี้ตั้งใจมีลูก โอกาสสูง)':''}</p>`:''}
  ${P.talk&&P.talk.who===x.id&&P.talk.until>=P.m?`<p class="pc-say">${esc(x.n)}: "${esc(P.talk.line)}"</p>`:''}
  <small class="mut">ทำได้คนละครั้งต่อเดือน (หมายตาไม่นับ)</small>
  ${acts.some(a=>['breakup','attack'].includes(a.id))?`<h4 class="c-bad" style="margin-top:10px">การกระทำรุนแรง</h4><div class="act-row">${acts.filter(a=>['breakup','attack'].includes(a.id)).map(btn).join('')}</div>`:''}`:'<p class="mut">จากไปแล้ว</p>';
 const ties=(x.ties||[]).map(([id,k])=>{const y=person(id);return y?`<li><button class="linkb" data-pcard2="${y.id}">${esc(y.n)}</button> <span class="mut">${{friend:'สหาย',rival:'คู่อริ',lover:'คนรัก'}[k]}</span></li>`:''}).join('');
 const circ=ties?`<ul class="pc-hist">${ties}</ul>`:'<p class="mut">ยังไม่รู้ว่าเขาสนิทกับใครบ้าง</p>';
 const pages={act:['ติดต่อ',act],info:['ข้อมูล',info],rel:['ความสัมพันธ์',rel],circle:['คนรอบตัว',circ]};
 m.innerHTML=`<div class="pc-card"><div class="pc-top"><canvas class="px" width="96" height="96" data-face="${x.id}"></canvas><div><h2>${esc(x.n)} <small>${x.sex==='f'?'♀':'♂'}</small></h2><p class="mut">${esc(x.job||x.role)} · <span class="${x.rel?'c-star':x.aff<0?'c-bad':'c-good'}">${relLabel(x)}</span> (ชอบพอ ${x.aff>0?'+':''}${x.aff})</p></div><button class="btn sm pc-x">✕</button></div>
  <div class="pc-tabs">${Object.entries(pages).map(([k,[n]])=>`<button class="${PPAGE===k?'on':''}" data-pp="${k}">${n}</button>`).join('')}</div><div class="pc-body">${pages[PPAGE][1]}</div></div>`;
 drawFaces();m.querySelector('.pc-x').onclick=closeCard;m.querySelectorAll('[data-pp]').forEach(b=>b.onclick=()=>{PPAGE=b.dataset.pp;renderCard()});
 m.querySelectorAll('[data-pcard2]').forEach(b=>b.onclick=()=>openCard(b.dataset.pcard2));
 m.querySelectorAll('[data-act2]').forEach(b=>b.onclick=()=>{interact(x.id,b.dataset.act2);save();render();if(PENDING.length)closeCard();else renderCard()})}
const _render12=render;render=function(){_render12();document.querySelectorAll('[data-pcard]').forEach(b=>b.onclick=e=>{if(e.target.closest('[data-party]'))return;PPAGE='act';openCard(b.dataset.pcard)});if(PCARD)renderCard()};
// ---- บ้านของตัวเอง ----
const _map12=views.map;views.map=()=>`<div class="card"><b>บ้านของท่าน</b> <span class="mut">ตอนนี้: ${SCENE_CAP.home}</span><div class="row" style="gap:6px;flex-wrap:wrap;margin-top:6px">${HOUSES.map(([k,n,c,d])=>`<button class="btn sm ${P.homeOwn===k?'on':''}" data-house="${k}" ${P.homeOwn===k||P.gold<c?'disabled':''} title="${d}">${n}${c?` · ${c} ทอง`:''}</button>`).join('')}</div><small class="mut">${HOUSES.map(h=>h[1]+': '+h[3]).join(' · ')}</small></div>`+_map12();
const _render12b=render;render=function(){_render12b();document.querySelectorAll('[data-house]').forEach(b=>b.onclick=()=>{buyHouse(b.dataset.house);save();render()})};
