from theme7 import theme
R=lambda f:open(f).read()
t=R('template.html')
art=R('gchar.js')+'\n'+R('char13.js')+'\n'+theme(R('art4.js').replace('/*MANIFEST*/',R('manifest7.json')))+'\n'+R('art6.js')+'\n'+R('art12.js')
logic=theme('\n'.join(R(f) for f in ['logic4.js','life5.js','events2.js','prog6.js','talent6.js','drama6.js','isekai7.js','story8.js','life9.js','world10.js','sys11.js','events11.js','rel12.js','story13.js']))
ui=theme(R('ui5.js').replace('/*CREATE*/',R('create5.js')).replace('load();P=null;startScreen();',R('ui6.js')+'\n'+R('ui7.js')+'\n'+R('ui8.js')+'\n'+R('ui9.js')+'\n'+R('ui10.js')+'\n'+R('ui11.js')+'\n'+R('ui12.js')+'\n'+R('ui14.js')+'\nload();P=null;startScreen();'))
t=t.replace('/*LOGIC*/',logic).replace('/*ART*/',art).replace('/*UI*/',ui)
open('index.html','w').write(t)
