// =============== หน้าจอ ===============
const $=s=>document.querySelector(s);
const SAVE='hunter-path-v4';
const BASE=5000;let speed=0,timer=null,tab='log',frame=0,editing=null,night=false,minimized=false,openYears={};
let SET={fate:false,fateWait:5};
function save(){try{localStorage.setItem(SAVE,JSON.stringify({P,META,SET}))}catch(e){}}
function load(){try{const d=JSON.parse(localStorage.getItem(SAVE));if(d){P=d.P;META=d.META||META;SET=d.SET||SET}}catch(e){}}
function setSpeed(s){speed=s;clearInterval(timer);if(s)timer=setInterval(step,BASE/s);render()}
function step(){if(BATTLE)return;const before=PENDING.length;tick();save();if(PENDING.length!==before||P.lastFight||!P.alive)render();else soft()}
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const rk=r=>r>=0?`<span class="rank r${RANKS[r]}">${RANKS[r]}</span>`:'';
const bar=(v,max,col)=>`<div class="bar"><i style="width:${clamp(v/max*100,0,100)}%;background:${col}"></i></div>`;
const icon=k=>MF.icons[k]?`<img class="ic px" src="${MF.icons[k]}" alt="">`:'';
const curScene=()=>PENDING[0]?.sc||P.scene||P.place;
function startBattle(){if(!P.lastFight)return render();const L=P.lastFight;P.lastFight=null;
 const foe=L.foe?{rival:person(P.flags.rival),mentor:person(P.flags.mentor)}[L.foe]:null;
 BATTLE={...L,t:0,foeName:foe?foe.n:L.foe==='thug'?'ฮันเตอร์นอกกฎหมาย':'',foeLook:foe?.look||'m2',foeTint:foe?.tint??5};render()}
// ภาพเคลื่อนไหว 10 เฟรม/วินาที
setInterval(()=>{frame++;
 if(editing){const cv=$('#pv');if(cv){const g=cv.getContext('2d');g.imageSmoothingEnabled=false;g.clearRect(0,0,220,220);shadow(g,110,206,34);spr(g,MF.chars[editing.ch].an[frame%40<30?'Idle':'Attack'],frame,110,206,2.4,false,1,editing.tint)}return}
 if(!P){drawScene($('#title'),'gate',null,frame);return}
 if(BATTLE){drawBattle($('#scene'),P,BATTLE);if(++BATTLE.t>38){if(BATTLE.win)P.mon=null;BATTLE=null;save();render()}return}
 drawScene($('#scene'),curScene(),P,frame,night);
 if(PENDING.length&&SET.fate&&!minimized){const q=PENDING[0];q._w=(q._w||0)+1;const el=$('#fatebar');if(el)el.style.width=Math.min(100,q._w/(SET.fateWait*10)*100)+'%';if(q._w>=SET.fateWait*10){answer('fate');save();P.lastFight?startBattle():render()}}
},100);

// ---------- สร้างตัวละคร ----------
function creator(mode){
 if(!editing)editing={ch:'g1',tint:0,name:'',mode};
 const ids=Object.keys(MF.chars),c=MF.chars[editing.ch];
 $('#modal').innerHTML='';
 $('#app').innerHTML=`<div class="panel"><h2>${mode==='edit'?'เปลี่ยนลุค':'สร้างตัวละคร'}</h2>
  <div class="creator"><div style="text-align:center"><canvas id="pv" width="220" height="220" class="px" style="width:240px;height:240px;background:linear-gradient(#24305a,#141a30);border-radius:10px"></canvas></div>
  <div><div class="mut" style="font-size:13px">รูปร่าง</div><div class="row" style="gap:6px;margin:4px 0 10px">${ids.map(k=>`<button class="btn ${editing.ch===k?'on':''}" data-ch="${k}">${MF.chars[k].sex==='f'?'หญิง':'ชาย'} ${k.slice(1)}</button>`).join('')}</div>
   <div class="mut" style="font-size:13px">โทนสีเสื้อผ้าและผม</div><div class="row" style="gap:6px;margin:4px 0 10px">${TINTS.map((h,i)=>`<button class="sw ${editing.tint===i?'on':''}" data-tint="${i}" style="background:${i?`hsl(${(h+220)%360} 55% 45%)`:'linear-gradient(135deg,#888,#444)'}" aria-label="สีแบบที่ ${i+1}"></button>`).join('')}</div>
   ${mode==='edit'?'':`<input id="nm" maxlength="16" placeholder="ชื่อ (เว้นว่าง = สุ่ม)" value="${esc(editing.name)}">`}
   <p class="mut" style="font-size:13px">เริ่มชีวิตตอนอายุ 15 ปี เป็นนักเรียน ม.4 อาชีพและแรงก์จะรู้ในวันตื่นพลังตอนอายุ 18</p></div></div>
  <div class="row" style="justify-content:flex-end"><button class="btn" id="back">ย้อนกลับ</button><button class="btn pri" id="ok">${mode==='edit'?'บันทึก':'เริ่มชีวิต'}</button></div></div>`;
 const nm=$('#nm');if(nm)nm.oninput=()=>editing.name=nm.value;
 document.querySelectorAll('[data-ch]').forEach(b=>b.onclick=()=>{editing.ch=b.dataset.ch;creator(mode)});
 document.querySelectorAll('[data-tint]').forEach(b=>b.onclick=()=>{editing.tint=+b.dataset.tint;creator(mode)});
 $('#back').onclick=()=>{editing=null;mode==='edit'?render():startScreen()};
 $('#ok').onclick=()=>{const e=editing;editing=null;const c=MF.chars[e.ch];
  if(mode==='edit'){P.look=e.ch;P.tint=e.tint;save();render()}
  else{newLife(e.name.trim()||pick(c.sex==='f'?NAMES_F:NAMES_M),c.sex,e.ch,e.tint);save();tab='log';setSpeed(1)}};
}
function startScreen(){
 const has=P&&P.alive;$('#modal').innerHTML='';
 $('#app').innerHTML=`<div class="panel" style="text-align:center;margin-top:3vh"><canvas id="title" width="576" height="324" class="scene"></canvas>
  <h1 style="font-size:34px;background:linear-gradient(90deg,#6fd3ff,#b48cff);-webkit-background-clip:text;color:transparent;margin-top:8px">เส้นทางฮันเตอร์</h1>
  <p class="mut">เกมจำลองชีวิตในโลกที่มีเกต ตั้งแต่นักเรียน ม.ปลาย จนถึงวันสุดท้ายของฮันเตอร์คนหนึ่ง</p>
  <div class="row" style="justify-content:center"><button class="btn pri" id="go">ชีวิตใหม่</button>${has?'<button class="btn" id="cont">เล่นต่อ</button>':''}</div>
  ${META.lives?`<p class="mut" style="font-size:13px;margin-top:12px">ใช้ชีวิตมาแล้ว ${META.lives} ชีวิต · ความทรงจำที่สืบทอด +${Math.min(META.legacy,30)}${META.best?` · ดีที่สุด: ${esc(META.best.name)} เลเวล ${META.best.lvl}`:''}</p>`:''}
  <p class="credit">ภาพตัวละคร มอนสเตอร์ ฉากกลางแจ้ง และไอคอน: CraftPix.net</p></div>`;
 $('#go').onclick=()=>{editing=null;creator('new')};if(has)$('#cont').onclick=()=>setSpeed(0);
}
// ---------- หน้าเกม ----------
function header(){
 const c=P.cls?CLASSES.find(x=>x.id===P.cls):null,mh=maxHp(P),pa=curPath(),sp=P.sponsor&&star(P.sponsor);
 const tt=P.titles.length?TITLES.find(t=>t.id===P.titles[P.titles.length-1]).n:'';
 return `<div class="panel hd">
  <div class="row"><h2>${esc(P.name)}</h2>${rk(P.rank)}${tt?`<span class="chip">«${tt}»</span>`:''}<span class="sp"></span>
   <button class="btn sm" id="night" title="กลางวัน/กลางคืน">${night?'☾':'☀'}</button>
   <div class="row speed">${[0,1,2,3,5,10].map(s=>`<button class="btn sm ${speed===s?'on':''}" data-s="${s}">${s?s+'×':'❚❚'}</button>`).join('')}</div></div>
  <div class="row mut" style="font-size:13px">อายุ ${ageY(P)} ปี ${mon(P)} เดือน · ${SEASON_N[SEASON(P.m)]} · <span class="c-gold">${P.stage==='school'?'นักเรียน ม.ปลาย':`${c.n} เลเวล ${P.lvl}`}</span>${P.guild?` · กิลด์${P.guild}`:''}${sp?` · ผู้สนับสนุน: ${sp.n}`:''}${P.sys?' · <span class="c-sys">[ระบบ]</span>':''}</div>
  <div class="grid2"><div><div class="lbl">พลังชีวิต ${P.hp}/${mh}</div>${bar(P.hp,mh,'linear-gradient(90deg,#ff5d6c,#ff9a76)')}</div>
   ${P.rank>=0?`<div><div class="lbl">EXP ${P.exp}/${expNeed(P)}</div>${bar(P.exp,expNeed(P),'linear-gradient(90deg,#4da3ff,#b48cff)')}</div>`:`<div><div class="lbl">อีก ${Math.max(0,18*12-P.m)} เดือนถึงวันตื่นพลัง</div>${bar(P.m-180,36,'#6fd3ff')}</div>`}</div>
  <div class="stats">${STATS.map(k=>`<div>${SN[k]}<b>${P[k]}</b></div>`).join('')}</div>
  <div class="row" style="font-size:13px;margin-top:6px;gap:12px"><span>เงิน <b class="c-gold">${P.gold}</b></span><span>กรรม <b class="${P.karma<0?'c-bad':'c-good'}">${P.karma}</b></span><span>ชื่อเสียง <b>${P.fame}</b></span>${P.rank>=0?`<span>ดาวเหรียญ <b class="c-star">${P.coin}</b></span><span>พลังรวม <b>${power(P)}</b></span>`:''}
   <span class="sp"></span><span class="mut">วิถี</span><button class="btn sm on" id="path">${pa?pa.n:'ยังไม่ได้เลือก'}</button></div>
 </div>`;
}
function sceneBox(){
 const sc=curScene(),pl=PLACES.find(x=>x.id===P.place);
 const cap=BATTLE?`กำลังต่อสู้ · ${BATTLE.foe?BATTLE.foeName:MON_N[BATTLE.mon]||''}${BATTLE.boss?' (บอส)':''}`:sc==='dungeon'?`ภายในเกต · ${WORLD_N[P.world]||''}`:SCENE_CAP[sceneKey(sc)]||pl?.n||'';
 const last=P.log.find(l=>l.c!=='sum');
 return `<div class="scenewrap"><canvas id="scene" width="576" height="324" class="scene"></canvas>
  <div class="loc"><b>${esc(cap)}</b>${P.act?`<span>กำลัง: ${esc(P.act)}</span>`:''}</div></div>
  <div class="caption">${esc(last?last.t:'')}</div>`;
}
function render(){
 if(!P)return startScreen();if(editing)return;
 const logTop=$('.log')?.scrollTop||0;
 $('#app').innerHTML=header()+sceneBox()+`
 <div class="tabs">${[['log','บันทึก'],['life','ชีวิต'],['people','ผู้คน'],['map','แผนที่'],...(P.rank>=0?[['gate','เกต'],['tower','หอคอย'],['shop','ร้านค้า'],['star','ดวงดาว']]:[])].map(([k,n])=>`<button data-t="${k}" class="${tab===k?'on':''}">${n}</button>`).join('')}</div>
 <div class="panel">${(views[tab]||views.log)()}</div><p class="credit">ภาพ: CraftPix.net และวาดเพิ่มในเกม</p>`;
 if(BATTLE)drawBattle($('#scene'),P,BATTLE);else drawScene($('#scene'),curScene(),P,frame,night);
 const lg=$('.log');if(lg)lg.scrollTop=logTop;bind();showModal();
}
function soft(){ // อัปเดตเฉพาะหัวและคำบรรยาย ไม่สร้างแท็บใหม่
 const h=$('.hd');if(h){const n=document.createElement('div');n.innerHTML=header();h.replaceWith(n.firstElementChild)}
 const w=$('.scenewrap');if(w){const sc=curScene();const cap=sc==='dungeon'?`ภายในเกต · ${WORLD_N[P.world]||''}`:SCENE_CAP[sceneKey(sc)]||'';w.querySelector('.loc').innerHTML=`<b>${esc(cap)}</b>${P.act?`<span>กำลัง: ${esc(P.act)}</span>`:''}`}
 const last=P.log.find(l=>l.c!=='sum');const c=$('.caption');if(c)c.textContent=last?last.t:'';
 if(tab==='log'){const lg=$('.log');const top=lg?.scrollTop||0;const box=$('#tabbox');if(box){box.outerHTML=views.log();const l2=$('.log');if(l2)l2.scrollTop=top;bindLog()}}
 bindHead();
}
function bindHead(){
 document.querySelectorAll('[data-s]').forEach(b=>b.onclick=()=>setSpeed(+b.dataset.s));
 const n=$('#night');if(n)n.onclick=()=>{night=!night;render()};
 const pa=$('#path');if(pa)pa.onclick=()=>{if(P.stage==='school'&&ageY(P)<18||P.stage==='hunter'){QUESTS[P.stage==='school'?'pathSchool':'pathHunter']();render()}};
}
function bindLog(){document.querySelectorAll('[data-y]').forEach(b=>b.onclick=()=>{const y=+b.dataset.y;openYears[y]=!(openYears[y]??(y>=ageY(P)-1));render()})}
function bind(){
 bindHead();bindLog();
 document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{tab=b.dataset.t;render()});
 document.querySelectorAll('[data-gate]').forEach(b=>b.onclick=()=>{if(BATTLE)return;enterGate(+b.dataset.gate);save();startBattle()});
 document.querySelectorAll('[data-buy]').forEach(b=>b.onclick=()=>{buy(b.dataset.buy);save();render()});
 document.querySelectorAll('[data-gear]').forEach(b=>b.onclick=()=>{const [k,i]=b.dataset.gear.split(':');buyGear(k,+i);save();render()});
 document.querySelectorAll('[data-go]').forEach(b=>b.onclick=()=>{goPlace(b.dataset.go);save();render()});
 document.querySelectorAll('[data-party]').forEach(b=>b.onclick=()=>{toggleParty(b.dataset.party);save();render()});
 const cl=$('#climb');if(cl)cl.onclick=()=>{if(BATTLE)return;climb();save();startBattle()};
 const ed=$('#edit');if(ed)ed.onclick=()=>{setSpeed(0);editing={ch:P.look,tint:P.tint,mode:'edit'};creator('edit')};
 const q=$('#quit');if(q)q.onclick=()=>{setSpeed(0);if(!P.alive)P=null;startScreen()};
 const fa=$('#setfate');if(fa)fa.onchange=()=>{SET.fate=fa.checked;save()};
}
const views={
 log:()=>{const ys={};P.log.forEach(l=>{(ys[l.y]=ys[l.y]||[]).push(l)});
  return `<div id="tabbox"><div class="log">${Object.keys(ys).sort((a,b)=>b-a).map(y=>{const open=openYears[y]??(+y>=ageY(P)-1);
   return `<div class="yr"><button class="yh" data-y="${y}">${open?'▾':'▸'} อายุ ${y}</button>${open?ys[y].map(l=>l.c==='sum'?`<p class="sum">${esc(l.t)}</p>`:`<p class="${l.c}"><span class="t">${l.mo} ด.</span>${esc(l.t)}</p>`).join(''):''}</div>`}).join('')}</div></div>`},
 life:()=>{const c=P.cls?CLASSES.find(x=>x.id===P.cls):null;
  return `<div class="kv">
   <div>ชื่อ</div><div>${esc(P.name)}</div><div>ครอบครัว</div><div>${P.family}</div><div>ช่วงชีวิต</div><div>${P.stage==='school'?'นักเรียน ม.ปลาย':'ฮันเตอร์'}</div>
   <div>อาชีพ</div><div>${c?`${c.n} แรงก์ ${RANKS[P.rank]} · ${c.d}`:'ยังไม่ตื่นพลัง'}</div><div>อายุขัย</div><div>${P.rank>=0?`ราว ${P.life} ปี`:'ไม่มีใครรู้'}</div>
   <div>อาวุธ / เกราะ</div><div>${P.wep>=0?WEAPONS[P.wep].n:'มือเปล่า'} / ${P.arm>=0?ARMORS[P.arm].n:'เสื้อธรรมดา'}</div>
   <div>สัตว์คู่ใจ</div><div>${P.flags.pet||'ไม่มี'}</div><div>ฉายา</div><div>${P.titles.map(id=>TITLES.find(t=>t.id===id).n).join(', ')||'ยังไม่มี'}</div>
   <div>เรื่องที่ค้างอยู่</div><div>${P.q.length?P.q.length+' เรื่องกำลังรออยู่ในอนาคต':'ไม่มี'}</div></div>
   <h3>นิสัย</h3><p class="mut" style="font-size:13px;margin-top:0">นิสัยเปลี่ยนไปตามทางเลือกของท่าน และมีผลกับบางเหตุการณ์</p>
   ${TRAITS.map(([k,a,b])=>`<div class="trait"><span>${a}</span><div class="tbar"><i style="left:${50+P.tr[k]/2}%"></i></div><span>${b}</span></div>`).join('')}
   <h3>ตั้งค่า</h3><label class="row" style="font-size:14px"><input type="checkbox" id="setfate" ${SET.fate?'checked':''} style="width:auto"> ให้ชะตาเลือกแทนเมื่อไม่ได้กดภายใน ${SET.fateWait} วินาที</label>
   <div class="row" style="margin-top:10px"><button class="btn" id="edit">เปลี่ยนลุค</button><button class="btn" id="quit">กลับหน้าแรก</button></div>`},
 people:()=>`<p class="mut" style="margin-top:0">ท่านรู้จัก ${P.people.length} คน · คู่หู ${P.party.length}/2 (ต้องเป็นฮันเตอร์และสนิท 40 ขึ้นไป คู่หูจะลงเกตด้วยและเพิ่มพลังรวม)</p>
   ${P.people.map(x=>`<div class="card row"><canvas class="mini px" width="64" height="64" data-face="${x.id}"></canvas><div class="sp"><b>${esc(x.n)}</b> <span class="mut">${x.role}${x.hunter?` · ฮันเตอร์แรงก์ ${RANKS[Math.max(0,x.rank)]}`:''}${x.alive?'':' · เสียชีวิตแล้ว'}</span>
    ${bar(x.aff+100,200,x.aff>=0?'#4fd18b':'#ff5d6c')}<span class="mut" style="font-size:12px">ความสนิท ${x.aff}</span></div>
    ${P.rank>=0&&x.hunter&&x.alive?`<button class="btn sm ${P.party.includes(x.id)?'on':''}" data-party="${x.id}" ${!P.party.includes(x.id)&&(x.aff<40||P.party.length>=2)?'disabled':''}>${P.party.includes(x.id)?'อยู่ในทีม':'ชวนเข้าทีม'}</button>`:''}</div>`).join('')}`,
 map:()=>`<p class="mut" style="margin-top:0">ท่านอยู่ที่ ${PLACES.find(x=>x.id===P.place)?.n||'—'} · ไปอยู่ที่ไหน เหตุการณ์ของที่นั่นจะเกิดบ่อยขึ้น</p>
   ${PLACES.map(pl=>{const ok=!pl.c||pl.c(P);return `<div class="card row"><div class="sp"><b>${pl.n}</b>${P.place===pl.id?' <span class="c-good">· ท่านอยู่ที่นี่</span>':''}<div class="mut" style="font-size:13px">${pl.d}${ok?'':` · ${pl.why}`}</div></div>
    <button class="btn sm" data-go="${pl.id}" ${!ok||P.place===pl.id?'disabled':''}>ไปที่นี่</button></div>`}).join('')}`,
 gate:()=>`<p class="mut" style="margin-top:0">กระดานเกตของสมาคม เปลี่ยนทุก 2 เดือน เข้าได้เดือนละ 1 เกต · พลังรวม ${power(P)}${P.party.length?` (รวมคู่หู ${P.party.length} คน)`:''}</p>
   ${P.gates.map((g,i)=>{const w=winChance(g.diff),risk=deathRisk(g.diff);return `<div class="card row"><canvas class="mini px" width="44" height="84" data-portal="${g.pc}" style="width:28px;height:54px"></canvas>${icon('mon'+g.r)}${rk(g.r)}
    <div class="sp"><b>${g.mod}</b> <span class="mut" style="font-size:13px">${WORLD_N[g.world]} · ${MON_N[g.mon]}</span><div style="font-size:13px" class="${w>.75?'c-good':w>.45?'':'c-bad'}">โอกาสชนะ ${Math.round(w*100)}%${risk?' · ☠ อาจตาย':''}${g.red?' · ออกไม่ได้จนกว่าจะชนะ':''}</div></div>
    <button class="btn pri" data-gate="${i}" ${P.gateDone||!P.alive?'disabled':''}>เข้าเกต</button></div>`}).join('')||'<p class="mut">ไม่มีเกตเหลือบนกระดาน</p>'}
   ${P.gateDone?'<p class="mut">เดือนนี้ท่านลงเกตไปแล้ว</p>':''}`,
 tower:()=>`<h3>หอคอยแห่งการทดสอบ</h3><p class="mut" style="margin-top:0">ไต่ได้เดือนละครั้ง สูงสุด 5 ชั้น ทุก 10 ชั้นมีผู้พิทักษ์ แพ้แล้วหอคอยส่งกลับลงมาโดยไม่ตาย</p>
   <div class="stats" style="grid-template-columns:repeat(3,1fr);margin-bottom:10px"><div>ชั้นปัจจุบัน<b>${P.floor}</b></div><div>โอกาสผ่านชั้นถัดไป<b>${Math.round(winChance(floorDiff(P.floor+1))*100)}%</b></div><div>สูงสุด<b>${P.best}</b></div></div>
   <button class="btn pri" id="climb" ${P.towerDone||!P.alive?'disabled':''}>${P.towerDone?'เดือนนี้ไต่แล้ว':'ไต่หอคอย'}</button>`,
 shop:()=>{const gear=(k,list,unit)=>list.map((it,i)=>`<div class="card row">${icon(k+i)}<div class="sp"><b>${it.n}</b>${P[k]===i?' <span class="c-good">· ใช้อยู่</span>':''}<div class="mut" style="font-size:13px">${unit(it)}</div></div>
    <button class="btn sm" data-gear="${k}:${i}" ${P[k]>=i||P.gold<it.c?'disabled':''}>${it.c} ทอง</button></div>`).join('');
   return `<h3>อาวุธ</h3>${gear('wep',WEAPONS,it=>'พลังต่อสู้ +'+it.p)}<h3>ชุดเกราะ</h3>${gear('arm',ARMORS,it=>'พลังชีวิตสูงสุด +'+it.h)}`},
 star:()=>`<p class="mut" style="margin-top:0">กลุ่มดาวเฝ้ามองฮันเตอร์ทุกคน ดวงไหนชอบท่านถึง 50 จะเสนอเป็นผู้สนับสนุน</p>
   ${P.scen?`<div class="card sysbox">[ฉากทดสอบ] ${scenText(P.scen)} · เหลือ ${P.scen.until-P.m} เดือน · รางวัล ${P.scen.rew} ดาวเหรียญ</div>`:''}
   ${STARS.map(s=>`<div class="card"><div class="row"><b class="c-star">${s.n}</b>${P.sponsor===s.id?'<span class="c-gold">· ผู้สนับสนุน</span>':''}<span class="sp"></span><span>${P.favor[s.id]}</span></div>
    ${bar(Math.max(0,P.favor[s.id]),100,'#b48cff')}<div class="mut" style="font-size:13px">พร: ${s.gift}</div></div>`).join('')}
   <h3>ร้านดวงดาว</h3>${SHOP.map(it=>`<div class="card row">${icon(it.id)}<div class="sp"><b>${it.n}</b><div class="mut" style="font-size:13px">${it.d}</div></div><button class="btn sm" data-buy="${it.id}" ${P.coin<it.c?'disabled':''}>${it.c} ดาวเหรียญ</button></div>`).join('')}`,
};
// วาดรูปเล็ก (หน้าผู้คน ประตูเกต) หลัง render
const _r=render;render=function(){_r();
 document.querySelectorAll('[data-face]').forEach(cv=>{const x=person(cv.dataset.face);if(!x)return;const g=cv.getContext('2d');g.imageSmoothingEnabled=false;g.clearRect(0,0,64,64);const s=anim(x.look,'Idle'),im=x.tint?tinted(s,x.tint):IMG[s.src];if(im&&im.complete!==false)g.drawImage(im,0,0,128,128,-32,8,128,128)});
 document.querySelectorAll('[data-portal]').forEach(cv=>{const g=cv.getContext('2d');g.drawImage(portalCanvas(cv.dataset.portal,frame%12),0,0)});
};

function showModal(){
 const m=$('#modal');if(BATTLE){m.innerHTML='';return}
 if(!P.alive){m.innerHTML=`<div class="modal"><div class="panel"><canvas id="mscene" width="576" height="324" class="scene"></canvas><h2 class="c-bad">ชีวิตจบลง</h2>
  <p>${esc(P.name)} ${P.rank>=0?`แรงก์ ${RANKS[P.rank]} เลเวล ${P.lvl}`:'คนธรรมดา'} อายุ ${ageY(P)} ปี<br>สาเหตุ: ${esc(P.cause)}</p>
  ${P.titles.length?`<p class="c-gold">ฉายา: ${P.titles.map(id=>TITLES.find(t=>t.id===id).n).join(', ')}</p>`:''}<p class="c-star">ความทรงจำที่ส่งต่อให้ชีวิตหน้า: +${Math.min(P.pts,30)} ค่าพลัง</p>
  <button class="btn pri" id="again">เกิดใหม่</button></div></div>`;clearInterval(timer);speed=0;drawScene($('#mscene'),'death',P,frame);
  $('#again').onclick=()=>{m.innerHTML='';P=null;save();startScreen()};return}
 if(!PENDING.length){m.innerHTML='';return}
 const q=PENDING[0];
 if(minimized){m.innerHTML=`<button class="minibar" id="unmin">▴ ${esc(q.title)} · รอการตัดสินใจ</button>`;$('#unmin').onclick=()=>{minimized=false;showModal()};return}
 m.innerHTML=`<div class="modal"><div class="panel ev"><div class="row"><span class="chip r${q.rare||0}">${RARE[q.rare||0]}</span>${q.chain?`<span class="mut" style="font-size:13px">📜 เรื่อง: ${esc(q.chain)}</span>`:''}<span class="sp"></span><button class="link" id="min">▾ ย่อไว้ก่อน</button></div>
  <h2>${esc(q.title)}</h2><div class="mut" style="font-size:13px">${STATS.map(k=>`${SN[k]} <b>${P[k]}</b>`).join(' · ')} · เงิน <b>${P.gold}</b> · พลังชีวิต <b>${P.hp}</b></div>
  <p>${esc(q.text)}</p>
  ${q.opts.map((o,i)=>{const ok=canPick(o),inf=optInfo(o);return `<button class="opt" data-a="${i}" ${ok?'':'disabled'}><b>${esc(o.t)}</b>${o.sub?`<span class="mut">${esc(o.sub)}</span>`:''}${inf.length?`<span class="inf">${inf.map(esc).join(' · ')}</span>`:''}</button>`}).join('')}
  <button class="opt" data-a="fate"><b>🎲 ให้ชะตาเลือก</b></button>${SET.fate?'<div class="bar"><i id="fatebar" style="width:0;background:#b48cff"></i></div>':''}</div></div>`;
 $('#min').onclick=()=>{minimized=true;showModal()};
 m.querySelectorAll('[data-a]').forEach(b=>b.onclick=()=>{answer(b.dataset.a==='fate'?'fate':+b.dataset.a);save();P.lastFight?startBattle():render()});
}
load();P&&P.alive?render():(P=null,startScreen());
