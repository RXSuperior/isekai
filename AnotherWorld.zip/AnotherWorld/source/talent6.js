// =============== v6: ระดับพรสวรรค์ ===============
TALENTS.push(
 {id:'shadowstep',n:'ก้าวเงา',ic:'🌘',c:5,d:'ความเร็ว +15 และโอกาสสำเร็จเมื่อใช้ความเร็ว +10%',st:{agi:15},chk:{agi:.1}},
 {id:'genius',n:'อัจฉริยะ',ic:'💡',c:6,d:'ปัญญา +15 และ EXP ที่ได้ +20%',st:{int:15},m:{exp:.2}},
 {id:'monster',n:'ร่างสัตว์ประหลาด',ic:'🐉',c:6,d:'กาย +12 ความอึด +12 พลังชีวิตสูงสุด +20%',st:{str:12,vit:12},m:{hp:.2}},
 {id:'heavenluck',n:'โชคฟ้าประทาน',ic:'🎐',c:7,d:'โชค +30',st:{luk:30}},
 {id:'manaheart',n:'หัวใจมานา',ic:'💠',c:8,d:'มานาแฝง +30 (ดันเพดานแรงก์ได้สองขั้น)',mana:30},
 {id:'reborn',n:'ผู้กลับชาติมาเกิด',ic:'♾️',c:9,d:'ค่าพลังทุกอย่าง +8 และมีตราสัญญาชีวิต 1 อัน',st:{str:8,agi:8,int:8,vit:8,cha:8,luk:8},mark:1},
 {id:'chosen',n:'ผู้ถูกเลือกของดวงดาว',ic:'🌠',c:9,d:'กลุ่มดาวทุกดวงชอบท่าน +30 ตั้งแต่เกิด',fav:30},
 {id:'frail',n:'ป่วยเรื้อรัง',ic:'🩹',c:-4,bad:1,d:'ความอึด -10 พลังชีวิตสูงสุด -20%',st:{vit:-10},m:{hp:-.2}},
 {id:'cursed',n:'คำสาปดวงดาว',ic:'🕳️',c:-5,bad:1,d:'กลุ่มดาวทุกดวงไม่ชอบท่าน -20',fav:-20});
const TIERS=[{n:'ธรรมดา',k:'t0'},{n:'ไม่ธรรมดา',k:'t1'},{n:'หายาก',k:'t2'},{n:'ล้ำค่า',k:'t3'},{n:'ตำนาน',k:'t4'}];
const tierOf=t=>t.bad?null:t.c<=1?0:t.c<=2?1:t.c<=4?2:t.c<=7?3:4;
const tierCls=t=>t.bad?'tb':TIERS[tierOf(t)].k,tierName=t=>t.bad?'ข้อเสีย':TIERS[tierOf(t)].n;
const _newLifeT=newLife;newLife=function(cfg){const p=_newLifeT(cfg);(p.talents||[]).forEach(id=>{const t=TALENTS.find(x=>x.id===id);if(t&&t.fav&&id!=='starlove')STARS.forEach(s=>p.favor[s.id]+=t.fav)});return p};
