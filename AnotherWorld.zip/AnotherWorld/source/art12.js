// =============== v11: ฉากแนวกว้างแบบ Way of Xian (วาดใหม่ทุกฉาก ไม่ใช้ภาพบ้านแล้ว) ===============
const CX=(W-576)/2,HX=W/2-90;
const GSET=()=>!P?'n':SEASON(P.m)==='winter'?'w':SEASON(P.m)==='autumn'?'a':'n';
// ภาพหลังแบบชั้น ปูต่อกันเต็มความกว้าง (ปราสาทวาดครั้งเดียวตรงกลาง)
function ghLay(g,set,t,move,only){const L=['5','castle','4','3','2','1'].filter(n=>!only||only.includes(n));
 L.forEach((n,i)=>{const im=IMG[`a/gh/c_${set}${n}.png`]||img(`a/gh/c_${set}${n}.png`);if(!im||!im.complete)return;
  if(n==='castle'){g.drawImage(im,W/2-im.width/2+120,0);return}const sp=move?i*i*.08:0,off=-((t*sp)%im.width);for(let x=off;x<W;x+=im.width)g.drawImage(im,Math.floor(x),0)})}
function tileImgs(g,key,t,move){const L=MF.bg[key];if(!L)return false;L.forEach((src,i)=>{const im=IMG[src];if(!im||!im.complete)return;const sp=move?i*i*.06:0,w=im.width,off=-((t*sp)%w);for(let x=off;x<W;x+=w)g.drawImage(im,Math.floor(x),0,w,H)});return true}
// ---- ชิ้นส่วนพิกเซล ----
const lerpC=(a,b,k)=>{const p=s=>[1,3,5].map(i=>parseInt(s.slice(i,i+2),16));const A=p(a),B=p(b);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*k).toString(16).padStart(2,'0')).join('')};
function grad(g,y0,y1,c0,c1){for(let y=y0;y<y1;y+=4)R(g,0,y,W,4,lerpC(c0,c1,(y-y0)/(y1-y0)))}
function plankWall(g,y0,y1,c,c2,c3){R(g,0,y0,W,y1-y0,c);for(let x=0;x<W;x+=26){R(g,x,y0,2,y1-y0,c2);for(let y=y0+8+(x*7)%40;y<y1;y+=56)R(g,x+8,y,3,3,c3)}}
function stoneWall(g,y0,y1,c,c2){R(g,0,y0,W,y1-y0,c);for(let y=y0,r=0;y<y1;y+=22,r++){R(g,0,y,W,2,c2);for(let x=(r%2)*28;x<W;x+=56)R(g,x,y,2,22,c2)}}
function boards(g,y,c,c2){R(g,0,y,W,H-y,c);R(g,0,y,W,3,c2);for(let r=0,yy=y+10;yy<H;yy+=10,r++){R(g,0,yy,W,1,c2);for(let x=(r*37)%90;x<W;x+=90)R(g,x,yy-9,1,9,c2)}}
function stoneFloor(g,y,c,c2){R(g,0,y,W,H-y,c);for(let yy=y,r=0;yy<H;yy+=9,r++){R(g,0,yy,W,1,c2);for(let x=(r%2)*30;x<W;x+=60)R(g,x,yy,1,9,c2)}}
function windowW(g,x,y,w,h,day,frame='#4a3220'){R(g,x-5,y-5,w+10,h+10,frame);R(g,x,y,w,h,day?'#9fd4f2':'#18234a');if(day){R(g,x+4,y+4,w/3,3,'#d8f0ff')}else R(g,x+w-16,y+8,8,8,'#f3ecc0');R(g,x+w/2-2,y,4,h,frame);R(g,x,y+h/2-2,w,4,frame);R(g,x-8,y+h+4,w+16,5,frame)}
function glow(g,x,y,r,a,c='255,190,90'){const gr=g.createRadialGradient(x,y,0,x,y,r);gr.addColorStop(0,`rgba(${c},${a})`);gr.addColorStop(1,`rgba(${c},0)`);g.fillStyle=gr;g.fillRect(x-r,y-r,r*2,r*2)}
function lantern(g,x,y,t,c='#ffcf6b'){R(g,x+5,y-14,2,14,'#3a2a1a');R(g,x,y,12,14,'#5a3a1a');R(g,x+2,y+2,8,10,c);glow(g,x+6,y+8,40,.25+((t+x)%7)/40)}
function candle(g,x,y,t){R(g,x,y,4,12,'#f2ead0');R(g,x+1,y-4-(t+x)%2,2,4,'#ffcf6b');glow(g,x+2,y-3,18,.3)}
function shelf(g,x,y,w,h,day){R(g,x,y,w,h,'#5a3a22');R(g,x+4,y+4,w-8,h-8,'#3a2616');for(let r=0;r<(h-8)/30|0;r++){const yy=y+4+r*30;R(g,x+4,yy+26,w-8,4,'#5a3a22');for(let i=0,bx=x+8;bx<x+w-12;i++){const bw=6+hr(i+x+r)*6|0;R(g,bx,yy+6+hr(i*3+r)*6,bw,20-hr(i*3+r)*6,['#8a2a2a','#2a4a8a','#3a6a3a','#8a6a2a','#5a2a6a'][(i+r+x)%5]);bx+=bw+1}}}
function table(g,x,w,y=FEET-44,c='#7a5232'){R(g,x,y,w,8,c);R(g,x,y+8,w,3,'#4a301c');R(g,x+6,y+11,6,FEET-y-11,'#4a301c');R(g,x+w-12,y+11,6,FEET-y-11,'#4a301c')}
function stool(g,x){R(g,x,FEET-24,22,5,'#6a4426');R(g,x+3,FEET-19,4,19,'#4a301c');R(g,x+15,FEET-19,4,19,'#4a301c')}
function barrel(g,x,y=FEET){R(g,x,y-40,30,40,'#7a4a26');R(g,x-2,y-34,34,4,'#3a3030');R(g,x-2,y-12,34,4,'#3a3030');R(g,x+6,y-40,2,40,'#6a3e1e');R(g,x+20,y-40,2,40,'#6a3e1e')}
function crate(g,x,y,s=28){R(g,x,y-s,s,s,'#9a7040');R(g,x+2,y-s+2,s-4,s-4,'#b08450');R(g,x,y-s/2-1,s,3,'#7a5530');R(g,x+s/2-1,y-s,3,s,'#7a5530')}
function bed(g,x,w=120,c='#c8c0e0'){R(g,x,FEET-34,w,22,'#6a4426');R(g,x+4,FEET-44,w-8,12,c);R(g,x+6,FEET-50,30,8,'#f4f0e6');R(g,x-4,FEET-60,8,60,'#5a3a20');R(g,x+w-4,FEET-46,8,46,'#5a3a20')}
function pillar(g,x,h,c,c2){R(g,x-4,FEET-h-10,40,10,c2);R(g,x,FEET-h,32,h,c);R(g,x+4,FEET-h,4,h,c2);R(g,x+24,FEET-h,3,h,c2);R(g,x-4,FEET-10,40,10,c2)}
function banner(g,x,y,w,h,c,c2){R(g,x-4,y-4,w+8,4,'#5a3a20');R(g,x,y,w,h,c);g.fillStyle=c;g.beginPath();g.moveTo(x,y+h);g.lineTo(x+w/2,y+h+12);g.lineTo(x+w,y+h);g.fill();R(g,x+w/2-6,y+h/2-6,12,12,c2)}
function fireplace(g,x,t){R(g,x,FEET-110,110,110,'#6a6460');R(g,x+4,FEET-106,102,6,'#8a8480');R(g,x+18,FEET-70,74,70,'#1a1210');for(let i=0;i<5;i++){const f=(t+i*3)%8;R(g,x+28+i*12,FEET-20-f*3,8,16+f*2,i%2?'#ff9a3a':'#ffcf5a')}glow(g,x+55,FEET-30,120,.35,'255,140,60')}
function plant(g,x,y=FEET){R(g,x,y-22,22,22,'#8a5a3a');for(let i=0;i<6;i++)R(g,x+2+i*3,y-46+hr(i+x)*14,5,26,'#3a7a3a')}
function rug(g,x,w,c,c2){R(g,x,FEET-6,w,10,c);R(g,x+4,FEET-4,w-8,2,c2)}
function statue(g,x,c,t,i){R(g,x-6,FEET-34,52,34,'#8a8478');R(g,x-2,FEET-38,44,6,'#a8a298');R(g,x+10,FEET-120,20,82,c);R(g,x+6,FEET-136,28,22,c);R(g,x+2,FEET-100,36,10,c);glow(g,x+20,FEET-130,46,.18+((t+i*5)%10)/60,'200,180,255')}
function rays(g,x,w,t,c='255,240,200'){g.save();g.globalAlpha=.10+((t%20)/200);g.fillStyle=`rgb(${c})`;g.beginPath();g.moveTo(x,0);g.lineTo(x+w,0);g.lineTo(x+w+160,FEET);g.lineTo(x+120,FEET);g.fill();g.restore()}
function stall(g,x,c1,c2,goods,t){R(g,x,FEET-100,6,100,'#5a3a20');R(g,x+124,FEET-100,6,100,'#5a3a20');for(let i=0;i<8;i++)R(g,x-6+i*18,FEET-112,18,22,i%2?c1:c2);for(let i=0;i<8;i++)R(g,x-6+i*18,FEET-90,18,6,i%2?c1:c2);
 R(g,x,FEET-46,130,10,'#8a5a32');R(g,x+4,FEET-36,122,36,'#6a4426');goods.forEach((gc,i)=>{R(g,x+8+i*24,FEET-58,18,12,gc);R(g,x+10+i*24,FEET-62,14,5,gc)});lantern(g,x+60,FEET-86,t)}
function lampPost(g,x,t,night){R(g,x,FEET-120,6,120,'#2a2a30');R(g,x-8,FEET-128,22,10,'#2a2a30');R(g,x-4,FEET-124,14,10,night?'#ffd36b':'#d8d0a0');if(night)glow(g,x+3,FEET-118,60,.4)}
function fountain(g,x,t){R(g,x-80,FEET-30,160,30,'#8a8478');R(g,x-74,FEET-26,148,8,'#4a90c8');R(g,x-12,FEET-90,24,60,'#9a948a');R(g,x-30,FEET-96,60,8,'#a8a298');for(let i=0;i<10;i++){const k=((t*.6+i*2.3)%10)/10;R(g,x-24+i*5,FEET-100+k*70,2,4,'#bfe4ff')}R(g,x-4,FEET-112,8,14,'#bfe4ff')}
function fenceRow(g,x0,x1,y=FEET){for(let x=x0;x<x1;x+=26){R(g,x,y-34,6,34,'#7a5a3a');}R(g,x0,y-28,x1-x0,4,'#8a6a42');R(g,x0,y-16,x1-x0,4,'#8a6a42')}
function water(g,y,t,c1,c2){R(g,0,y,W,FEET-y+6,c1);for(let i=0;i<70;i++){const x=(hr(i)*W+t*(.5+hr(i*3)))%W,yy=y+6+hr(i*7)*(FEET-y-6);R(g,x,yy,10+hr(i*5)*20,2,c2)}}
function dummy(g,x,t){R(g,x+12,FEET-110,6,110,'#6a4426');R(g,x,FEET-96,30,40,'#c8a86a');R(g,x+4,FEET-118,22,22,'#c8a86a');R(g,x-14,FEET-86,58,6,'#6a4426');R(g,x+8,FEET-84,14,4,'#a83a2a')}
function rack(g,x){R(g,x,FEET-80,70,6,'#5a3a20');R(g,x+4,FEET-80,6,80,'#5a3a20');R(g,x+60,FEET-80,6,80,'#5a3a20');for(let i=0;i<4;i++){R(g,x+14+i*12,FEET-120,3,80,'#c8ccd8');R(g,x+12+i*12,FEET-90,7,3,'#6a4a2a')}}
function npcTag(g,txt,x){tag(g,txt,x,FEET-CH*2-6)}
// ---- พื้นดินกลางแจ้งแบบกว้าง ----
function dirt(g,c1,c2,c3){R(g,0,FEET-6,W,H-FEET+6,c1);R(g,0,FEET-6,W,3,c2);for(let i=0;i<120;i++)R(g,hr(i)*W,FEET-2+hr(i*7)*16,3+hr(i*3)*4,2,c3)}
function grassTop(g,c){for(let i=0;i<180;i++)R(g,hr(i*1.7)*W,FEET-10-hr(i*3)*5,2,5+hr(i*5)*5,c)}
// ---- ฉากทั้งหมด ----
const SC12={
 // บ้าน: ตามฐานะครอบครัว
 home:(g,t,day)=>{const k=typeof HOME_KIND==='function'?HOME_KIND():'home',mk=P&&P.homeMark&&P.homeMark.until>P.m?P.homeMark.k:null;
  if(k==='hut'){plankWall(g,0,FEET-34,'#5e4630','#4a3624','#3a2a1a');boards(g,FEET-34,'#4a3624','#3a2a1a');windowW(g,W/2-60,60,90,70,day,'#3a2a1a');
   R(g,80,FEET-60,150,26,'#8a7a5a');R(g,84,FEET-68,48,10,'#c8b88a');table(g,W-330,110);stool(g,W-350);stool(g,W-200);R(g,W-300,FEET-60,20,12,'#7a4a2a');candle(g,W-260,FEET-58,t);
   R(g,W-150,FEET-120,90,120,'#3a3a3a');R(g,W-140,FEET-60,70,60,'#1a1210');for(let i=0;i<4;i++){const f=(t+i*3)%8;R(g,W-130+i*14,FEET-14-f*2,8,12+f,i%2?'#ff9a3a':'#ffcf5a')}glow(g,W-105,FEET-30,90,.3,'255,140,60');R(g,W-450,FEET-90,40,56,'#6a5a40');for(let i=0;i<3;i++)R(g,W-446,FEET-84+i*16,32,3,'#4a3a26')}
  else if(k==='church'){stoneWall(g,0,FEET-34,'#cfc6b4','#b8ae9a');stoneFloor(g,FEET-34,'#8a7a64','#76664e');
   [[140,40],[W/2-40,26],[W-220,40]].forEach(([x,y])=>{R(g,x-4,y-4,88,124,'#5a4a7a');R(g,x,y,80,116,day?'#a8c8f0':'#1a2448');R(g,x+38,y,4,116,'#5a4a7a');R(g,x,y+54,80,4,'#5a4a7a');R(g,x+10,y+10,20,20,'#e8a8c8');R(g,x+50,y+70,20,20,'#a8e8c8');if(day)rays(g,x,80,t)});
   R(g,W/2-3,FEET-150,6,40,'#d8b040');R(g,W/2-13,FEET-136,26,6,'#d8b040');for(let i=0;i<6;i++){R(g,60+i*190,FEET-40,140,10,'#6a4a2a');R(g,66+i*190,FEET-30,6,30,'#4a3420');R(g,190+i*190,FEET-30,6,30,'#4a3420')}for(let i=0;i<5;i++)candle(g,W/2-60+i*28,FEET-80,t);R(g,W/2-80,FEET-70,160,8,'#e8e0c8');R(g,W/2-74,FEET-62,148,62,'#b8a888')}
  else if(k==='manor'){plankWall(g,0,FEET-40,'#4a2a3a','#5a3448','#3a2030');for(let x=20;x<W;x+=150){R(g,x,24,110,FEET-84,'#5e3a4e');R(g,x+5,29,100,FEET-94,'#6a4458')}R(g,0,FEET-44,W,6,'#d8b040');stoneFloor(g,FEET-38,'#6a4a2a','#5a3e22');rug(g,W/2-260,520,'#8a2a34','#d8b040');
   windowW(g,W/2-90,40,180,140,day,'#6a4a2a');R(g,W/2-100,30,200,8,'#d8b040');R(g,100,FEET-90,180,56,'#7a2a34');R(g,100,FEET-98,180,10,'#9a3a44');R(g,96,FEET-120,8,86,'#5a2a20');shelf(g,W-260,FEET-200,150,200,day);
   R(g,W/2+170,FEET-170,10,120,'#d8b040');R(g,W/2+140,FEET-180,70,12,'#d8b040');for(let i=0;i<4;i++)candle(g,W/2+144+i*18,FEET-196,t);plant(g,40);plant(g,W-80)}
  else{plankWall(g,0,FEET-36,'#b89870','#a07e58','#8a6a46');boards(g,FEET-36,'#7a5232','#5e3e24');windowW(g,W/2-70,46,120,100,day);
   R(g,40,FEET-200,8,166,'#6e4a30');bed(g,90,150,'#b8c4e0');shelf(g,280,FEET-170,110,136,day);table(g,W-380,140);stool(g,W-400);stool(g,W-220);R(g,W-350,FEET-58,24,14,'#7a3a2a');candle(g,W-300,FEET-56,t);
   R(g,W-160,FEET-150,100,116,'#6a6460');R(g,W-148,FEET-80,76,80,'#1a1210');for(let i=0;i<4;i++){const f=(t+i*3)%8;R(g,W-140+i*16,FEET-16-f*2,9,14+f,i%2?'#ff9a3a':'#ffcf5a')}glow(g,W-110,FEET-30,100,.3,'255,140,60');plant(g,W/2+120);rug(g,W/2-140,280,'#7a3a3a','#c8a060')}
  if(mk==='wedding'){for(let i=0;i<30;i++)R(g,i*W/29,12+Math.sin(i)*6,10,10,i%2?'#ff9ac0':'#fff4f8');R(g,0,8,W,3,'#e8d0a0')}
  if(mk==='baby'){const x=W/2+200;R(g,x,FEET-40,90,34,'#8a6040');R(g,x+4,FEET-48,82,10,'#f4ecd8');R(g,x-6,FEET-58,6,58,'#6a4a2e');R(g,x+90,FEET-58,6,58,'#6a4a2e')}
  if(mk==='funeral'){for(let i=0;i<8;i++){R(g,60+i*150,30,4,26,'#ddd');R(g,48+i*150,56,28,34,'#f4f4f4')}R(g,0,0,W,12,'#f0f0f0');for(let i=0;i<5;i++)candle(g,W/2+120+i*20,FEET-80,t)}
  if(mk==='raid'){for(let i=0;i<20;i++)R(g,hr(i)*W,20+hr(i*3)*160,30+hr(i*5)*40,6+hr(i*7)*10,'rgba(30,20,15,.55)');R(g,W/2-200,FEET-24,60,20,'#5a4a3a')}},
 // สถาบันเวท
 school:(g,t,day)=>{stoneWall(g,0,FEET-34,'#6a6070','#5a5060');stoneFloor(g,FEET-34,'#4a4250','#3a3442');for(let x=0;x<W;x+=260)pillar(g,x+20,FEET-20,'#8a8090','#6a6070');
  R(g,W/2-200,40,360,130,'#2a3a30');R(g,W/2-206,34,372,8,'#6a4a2a');g.fillStyle='#d8f0d0';g.font='16px Sarabun';g.textAlign='left';g.fillText('ᚱᚢᚾ · วงเวทพื้นฐาน ๗ ธาตุ',W/2-180,70);g.strokeStyle='#cfe8c8';g.lineWidth=2;g.beginPath();g.arc(W/2-60,120,32,0,7);g.stroke();g.beginPath();g.moveTo(W/2-92,120);g.lineTo(W/2-28,120);g.moveTo(W/2-60,88);g.lineTo(W/2-60,152);g.stroke();
  shelf(g,120,FEET-210,140,176,day);shelf(g,W-260,FEET-210,140,176,day);for(let i=0;i<4;i++)table(g,120+i*250,130,FEET-46,'#8a6a42');for(let i=0;i<4;i++){R(g,150+i*250,FEET-56,16,10,'#e8e0c8');candle(g,210+i*250,FEET-58,t)}
  windowW(g,W/2+220,50,70,110,day,'#5a5060');windowW(g,W/2-330,50,70,110,day,'#5a5060');for(let i=0;i<3;i++){const a=t*.05+i*2.1;R(g,W/2+140+Math.cos(a)*30,90+Math.sin(a)*14,5,5,'#b48cff')}},
 // กิลด์นักผจญภัย
 guild:(g,t,day)=>{plankWall(g,0,FEET-36,'#4a3424','#3a281a','#2e2014');boards(g,FEET-36,'#5a4030','#4a3426');
  R(g,230,40,220,150,'#6b4a2a');R(g,236,46,208,138,'#8a6a3c');for(let i=0;i<10;i++)R(g,244+(i%5)*40,54+(i/5|0)*62,32,48,['#efe6d0','#f6d6a0','#d9ecff','#f0d0d0'][i%4]);g.fillStyle='#ffd36b';g.font='bold 13px Mitr';g.textAlign='center';g.fillText('กระดานภารกิจ',340,32);
  banner(g,W/2-150,20,50,80,'#7a2a2a','#ffd36b');banner(g,W/2+100,20,50,80,'#2a4a7a','#ffd36b');g.fillStyle='#ffd36b';g.font='bold 18px Mitr';g.fillText('กิลด์นักผจญภัย',W/2,60);
  R(g,W/2+190,FEET-80,320,48,'#6e4a2c');R(g,W/2+186,FEET-88,328,10,'#8a6a3c');for(let i=0;i<3;i++)R(g,W/2+220+i*90,FEET-100,20,12,'#d8c8a0');
  R(g,W-140,40,60,40,'#5a3a20');R(g,W-130,46,40,28,'#d8d0c0');R(g,W-120,52,6,6,'#2a2a2a');R(g,W-104,52,6,6,'#2a2a2a');
  table(g,330,120);stool(g,310);stool(g,460);barrel(g,40);barrel(g,76);lantern(g,W/2-40,40,t);lantern(g,W/2+300,40,t)},
 // โรงเตี๊ยม
 tavern:(g,t,day)=>{plankWall(g,0,FEET-36,'#5a3a24','#4a2e1a','#3a2414');boards(g,FEET-36,'#4a3020','#3a2416');for(let x=0;x<W;x+=180)R(g,x,0,14,FEET-36,'#3a2414');R(g,0,0,W,16,'#3a2414');
  R(g,60,FEET-120,360,10,'#3a2414');for(let i=0;i<8;i++){R(g,74+i*42,FEET-150,14,28,['#4a8a4a','#8a3a2a','#c8a040','#4a4a8a'][i%4]);R(g,77+i*42,FEET-158,8,8,'#3a2414')}
  R(g,40,FEET-70,400,40,'#6e4a2c');R(g,36,FEET-76,408,8,'#8a6a3c');for(let i=0;i<4;i++)barrel(g,470+i*36,FEET-40);
  table(g,W/2+40,140);stool(g,W/2+20);stool(g,W/2+170);R(g,W/2+70,FEET-56,12,12,'#d8c8a0');R(g,W/2+110,FEET-58,10,14,'#c8a040');table(g,W-300,140);stool(g,W-320);stool(g,W-150);
  fireplace(g,W-140,t);for(let i=0;i<5;i++)lantern(g,120+i*220,30,t);windowW(g,W/2-170,60,90,70,day,'#3a2414')},
 // วิหารแห่งทวยเทพ
 shrine:(g,t,day)=>{grad(g,0,FEET-30,'#2a2440','#4a4060');stoneFloor(g,FEET-30,'#5a5468','#48425a');for(let x=40;x<W;x+=180)pillar(g,x,FEET-10,'#a8a2b8','#8a849a');
  if(day){rays(g,W/2-140,60,t);rays(g,W/2+80,60,t)}const cols=['#c8c0ff','#ffd08a','#ff8a6a','#ffe0f0','#d8d8a0','#e8e8f0','#6aa86a'];for(let i=0;i<7;i++)statue(g,110+i*150,cols[i],t,i);
  R(g,W/2-90,FEET-60,180,60,'#8a849a');R(g,W/2-96,FEET-66,192,8,'#b8b2c8');for(let i=0;i<7;i++)candle(g,W/2-70+i*22,FEET-80,t);glow(g,W/2,FEET-80,140,.18,'255,220,160')},
 // วิหารรักษา
 hospital:(g,t,day)=>{stoneWall(g,0,FEET-34,'#e6e2d6','#d4cfc0');stoneFloor(g,FEET-34,'#c8c0ae','#b4ac98');for(let i=0;i<4;i++){windowW(g,120+i*260,50,80,90,day,'#a8a090');if(day)rays(g,120+i*260,80,t)}
  for(let i=0;i<4;i++)bed(g,90+i*270,140,'#f4f4f8');g.fillStyle='#e8b840';g.beginPath();g.arc(W/2,70,22,0,7);g.fill();for(let i=0;i<12;i++){const an=i/12*6.28+t*.02;R(g,W/2+Math.cos(an)*34-2,70+Math.sin(an)*34-2,5,5,'#e8b840')}for(let i=0;i<5;i++)plant(g,40+i*260,FEET);R(g,W-120,FEET-90,70,90,'#8a6a42');for(let i=0;i<6;i++)R(g,W-114+(i%3)*22,FEET-84+(i/3|0)*30,14,20,['#8ad0a0','#d0a0d0','#a0c0e8'][i%3])},
 // บ่อนใต้ดิน
 casino:(g,t,day)=>{stoneWall(g,0,FEET-34,'#2a1e22','#1e1418');boards(g,FEET-34,'#3a1424','#2a0e1a');for(let i=0;i<10;i++)lantern(g,60+i*115,24,t,i%2?'#ff6a8a':'#ffcf6b');
  for(let i=0;i<3;i++){const x=120+i*340;R(g,x,FEET-60,220,30,'#0f5a2a');R(g,x-4,FEET-64,228,6,'#8a5a2a');R(g,x+20,FEET-30,8,30,'#3a2414');R(g,x+192,FEET-30,8,30,'#3a2414');for(let j=0;j<5;j++)R(g,x+30+j*36,FEET-56,10,6,j%2?'#fff':'#ff3b3b')}
  R(g,W/2-30,40,60,80,'#1a0a14');R(g,W/2-24,46,48,40,'#8a3a5a');g.fillStyle='#ffd36b';g.font='bold 14px Mitr';g.textAlign='center';g.fillText('เดิมพันด้วยชีวิต',W/2,140)},
 // ห้องประเมินพลัง (ลูกแก้วมานา)
 awaken:(g,t,day)=>{grad(g,0,FEET-30,'#0d1430','#1a2450');stoneFloor(g,FEET-30,'#20284a','#2a3460');for(let x=30;x<W;x+=140)pillar(g,x,FEET-10,'#2a3460','#1a2450');
  R(g,W/2+120,FEET-90,60,80,'#3a3f60');R(g,W/2+108,FEET-14,84,8,'#555c86');const p=(t%20)/20;g.fillStyle=`rgba(120,200,255,${.45+p*.4})`;g.beginPath();g.arc(W/2+150,FEET-112,24+p*4,0,7);g.fill();glow(g,W/2+150,FEET-112,120,.3,'120,200,255');R(g,W/2+143,FEET-122,6,6,'#fff');
  for(let i=0;i<12;i++){const a=t*.04+i*.52;R(g,W/2+150+Math.cos(a)*70,FEET-112+Math.sin(a)*30,3,3,'#9fd0ff')}},
 // จัตุรัสกลางเมือง
 city:(g,t,day)=>{ghLay(g,GSET(),t,false,['5','castle','4']);townRow(g,GSET());stoneFloor(g,FEET-8,'#7a7268','#6a6258');fountain(g,W/2+80,t);lampPost(g,W/2-260,t,!day);lampPost(g,W/2+400,t,!day);banner(g,120,FEET-180,40,70,'#7a2a2a','#ffd36b');banner(g,W-160,FEET-180,40,70,'#2a4a7a','#ffd36b');crate(g,60,FEET);crate(g,88,FEET);barrel(g,W-90)},
 // ตลาด
 market:(g,t,day)=>{ghLay(g,GSET(),t,false,['5','castle','4']);townRow(g,GSET());dirt(g,'#7a6448','#8a7458','#5a4a34');
  stall(g,80,'#c8473a','#f0e6d0',['#d84a3a','#f0c040','#7ac04a','#d88a3a'],t);stall(g,W/2+180,'#3a7ac8','#f0e6d0',['#a8d0f0','#e8e0c8','#c8a8e8','#f0d0a0'],t);stall(g,W-200,'#4a9a4a','#f0e6d0',['#8a5a3a','#c8c8c8','#5a8a3a','#e8c060'],t);crate(g,240,FEET);crate(g,268,FEET);crate(g,252,FEET-28);barrel(g,W/2+340);lampPost(g,W/2-140,t,!day)},
 // ทุ่งนา
 field:(g,t,day)=>{ghLay(g,GSET(),t,false,['5','4','3']);const s=GSET();dirt(g,s==='w'?'#d8e4ee':'#5a6a34',s==='w'?'#ffffff':'#7a8a44','#4a5a2a');
  if(s!=='w')for(let r=0;r<3;r++)for(let x=-20+r*9;x<W;x+=18)R(g,x,FEET-48+r*14,5,30-r*6,s==='a'?'#d8a840':'#c8b850');
  fenceRow(g,0,W/2-120);fenceRow(g,W/2+260,W);const x=W/2+160;R(g,x,FEET-110,6,110,'#6a4426');R(g,x-30,FEET-90,66,6,'#6a4426');R(g,x-10,FEET-104,26,34,'#a8783a');R(g,x-4,FEET-126,18,22,'#d8c070');R(g,x-14,FEET-132,38,8,'#8a5a2a');
  R(g,W-170,FEET-200,60,200,'#d8d0c0');g.fillStyle='#8a4a2a';g.beginPath();g.moveTo(W-180,FEET-200);g.lineTo(W-140,FEET-240);g.lineTo(W-100,FEET-200);g.fill();for(let i=0;i<4;i++){const a=t*.05+i*1.57;g.strokeStyle='#e8e0c8';g.lineWidth=6;g.beginPath();g.moveTo(W-140,FEET-190);g.lineTo(W-140+Math.cos(a)*70,FEET-190+Math.sin(a)*70);g.stroke()}},
 // ริมทะเลสาบ
 lake:(g,t,day)=>{ghLay(g,GSET(),t,false,['5','castle','4']);const s=GSET();water(g,FEET-90,t,s==='w'?'#b8d0e0':'#3a7aa8',s==='w'?'#e8f4ff':'#8ac8e8');
  R(g,0,FEET-8,W,14,s==='w'?'#e8eef4':'#6a8a3a');for(let i=0;i<40;i++)R(g,hr(i)*W,FEET-26-hr(i*3)*10,3,22,s==='w'?'#c8d4dc':'#4a7a2a');
  R(g,W/2+120,FEET-30,320,10,'#7a5a3a');for(let x=W/2+130;x<W/2+440;x+=50)R(g,x,FEET-22,8,30,'#5a3a20');
  const bx=W/2+300+Math.sin(t*.05)*20;R(g,bx,FEET-58,120,12,'#6a4426');R(g,bx+10,FEET-48,100,6,'#4a2e16');R(g,bx+50,FEET-120,4,64,'#5a3a20');g.fillStyle='#e8e0c8';g.beginPath();g.moveTo(bx+54,FEET-118);g.lineTo(bx+100,FEET-70);g.lineTo(bx+54,FEET-70);g.fill();
  R(g,140,FEET-160,10,150,'#5a3a20');g.fillStyle=s==='w'?'#e8f0f8':s==='a'?'#c8701a':'#3a7a3a';g.beginPath();g.arc(145,FEET-170,60,0,7);g.fill()},
 // ลานฝึก
 train:(g,t,day)=>{ghLay(g,GSET(),t,false);dirt(g,'#a88a5a','#c8a870','#8a6a40');for(let i=0;i<3;i++)dummy(g,W/2+170+i*110,t);rack(g,120);rack(g,W-160);R(g,W/2-300,FEET-12,600,4,'#8a6a40');banner(g,40,FEET-200,40,80,'#7a2a2a','#ffd36b')},
 // ปากทางดันเจี้ยน
 gatezone:(g,t,day)=>{ghLay(g,'a',t,false);dirt(g,'#4a3a20','#6a5030','#3a2a14');const x=W/2+200;
  R(g,x-110,FEET-230,40,230,'#6a6460');R(g,x+110,FEET-230,40,230,'#6a6460');R(g,x-120,FEET-250,280,30,'#7a746c');for(let y=FEET-230;y<FEET;y+=22){R(g,x-110,y,40,2,'#4a4440');R(g,x+110,y,40,2,'#4a4440')}portal(g,'blue',x+20,FEET-10,2.2,t);
  for(let i=0;i<2;i++){const tx=120+i*220;g.fillStyle=i?'#8a5a3a':'#6a6a3a';g.beginPath();g.moveTo(tx,FEET);g.lineTo(tx+60,FEET-90);g.lineTo(tx+120,FEET);g.fill();R(g,tx+52,FEET-40,16,40,'#2a1a10')}
  [W/2-120,W-80].forEach(px=>{R(g,px,FEET-120,4,120,'#5a3a20');R(g,px+4,FEET-118,30,18,'#d8402a')});crate(g,W/2-60,FEET);barrel(g,W/2-30)},
 // ถนนระหว่างเดินทาง
 road:(g,t,day)=>{ghLay(g,GSET(),t,true);dirt(g,'#8a7048','#a88a5a','#6a5434');R(g,0,FEET-2,W,6,'#a0845a')},
 // ห้องฝึกในหอคอย / ฉากอื่นใช้ภาพเดิม
};
SC12.gate=SC12.gatezone;
// แถวหลังคาเมืองไกล ๆ (ไม่ใช่ภาพบ้าน วาดเป็นเงา)
function townRow(g,s){const base=FEET-60,c=s==='w'?'#8a96a8':s==='a'?'#7a5a3a':'#5a6a5a',r=s==='w'?'#5a6a84':s==='a'?'#8a3a2a':'#7a3a2a';
 for(let i=0,x=-30;x<W;i++){const w=70+hr(i)*60|0,h=50+hr(i*3)*50|0;R(g,x,base-h,w,h+60,c);g.fillStyle=r;g.beginPath();g.moveTo(x-6,base-h);g.lineTo(x+w/2,base-h-26-hr(i*5)*16);g.lineTo(x+w+6,base-h);g.fill();
  for(let k=0;k<2;k++)R(g,x+12+k*(w-30),base-h+18,10,12,'#f0d890');if(s==='w')R(g,x-4,base-h-4,w+8,5,'#f4f8fc');x+=w+8}}
// ใช้ฉากใหม่แทนฉากในอาคารเดิม
['home','school','guild','hospital','casino','awaken','tavern','shrine'].forEach(k=>INDOOR[k]=SC12[k]);
Object.assign(SCENE_CAP,{school:'ห้องเรียนสถาบันเวท',tavern:'โรงเตี๊ยม',shrine:'วิหารแห่งทวยเทพ',market:'ตลาด',field:'ทุ่งนา',lake:'ริมทะเลสาบ',hospital:'วิหารรักษา',guild:'กิลด์นักผจญภัย',casino:'บ่อนใต้ดิน',awaken:'ห้องประเมินพลัง'});
function bgWide(g,key,t,day,move){const f=SC12[key];if(f){f(g,t,day);return}
 if(MF.bg[key]){tileImgs(g,key,t,move);ground(g,key,t)}else{ghLay(g,GSET(),t,move);ground(g,'train',t)}}
// คนที่อยู่ ณ ที่นั้น (แบบ WoX: เห็นคนรู้จักยืนอยู่ในฉากพร้อมป้ายชื่อ)
function presentPeople(key){if(!P||!P.people)return [];const s=P.spot||key;return P.people.filter(x=>x.alive&&x.home===s&&!P.party.includes(x.id)).slice(0,2)}
drawScene=function(cv,sc,P0,t,night){if(!cv)return;const g=cv.getContext('2d');g.imageSmoothingEnabled=false;const key=sceneKey(sc),day=!night;
 const indoor=!!INDOOR[key];
 if(!P0){bgWide(g,key,t,true,true);weather(g,'spring',t,true);return}
 if(key==='death'){bgWide(g,'death',t,day,false);R(g,W/2-18,236,36,70,'#4a4f5a');R(g,W/2-32,252,64,12,'#4a4f5a');nightTint(g,night);return}
 const walk=key==='road';bgWide(g,key,t,day,walk);
 if(key==='gatered')portal(g,'red',W/2+220,FEET-6,1.8,t);
 if(key==='sky'){g.strokeStyle='rgba(180,140,255,.6)';g.beginPath();[[W/2-120,60],[W/2-60,36],[W/2,70],[W/2+60,40],[W/2+130,78]].forEach(([x,y],i)=>i?g.lineTo(x,y):g.moveTo(x,y));g.stroke()}
 const hero=key==='train'?'Attack':walk?'Walk':'Idle';
 P0.party.forEach((id,i)=>{const x=person(id);if(x&&x.alive)person4(g,x.look,x.tint,walk?'Walk':'Idle',t+i*3,HX-80-i*70,false,null,1.8)});
 person4(g,P0.look,P0.tint,hero,t,HX,false,P0.name,2,P0.cls);
 if(key==='guild')person4(g,{...CLERK,face:3,head:4,accC:0},0,'Idle',t,W/2+350,true,'เจ้าหน้าที่กิลด์');
 if(key==='tavern')person4(g,{...THUG,hairC:9,outfit:3,face:1,accC:11},0,'Idle',t,240,false,'เจ้าของโรงเตี๊ยม');
 const mon=key==='fire'?'wolf_b':(sc==='dungeon'||key==='gatered')?P0.mon:null;
 if(mon&&MF.mons[mon]){shadow(g,HX+300,FEET,40);spr(g,MF.mons[mon].Idle,t,HX+300,FEET,2,true)}
 const talk=P0.talk&&P0.talk.until>=P0.m?person(P0.talk.who):null;
 if(talk){person4(g,talk.look,talk.tint,'Idle',t+4,HX+160,true,`${talk.n} (${typeof relLabel==='function'?relLabel(talk):talk.role})`);if(P0.talk.line)bubble(g,P0.talk.line,HX+160,FEET-CH*2-30)}
 else if(!walk&&!mon)presentPeople(key).forEach((x,i)=>person4(g,x.look,x.tint,'Idle',t+i*5,HX+200+i*140,true,`${x.n} (${typeof relLabel==='function'?relLabel(x):x.role})`,1.9));
 weather(g,SEASON(P0.m),t,!indoor);nightTint(g,night)};
talkInset=function(){};

// เด็กตัวเล็กกว่าผู้ใหญ่
const _p4=person4;person4=function(g,look,tint,name,f,x,flip,label,sc=2,wep){if(look&&look.small)sc*=.68;return _p4(g,look,tint,name,f,x,flip,label,sc,wep)};

// จุดยึดเท้าต่อท่า (สร้างจาก /tmp/anchor.py): ไม่ให้ศพจมพื้น ไม่ให้ตัวกระโดดตอนเปลี่ยนท่า
const ANCHORS={"slime_g":{"Hurt":[0,-6]},"slime_b":{"Hurt":[0,-6]},"slime_r":{"Hurt":[0,-6]},"skel_w":{"Hurt":[0,5]},"skel_s":{"Hurt":[0,-6],"Dead":[0,5]},"skel_a":{"Dead":[0,12]},"wolf_b":{"Hurt":[0,10],"Dead":[0,14]},"frost":{"Dead":[15,0]},"necro":{"Idle":[13,0],"Walk":[9,0],"Attack_1":[11,0],"Hurt":[13,0],"Dead":[13,0]},"td0":{"Dead":[9,0]},"td1":{"Walk":[12,0],"Attack_1":[11,0],"Dead":[3,0]},"td2":{"Attack_1":[18,0],"Dead":[9,0]},"td3":{"Attack_1":[15,0],"Dead":[5,0]},"td4":{"Attack_1":[13,0],"Dead":[4,0]},"td5":{"Dead":[9,0]},"td6":{"Dead":[14,0]},"td7":{"Attack_1":[14,0],"Dead":[4,0]},"td8":{"Dead":[9,0]},"td9":{"Attack_1":[14,0],"Dead":[4,0]},"td10":{"Attack_1":[19,0],"Dead":[14,0]}};
for(const m in ANCHORS)for(const a in ANCHORS[m]){const s=MF.mons[m]&&MF.mons[m][a];if(s){s.oy=ANCHORS[m][a][0];s.dx=ANCHORS[m][a][1]}}
