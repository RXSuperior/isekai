// =============== v11: ความสัมพันธ์แบบ Way of Xian (นิสัย หน้าตา ความไว้ใจ ความนับถือ บุญคุณ เคมี เรื่องที่ผ่านมาด้วยกัน) ===============
const TEMPERS=[
 {n:'ใจดี',d:'ใจอ่อน ช่วยคนอื่นก่อนตัวเอง ชอบคนที่ทำดี',talk:1},{n:'หยิ่ง',d:'ถือตัว นับถือคนที่เก่งกว่าเท่านั้น',talk:-1,resp:1},
 {n:'โลภ',d:'ชอบของมีค่า ของขวัญได้ผลดีเป็นพิเศษ',gift:1.5},{n:'ซื่อสัตย์',d:'รักษาคำพูด ไว้ใจคนช้าแต่ไม่เปลี่ยนใจ',trust:1},
 {n:'เจ้าเล่ห์',d:'พูดเก่ง มีเรื่องให้ช่วยบ่อย แต่ไว้ใจยาก',trust:-1},{n:'เย็นชา',d:'พูดน้อย เปิดใจยาก ดื่มด้วยกันไม่ค่อยช่วย',talk:-1,drink:.5},
 {n:'ร่าเริง',d:'คุยสนุก ดื่มด้วยกันแล้วสนิทเร็ว',talk:1,drink:2},{n:'ทะเยอทะยาน',d:'อยากก้าวหน้า ชอบประลองและคนที่มีอนาคต',spar:2},
 {n:'ขี้อาย',d:'เขินง่าย คุยนาน ๆ จะค่อยเปิดใจ',drink:.5},{n:'ใจร้อน',d:'โกรธง่ายหายเร็ว ชอบประลองฝีมือ',spar:2}];
const GOOD_PAIRS=new Set(['0-8','8-0','6-8','8-6','3-0','0-3','6-5','5-6','1-4','4-1','7-3','3-7','6-6','3-3','0-0']);
const BAD_PAIRS=new Set(['2-0','0-2','9-8','8-9','4-3','3-4','1-1','9-9','2-2']);
const LIKES=['ขนมหวาน','อาวุธชั้นดี','ตำราเก่า','ดอกไม้','ไวน์องุ่น','เครื่องประดับ','สมุนไพรหายาก','ของแปลกจากต่างแดน','เครื่องดนตรี','ผ้าไหม'];
const CHARM_N=[[30,'หน้าตาธรรมดา'],[50,'หน้าตาดี'],[70,'หน้าตาสะดุดตา'],[85,'งดงามเป็นที่เลื่องลือ'],[999,'งามล่มเมือง']];
const TALENT_N=['พรสวรรค์ต่ำ','พรสวรรค์ธรรมดา','มีแวว','พรสวรรค์สูง','อัจฉริยะ'];
const DILI_N=['ขี้เกียจ','ทำบ้างไม่ทำบ้าง','ขยันพอตัว','ขยันมาก'];
// อาชีพตามที่ที่พบ
const JOBS_AT={market:['พ่อค้าผ้า','แม่ค้าขนม','พ่อค้าเครื่องเทศ','ช่างตีเหล็ก','คนขายดอกไม้'],tavern:['นักผจญภัยพเนจร','นักดนตรีพเนจร','เจ้าของโรงเตี๊ยม','ทหารรับจ้าง','นักพนัน'],
 shrine:['นักบวชฝึกหัด','แม่ชีผู้ดูแลวิหาร','ผู้แสวงบุญ'],field:['ชาวนา','คนเลี้ยงแกะ','ลูกชาวนา'],lake:['ชาวประมง','กวีพเนจร','จิตรกร'],
 guild:['นักผจญภัย','เจ้าหน้าที่กิลด์','นักเวทรับจ้าง','นักธนูหนุ่ม'],school:['เพื่อนร่วมสถาบัน','อาจารย์ฝึกหัด','บรรณารักษ์'],city:['ทหารยาม','ลูกขุนนาง','นักเล่านิทาน','ช่างตัดเสื้อ'],
 forest:['นายพราน','คนเก็บสมุนไพร','เอลฟ์พเนจร'],train:['ครูฝึกดาบ','นักดาบฝึกหัด'],gatezone:['นักผจญภัย','พ่อค้าเร่หน้าดันเจี้ยน'],hospital:['หมอสมุนไพร','นักบวชรักษา'],casino:['นักพนัน','นายหน้าข่าว']};
const JOB_BIO={'พ่อค้า':'ขายของในตลาดมาตั้งแต่เด็ก รู้ราคาทุกอย่างในเมือง','แม่ค้า':'ตื่นตีสี่ทุกวันเพื่อนวดแป้ง ฝันอยากมีร้านเป็นของตัวเอง','ช่างตีเหล็ก':'แขนแข็งแรงกว่าใครในตลาด ดาบที่ตีส่งให้กองทัพหลวง',
 'นักผจญภัย':'รับงานจากกิลด์เลี้ยงชีพ ฝันว่าจะได้แรงก์ S สักวัน','นักดนตรี':'เดินทางไปทุกเมือง ร้องเพลงแลกข้าว','ทหาร':'เคยรบที่ชายแดน มีแผลเป็นยาวที่แขน','นักบวช':'สวดภาวนาต่อเหล่าเทพทุกเช้า เชื่อว่าเทพเฝ้ามองทุกคนอยู่',
 'แม่ชี':'ดูแลเด็กกำพร้าและคนป่วยมาค่อนชีวิต','ผู้แสวงบุญ':'เดินทางไกลมาไหว้วิหาร เพื่อขอให้ลูกที่ป่วยหาย','ชาวนา':'ไถนามาทั้งชีวิต รู้จักฝนฟ้าดีกว่าใคร','คนเลี้ยงแกะ':'ใช้ชีวิตกับฝูงแกะบนเนินเขา พูดกับแกะมากกว่าคน',
 'ชาวประมง':'ออกเรือก่อนฟ้าสาง รู้ทุกมุมของทะเลสาบ','กวี':'เขียนกลอนถึงดวงจันทร์สองดวง ไม่เคยขายได้สักบท','จิตรกร':'วาดภาพทะเลสาบซ้ำเป็นร้อยรูป ยังไม่พอใจสักรูป','เจ้าหน้าที่กิลด์':'จำหน้านักผจญภัยได้ทุกคน และรู้ว่าใครจะไม่กลับมา',
 'นักเวท':'ออกจากสถาบันเวทกลางคัน เพราะไม่มีเงินจ่ายค่าเรียน','นักธนู':'ยิงนกได้ตั้งแต่เจ็ดขวบ','เพื่อนร่วมสถาบัน':'เรียนห้องเดียวกัน ชอบแอบหลับในคาบประวัติศาสตร์','อาจารย์':'สอนอักษรรูนให้เด็กปีหนึ่ง เข้มงวดแต่ใจดี','บรรณารักษ์':'อ่านหนังสือในหอตำราครบทุกเล่มแล้ว (เขาว่าอย่างนั้น)',
 'ทหารยาม':'เฝ้าประตูเมืองมาสิบปี ไม่เคยได้เลื่อนขั้น','ลูกขุนนาง':'ใช้ชีวิตสบายจนเบื่อ แอบหนีออกมาเที่ยวตลาดบ่อย ๆ','นักเล่านิทาน':'เล่าเรื่องสงครามจอมมารครั้งก่อนเหมือนเห็นมากับตา','ช่างตัดเสื้อ':'มือไวที่สุดในเมือง ตัดชุดให้ขุนนางมาแล้วหลายตระกูล',
 'นายพราน':'ล่าสัตว์ในป่าข้างเมือง รู้ทางที่สัตว์อสูรชอบเดิน','คนเก็บสมุนไพร':'รู้จักสมุนไพรทุกต้นในป่า และรู้ว่าต้นไหนกินแล้วตาย','เอลฟ์':'มาจากป่าลึกทางตะวันตก อายุมากกว่าที่หน้าตาบอก','ครูฝึก':'เคยเป็นอัศวินของราชวัง ก่อนเข่าจะเจ็บ',
 'นักดาบ':'ซ้อมดาบทุกเช้าก่อนไก่ขัน','หมอ':'รักษาคนจนโดยไม่คิดเงิน','นักพนัน':'แพ้มากกว่าชนะ แต่เล่าแต่ตาที่ชนะ','นายหน้าข่าว':'ขายข่าวลือให้ใครก็ได้ที่จ่ายเงิน','เจ้าของโรงเตี๊ยม':'รู้เรื่องของทุกคนที่เคยมาดื่มที่ร้าน','คนขายดอกไม้':'ปลูกดอกไม้เองหลังบ้าน ส่งกลิ่นหอมไปทั้งซอย'};
const bioOf=x=>{const k=Object.keys(JOB_BIO).find(k=>(x.job||x.role||'').includes(k));return k?JOB_BIO[k]:null};
const hashId=(s,salt)=>{let h=7;for(const c of String(s)+salt)h=(h*31+c.charCodeAt(0))>>>0;return h};
function ensureNpc(x){if(x.tr!=null&&x.ch!=null)return x;const h=hashId(x.id+x.n,'npc');
 x.tr=x.tr??h%10;x.ch=x.ch??(20+hashId(x.id,'ch')%76);x.like=x.like??LIKES[hashId(x.id,'like')%LIKES.length];x.dis=x.dis??LIKES[(hashId(x.id,'dis')+3)%LIKES.length];
 x.tal=x.tal??Math.min(4,Math.floor((hashId(x.id,'tal')%100)/22));x.dili=x.dili??hashId(x.id,'dili')%4;x.trs=x.trs||0;x.rs=x.rs||0;x.fv=x.fv||0;x.ro=x.ro??(x.spark||0);
 x.met=x.met??ageY(P);x.nmet=x.nmet||1;x.hist=x.hist||[];x.job=x.job||x.role;return x}

// ---- แต่งตัวตามอาชีพ อายุ และนิสัย ให้แต่ละคนดูไม่ซ้ำกัน ----
const OC=n=>OUT_COLORS.findIndex(c=>c[0]===n);
function dressNpc(x){if(!x||!x.look||typeof x.look!=='object'||x.dressed)return;const L=x.look,j=(x.job||x.role||''),m=x.sex!=='f',h=hashId(x.id+x.n,'dress'),rr=k=>(h>>>k)%100/100;
 const set=(o)=>Object.assign(L,o),pk=(a,k)=>a[(h>>>k)%a.length];
 if(/นักบวช|แม่ชี|แสวงบุญ|หมอ/.test(j))set({outfit:4,head:rr(3)<.5?1:0,accC:pk([OC('ขาว'),OC('ครีม'),OC('ทอง')],5)});
 else if(/นักเวท|อาจารย์|บรรณารักษ์|กวี/.test(j))set({outfit:4,head:/นักเวท/.test(j)?2:rr(3)<.3?2:0,face:rr(7)<.5?3:0,accC:pk([OC('ม่วง'),OC('กรมท่า'),OC('แดงเลือดหมู'),OC('น้ำเงิน')],5)});
 else if(/ช่างตีเหล็ก|แม่ค้า|พ่อค้า|เจ้าของโรงเตี๊ยม|ช่างตัดเสื้อ|คนขายดอกไม้/.test(j))set({outfit:rr(2)<.7?3:5,head:/ดอกไม้/.test(j)&&!m?6:rr(4)<.25?3:0,face:m&&rr(6)<.45?pk([1,2],7):0,accC:pk([OC('น้ำตาล'),OC('ครีม'),OC('ขาว'),OC('ส้ม')],5)});
 else if(/ทหาร(?!รับจ้าง)|ครูฝึก|อัศวิน|หัวหน้าทีม|ทหารยาม/.test(j))set({outfit:2,face:rr(3)<.35?5:m&&rr(4)<.3?2:0,head:rr(5)<.2?3:0,accC:pk([OC('แดง'),OC('น้ำเงิน'),OC('กรมท่า')],6)});
 else if(/นักผจญภัย|นักดาบ|นักธนู|นายพราน|ทหารรับจ้าง|หน้าดันเจี้ยน|นักดนตรี/.test(j))set({outfit:pk([1,6,6,5,2,0],3),head:pk([5,3,1,0,0],6),face:rr(8)<.25?pk([5,4,1],9):0,accC:pk([OC('เขียวทหาร'),OC('น้ำตาล'),OC('แดงเลือดหมู'),OC('กรมท่า'),OC('เขียว')],10)});
 else if(/ชาวนา|เลี้ยงแกะ|ลูกชาวนา|ชาวประมง|เก็บสมุนไพร/.test(j))set({head:rr(3)<.7?5:3,outfit:rr(5)<.3?5:0,face:m&&rr(6)<.4?1:0,accC:pk([OC('ครีม'),OC('น้ำตาล'),OC('เขียวทหาร')],5)});
 else if(/ขุนนาง|เอลฟ์|เจ้าหญิง|เจ้าชาย/.test(j))set({head:4,outfit:1,accC:pk([OC('แดง'),OC('น้ำเงิน'),OC('ม่วง'),OC('ทอง')],5)});
 else if(/นักพนัน|นายหน้า|โจร|นอกกฎหมาย/.test(j))set({face:pk([4,5,2],3),head:rr(5)<.5?3:0,outfit:rr(6)<.5?5:0,accC:pk([OC('ดำ'),OC('แดงเลือดหมู'),OC('ม่วง')],7)});
 else if(/^พ่อ/.test(j))set({face:rr(3)<.5?pk([1,2],4):0});
 else if(/^แม่/.test(j))set({outfit:rr(3)<.4?3:0,accC:OC('ครีม')});
 else if(!isFamily(x)&&rr(3)<.45){const k=pk(['face','head','outfit'],4);if(k==='face')L.face=m?pk([1,2,3,5],6):pk([3,5],6);else if(k==='head')L.head=m?pk([3,5,1],6):pk([6,3,4,1],6);else L.outfit=pk([1,5,3],6);L.accC=(h>>>8)%16}
 if(!m&&(L.face===1||L.face===2))L.face=0;
 // คนแก่ผมหงอก
 if((x.age||20)>=55)set({hairC:pk([7,8,9],2),face:m&&rr(9)<.6&&!L.face?1:L.face});
 x.dressed=1}
const _en12=ensureNpc;ensureNpc=function(x){_en12(x);dressNpc(x);if(x.look&&typeof x.look==='object')x.look.small=(x.age??20)<13?1:0;return x};
// อุปนิสัยของตัวเอก (จากนิสัยที่สะสม)
function heroTemper(){const q=P.tr||{};if((q.kind||0)>30)return 0;if((q.brave||0)>40)return 7;if((q.kind||0)<-30)return 2;if((q.loyal||0)>30)return 3;if((q.dili||0)<-30)return 6;return 5}
const idealType=()=>hashId(P.name+(P.sex||''),'ideal')%10;
function chemistry(x){ensureNpc(x);let c=.8+(x.ch-50)/150;const h=heroTemper(),t=x.tr;if(GOOD_PAIRS.has(`${h}-${t}`))c+=.25;if(BAD_PAIRS.has(`${h}-${t}`))c-=.25;if(t===idealType())c+=.3;if(!!x.hunter!==(P.rank>=0))c-=.15;return clamp(c,.5,1.6)}
const chemLabel=c=>c>=1.3?'ฟ้าลิขิต':c>=1.05?'เข้ากันดี':c>=.8?'พอไปได้':'ไม่ค่อยเข้ากัน';
const charmLabel=c=>CHARM_N.find(([lim])=>c<lim)[1];
const deepTie=x=>isFamily(x)||x.rel==='spouse'||x.bond;
function trustOf(x){ensureNpc(x);return clamp(Math.round(x.aff*.5+(deepTie(x)?15:0)+(x.trs||0)),-100,100)}
const lvlOf=p=>p.rank>=0?p.rank+1:0;
function respOf(x){ensureNpc(x);const gap=clamp((lvlOf(P)-lvlOf(x))*12,-40,40),fame=Math.min(5,Math.floor(P.fame/40));return clamp(Math.round(gap+fame*6+(isFamily(x)?10:0)+(x.rs||0)+(TEMPERS[x.tr].resp&&gap<0?-10:0)),-100,100)}
const band=v=>v>=40?2:v>=10?1:v>-10?0:v>-40?-1:-2;
function standingWords(x){const c=band(x.aff),t=band(trustOf(x)),r=band(respOf(x));
 if(c>=1&&t<=-1)return 'ชอบท่าน แต่ยังไม่ไว้ใจ';if(c<=-1&&r>=1)return 'ไม่ชอบหน้าท่าน แต่ยอมรับในฝีมือ';if(r>=2&&t<=-1)return 'ยำเกรงท่าน แต่ระแวงอยู่ในใจ';if(t>=1&&r<=-1)return 'ไว้ใจท่าน แต่ไม่ได้นับถือนัก';
 if(c>=2&&t>=2&&r>=1)return 'รัก ไว้ใจ และนับถือท่านเต็มหัวใจ';if(c>=1&&t>=1)return 'เป็นมิตรและไว้ใจท่าน';if(c<=-2&&t<=-2)return 'เกลียดและไม่ไว้ใจท่านแม้แต่น้อย';if(r<=-2)return 'มองท่านเป็นคนชั้นต่ำกว่า';return 'ยังรู้จักกันไม่ลึกซึ้ง'}
const STAGE_N={none:'ยังไม่มีอะไร',crush:'แอบชอบกัน',lover:'คนรัก',fiance:'คู่หมั้น',spouse:'คู่ครอง'};
function stageOf(x){if(x.rel==='spouse'||x.rel==='fiance'||x.rel==='lover')return x.rel;return x.lit&&(x.ro||0)>=1?'crush':'none'}
const LOVE_STEPS=[{id:'crush',act:'court',t:'ชวนเดทจนเกิดประกายรัก',need:{ro:1}},{id:'lover',act:'confess',t:'สารภาพรัก',need:{ro:1,aff:20}},{id:'fiance',act:'propose',t:'ขอหมั้น',need:{ro:3,aff:40}},{id:'spouse',act:'wed',t:'แต่งงาน',need:{aff:50,gold:500}}];
function romanceWhy(x){if(isFamily(x))return 'เป็นครอบครัว';if(ageY(P)<16)return 'ท่านยังเด็กเกินไป';if((x.age??18)<16)return 'อีกฝ่ายยังเด็กเกินไป';if(P.people.some(y=>y.rel==='spouse'&&y.alive&&y!==x))return 'ท่านแต่งงานแล้ว';if(x.rel==='spouse')return null;if(x.taken&&x.rel!=='lover'&&x.rel!=='fiance')return `มีคนรักอยู่แล้ว (${x.taken})`;return null}
// ---- การกระทำ (เดือนละครั้งต่อคน) ----
const ACT_N={talk:'คุย',gift:'ให้ของขวัญ',drink:'ดื่มด้วยกัน',spar:'ประลองฝีมือ',askHelp:'ขอความช่วยเหลือ',repay:'ตอบแทนบุญคุณ',interest:'หมายตา',interestOff:'เลิกหมายตา',court:'ชวนออกเดท',confess:'สารภาพรัก',propose:'ขอหมั้น',wed:'แต่งงาน',together:'ใช้เวลาด้วยกัน',child:'ขอมีลูก',party:'ชวนเข้าทีม',breakup:'เลิกรา',attack:'ทำร้าย',makePeace:'ขอคืนดี'};
function actOptions(x){if(!P||!x||!x.alive)return [];ensureNpc(x);const me=ageY(P),done=P.acted&&P.acted[x.id]===P.m,why0=PENDING.length?'มีเรื่องรอตัดสินใจอยู่':done?'เดือนนี้พบกันแล้ว':null;
 const out=[],add=(id,show,why=null)=>{if(show)out.push({id,why:why0||why})};const fam=isFamily(x),rom=['lover','fiance','spouse'].includes(x.rel),rw=romanceWhy(x);
 add('talk',true);add('gift',me>=8,P.gold<10?'เงินไม่พอ':null);add('drink',me>=16&&(x.age??18)>=16,P.gold<10?'เงินไม่พอ':null);add('spar',me>=10&&(x.age??18)>=10);
 add('askHelp',!fam&&(x.aff>=60||x.bond),x.askAt!=null&&P.m-x.askAt<36?'เพิ่งขอไปไม่นาน':null);add('repay',(x.fv||0)<0,P.gold<(-x.fv)*5?'เงินไม่พอ':null);
 if(x.aff<-10)add('makePeace',true,P.gold<50?'เงินไม่พอ (50)':null);
 const canAsk=!fam&&!rom&&me>=16&&(x.age??18)>=16&&(!rw||x.aff>=25);
 if(canAsk&&!x.interest&&!rw)out.push({id:'interest',why:null});if(x.interest&&!rom)out.push({id:'interestOff',why:null});
 add('court',canAsk||x.rel==='lover',rw||(P.gold<20?'เงินไม่พอ (20)':null));
 add('confess',canAsk&&!rw,(x.ro||0)<1?'ยังไม่มีประกายรัก':x.aff<20?'ยังไม่สนิทพอ':null);
 add('propose',x.rel==='lover',(x.ro||0)<3?`ประกายรักยังไม่พอ (${(x.ro||0).toFixed(1)}/3)`:x.aff<40?'ยังไม่สนิทพอ (40)':null);
 add('wed',x.rel==='fiance',x.aff<50?'ยังไม่สนิทพอ (50)':P.gold<500?'เงินไม่พอ (500)':null);
 add('together',x.rel==='spouse');add('child',x.rel==='spouse'&&me<50,P.people.filter(y=>/^ลูก(ชาย|สาว)/.test(y.role)&&y.alive).length>=6?'ลูกเยอะพอแล้ว':null);
 if(P.rank>=0&&x.hunter)add('party',true,!P.party.includes(x.id)&&(x.aff<40||P.party.length>=2)?(x.aff<40?'ต้องสนิท 40 ขึ้นไป':'ทีมเต็ม'):null);
 add('breakup',rom);add('attack',!fam&&me>=12);
 return out}
function nlog(x,t,c){ensureNpc(x);x.hist.push({a:ageY(P),t});if(x.hist.length>14)x.hist.shift();log(t,c||'')}
function say2(x,l){P.talk={who:x.id,line:l,until:P.m+1}}
const TALK_LINES=[['ช่วงนี้เป็นยังไงบ้าง ทานข้าวหรือยัง','ข้าเป็นห่วงเจ้านะ'],['ข้าไม่ได้อยากคุยกับเจ้าหรอก แค่ว่างพอดี','เจ้าก็ไม่เลวนี่'],['ได้ยินว่าเจ้าได้เงินจากภารกิจเยอะเลยนี่','มีของดี ๆ มาฝากบ้างไหม'],['ข้าจำได้ทุกคำที่เจ้าพูด','สัญญาแล้วต้องทำนะ'],['ข้ามีข่าวลือเด็ด ๆ จะเล่าให้ฟัง','แต่ต้องเลี้ยงข้าวข้าก่อน'],['...','อืม'],['วันนี้อากาศดีจัง! ไปเที่ยวกันไหม','ฮ่า ๆ ๆ'],['สักวันข้าจะยิ่งใหญ่กว่าทุกคนในเมืองนี้','เจ้าจะมาเป็นพวกข้าไหม'],['อ...เอ่อ สวัสดี','(ก้มหน้าแดง)'],['เมื่อกี้ใครมองหน้าข้า!','เอาเถอะ ช่างมัน']];
function interact(id,act){const x=person(id);if(!x||!x.alive)return;ensureNpc(x);const o=actOptions(x).find(a=>a.id===act);if(!o||o.why)return;
 const T=TEMPERS[x.tr],chem=chemistry(x),odds=v=>clamp(v,.05,.95),n=x.n;P.acted=P.acted||{};if(!['interest','interestOff','party'].includes(act))P.acted[x.id]=P.m;
 if(act==='talk'){affGain(x,ri(2,4)+Math.round(P.cha/40)+(T.talk||0));x.trs+=1;x.nmet++;if(x.nmet>=3)x.knowLike=1;if(x.lit&&x.aff>=30&&!romanceWhy(x)&&x.rel!=='spouse')x.ro=Math.round(((x.ro||0)+.3*chem)*10)/10;
  nlog(x,`นั่งคุยกับ${n}อยู่นาน เรื่องเล็กเรื่องใหญ่${x.nmet===3?` และได้รู้ว่า${n}ชอบ${x.like}`:''}`);say2(x,pick(TALK_LINES[x.tr]))}
 if(act==='gift'){const cost=Math.min(80,Math.max(10,Math.round(P.gold*.03)));P.gold-=cost;const hit=x.knowLike,mult=(hit?1.6:1)*(T.gift||1);affGain(x,Math.round(ri(5,9)*mult));x.trs+=2;x.fv+=Math.round(cost/10*mult);
  nlog(x,hit?`มอบ${x.like}ให้${n} (${cost} ทอง) ของที่ชอบที่สุด ${n}ยิ้มกว้างจนตาหยี`:`มอบของขวัญให้${n} (${cost} ทอง) อีกฝ่ายรับไว้ด้วยรอยยิ้ม`,'c-good');say2(x,hit?'เจ้ารู้ได้ยังไงว่าข้าชอบอันนี้!':'ขอบใจนะ')}
 if(act==='drink'){P.gold-=10;affGain(x,Math.round(ri(3,6)*(T.drink||1)));const L=[`ชวน${n}ไปดื่มที่โรงเตี๊ยม คุยกันจนเจ้าของร้านต้องมาไล่กลับบ้าน`,`นั่งดื่มกับ${n}ใต้ต้นหลิวริมทะเลสาบ ไม่ค่อยพูดอะไร แต่ไม่มีใครอยากลุก`,`${n}ดื่มไปสามจอกก็เริ่มเล่าเรื่องสมัยเด็กที่ไม่เคยบอกใคร`];
  nlog(x,L[x.nmet%3]);if(x.lit&&!romanceWhy(x))x.ro=Math.round(((x.ro||0)+.2*chem)*10)/10;say2(x,'อีกจอก!')}
 if(act==='spar'){const win=RNG()<odds(.5+(power(P)-((x.rank+1)*70+30))/300);affGain(x,(x.aff<0?-2:2)+(win?0:1)*(T.spar?1:0)+(T.spar||0)/2|0);x.rs+=win?4:-2;if(P.rank>=0)gainExp(15+P.lvl*2);
  nlog(x,win?`ขอประลองฝีมือกับ${n} และเป็นฝ่ายชนะ`:`ประลองกับ${n}แล้วแพ้ ได้บทเรียนไปหลายอย่าง`,win?'c-good':'');if(win)addFame(1);else scratch(5);say2(x,win?'ฝีมือดีขึ้นเยอะนะ':'ยังอ่อนหัดอยู่')}
 if(act==='askHelp'){x.askAt=P.m;const lend=Math.max(30,Math.round(Math.min(400,50+x.aff*3)*(1+trustOf(x)/200)));P.gold+=lend;affGain(x,-3);x.fv-=Math.ceil(lend/5);
  nlog(x,`ไปขอให้${n}ช่วย ${n}ไม่ถามอะไรสักคำ ยื่นเงิน ${lend} ทองให้ แล้วบอกว่าไม่ต้องรีบคืน (ติดค้างบุญคุณ)`,'c-gold');say2(x,'เพื่อนกันไม่ต้องเกรงใจ')}
 if(act==='repay'){const c=(-x.fv)*5;P.gold-=c;x.fv=0;x.trs+=8;affGain(x,4);nlog(x,`นำเงิน ${c} ทองไปคืน${n} พร้อมขอบคุณที่เคยช่วย`,'c-good');say2(x,'เจ้าไม่ลืมจริง ๆ ด้วย')}
 if(act==='makePeace'){P.gold-=50;const ok=RNG()<odds(.35+P.cha/200+(T.trust===1?.1:0));if(ok){x.aff=Math.min(10,x.aff+25);x.gr=0;nlog(x,`ไปขอคืนดีกับ${n} อีกฝ่ายยอมจับมือ`,'c-good')}else{affGain(x,-3);nlog(x,`ไปขอคืนดีกับ${n} แต่ถูกปิดประตูใส่หน้า`,'c-bad')}}
 if(act==='interest'){for(const y of P.people)if(y.interest&&y!==x)delete y.interest;x.interest=1;x.lit=1;x.ro=Math.max(x.ro||0,.3);nlog(x,`เริ่มมอง${n}ด้วยสายตาที่ต่างไปจากเดิม ใจเต้นแรงทุกครั้งที่อีกฝ่ายยิ้ม`,'c-star')}
 if(act==='interestOff'){delete x.interest;nlog(x,`เลิกหมายตา${n} เก็บความรู้สึกไว้ในใจ`)}
 if(act==='court'){P.gold-=20;x.lit=1;const ok=RNG()<odds(.6+(chem-1)*.5+P.cha/400+(x.interest?.1:0));
  if(ok){x.ro=Math.round(((x.ro||0)+.8*chem)*10)/10;affGain(x,ri(2,5));nlog(x,pick([`ชวน${n}ไปเดินเล่นริมทะเลสาบและกินขนมด้วยกัน อีกฝ่ายยิ้มบ่อยกว่าทุกครั้ง`,`พา${n}ไปลอยโคมที่ท่าน้ำ ทั้งสองยืนดูโคมจนลับตา`,`ชวน${n}ไปดูละครเร่ในจัตุรัส มือของทั้งคู่บังเอิญแตะกัน`]),'c-star');say2(x,'ไปด้วยกันอีกนะ')}
  else{x.ro=Math.round(((x.ro||0)+.1)*10)/10;affGain(x,-1);nlog(x,`ชวน${n}ไปเที่ยว แต่พูดอะไรก็ผิดจังหวะไปหมด ต่างคนต่างเขินจนแยกกันกลับ`);say2(x,'...ข้าขอตัวก่อนนะ')}}
 if(act==='confess'){const yes=RNG()<odds(.05+x.aff/150+(x.ro||0)*.15+(chem-1)*.4+(x.interest?.05:0)+trustOf(x)/400);
  if(yes){x.rel='lover';affGain(x,15);x.trs+=5;nlog(x,`รวบรวมความกล้าสารภาพรักกับ${n} อีกฝ่ายนิ่งไปครู่หนึ่ง แล้วยิ้มตอบรับ นับแต่วันนี้ทั้งสองเป็นคนรักกัน`,'c-gold');say2(x,'ข้ารอคำนี้มานานแล้ว')}
  else{x.aff-=8;x.ro=Math.max(0,(x.ro||0)-.5);nlog(x,`สารภาพรักกับ${n} แต่อีกฝ่ายส่ายหน้าเบา ๆ ขอให้เป็นคนรู้จักกันต่อไป`,'c-bad');say2(x,'ขอโทษนะ')}}
 if(act==='propose'){const yes=RNG()<odds(.25+x.aff/150+(x.ro||0)*.1+trustOf(x)/300);if(yes){x.rel='fiance';affGain(x,10);nlog(x,`คุกเข่าขอ${n}หมั้น อีกฝ่ายน้ำตาคลอแล้วพยักหน้า`,'c-gold');say2(x,'ใช่ ข้าตกลง')}else{x.aff-=5;nlog(x,`ขอ${n}หมั้น แต่อีกฝ่ายขอเวลาคิดอีกสักพัก`);say2(x,'ขอเวลาอีกนิด')}}
 if(act==='wed')schedule('wedding',0,{id:x.id});
 if(act==='together'){affGain(x,3);heal(.15);nlog(x,pick([`ใช้เวลาทั้งวันกับ${n} ทำอาหารด้วยกันแล้วนั่งดูพระอาทิตย์ตก`,`พา${n}กลับไปเดินที่ที่เคยเดทกันครั้งแรก`,`นั่งฟัง${n}เล่าเรื่องวันนี้จนหลับไปทั้งคู่`]),'c-good');say2(x,'อยู่ด้วยกันอย่างนี้ทุกวันก็ดี')}
 if(act==='child'){x.wantChild=P.m+12;nlog(x,`คุยกับ${n}เรื่องอยากมีลูก ทั้งสองตกลงกันแล้ว (โอกาสมีลูกปีนี้สูงขึ้นมาก)`,'c-star')}
 if(act==='party'){toggleParty(x.id)}
 if(act==='breakup'){const was=x.rel;x.rel=null;x.lit=0;x.ro=0;x.aff=Math.min(x.aff,-20);x.gr=(x.gr||0)+1;nlog(x,was==='spouse'?`หย่าขาดกับ${n} บ้านเงียบลงทันที`:`บอกเลิก${n} อีกฝ่ายร้องไห้ไม่หยุด`,'c-bad')}
 if(act==='attack'){const win=RNG()<odds(.5+(power(P)-((x.rank+1)*70+30))/250);x.aff=-80;x.gr=2;P.karma-=8;if(win){nlog(x,`ลงมือทำร้าย${n}จนบาดเจ็บสาหัส`,'c-bad');addFavor('evil',4)}else{nlog(x,`ลงมือทำร้าย${n} แต่ถูกสวนกลับจนเจ็บหนัก`,'c-bad');hurt(30,`ถูก${n}สวนกลับ`)}}
 x.ro=Math.round((x.ro||0)*10)/10;x.spark=Math.floor(x.ro||0)}
// งานแต่ง: ใช้ของเดิมแต่ให้ทั้งสองแบบ
// ---- พบคนใหม่ตามที่ที่อยู่ (แบบ MEETINGS ของ WoX) ----
const MEET_LINES=['ได้รู้จักกับ{n} {j} ที่{s}','บังเอิญชนกับ{n} {j} ที่{s} ของในมือหล่นกระจาย ทั้งคู่ช่วยกันเก็บ','{n} {j} ทักท่านก่อนที่{s} คุยกันถูกคอ','ช่วย{n} {j} ยกของที่{s} เลยได้รู้จักกัน'];
function spotName(s){return (typeof SPOT_N!=='undefined'&&SPOT_N[s])||(PLACES.find(p=>p.id===s)||{}).n||'ในเมือง'}
function meetSomeone(){const s=P.spot||P.place||'city';const jobs=JOBS_AT[s]||JOBS_AT.city;const job=pick(jobs);const sex=RNG()<.5?'m':'f';
 const x=mkPerson(job,sex,{aff:ri(4,14),hunter:/นักผจญภัย|นักเวท|นักธนู|ทหาร|นักดาบ|ครูฝึก|นายพราน/.test(job),rank:-1});if(x.hunter)x.rank=clamp(Math.max(0,P.rank)+ri(-1,1),0,5);
 x.fam=0;x.age=clamp(ageY(P)+ri(-6,12),14,80);x.home=s;x.job=job;ensureNpc(x);
 // บางคนรู้จักคนที่ท่านรู้จักอยู่แล้ว
 const k=P.people.find(y=>y!==x&&y.alive&&y.home===s&&!isFamily(y));if(k&&RNG()<.4){const tie=pick(['friend','friend','rival','lover']);if(tie!=='lover'||k.sex!==x.sex){(x.ties=x.ties||[]).push([k.id,tie]);(k.ties=k.ties||[]).push([x.id,tie]);if(tie==='lover'&&!k.rel){x.taken=k.n;k.taken=x.n}}}
 nlog(x,pick(MEET_LINES).replace('{n}',x.n).replace('{j}',job).replace('{s}',spotName(s)));
 // คนแปลกหน้าที่ไม่ได้สนิทกันหายไปจากความทรงจำบ้าง
 const extra=P.people.filter(y=>y.alive&&!isFamily(y)&&!y.rel&&!y.bond&&y.aff<15&&y.home&&y!==x&&!P.party.includes(y.id));if(P.people.filter(y=>y.alive&&!isFamily(y)).length>26&&extra.length){const r=extra.sort((a,b)=>a.aff-b.aff)[0];P.people.splice(P.people.indexOf(r),1)}}
// ---- เรื่องเดือดร้อนของคนที่รู้จัก (มาขอให้ช่วย) ----
const TROUBLES=[
 {j:/พ่อค้า|แม่ค้า|ช่าง|คนขาย/,t:(x)=>`${x.n}ถูกพวกนักเลงในตลาดรีดไถทุกเดือน วันนี้มันขู่จะเผาแผงทิ้ง`,o:x=>[{t:'ไปจัดการพวกนักเลง',fight:{diff:GATE_DIFF[Math.max(0,P.rank)]*.5,foe:'thug',world:'city',safe:1}},{t:'จ่ายค่าคุ้มครองแทน',cost:{gold:150}}]},
 {j:/นักผจญภัย|นักเวท|นักธนู|ทหาร|นักดาบ/,t:x=>`${x.n}ติดอยู่ในดันเจี้ยนชั้นล่างกับเพื่อนอีกสองคน ข่าวมาถึงกิลด์ตอนเที่ยงคืน`,o:x=>[{t:'ลงไปช่วยทันที',fight:{diff:GATE_DIFF[Math.max(0,P.rank)]*.85,world:'w_ruin',cause:`ตายระหว่างช่วย${x.n}ในดันเจี้ยน`}},{t:'จ้างทีมกู้ภัยของกิลด์',cost:{gold:400}}]},
 {j:/ชาวนา|เลี้ยงแกะ|ลูกชาวนา/,t:x=>`หมูป่าอสูรบุกไร่ของ${x.n}ทุกคืน ข้าวทั้งปีกำลังจะหมด`,o:x=>[{t:'ซุ่มล่าหมูป่าตอนกลางคืน',fight:{diff:GATE_DIFF[Math.max(0,P.rank)]*.5,mon:'wolf_b',world:'train',safe:1}},{t:'ช่วยล้อมรั้วใหม่',chk:['str','mid']}]},
 {j:/นักบวช|แม่ชี|แสวงบุญ|หมอ/,t:x=>`เด็กในความดูแลของ${x.n}ป่วยด้วยไข้ประหลาด ต้องใช้สมุนไพรจากป่าลึก`,o:x=>[{t:'เข้าป่าไปหาสมุนไพร',chk:['int','mid']},{t:'ซื้อยาจากพ่อค้า',cost:{gold:200}}]},
 {j:/./,t:x=>`${x.n}ต้องย้ายของทั้งบ้านไปฝั่งเมืองเก่าภายในวันเดียว แต่ไม่มีใครมาช่วยเลย`,o:x=>[{t:'ไปช่วยยกของทั้งวัน',chk:['str','easy']},{t:'จ้างเกวียนให้',cost:{gold:40}}]}];
QUESTS.npcTrouble=(d)=>{const x=person(d.id);if(!x||!x.alive)return;ensureNpc(x);const T=TROUBLES.find(t=>t.j.test(x.job||x.role));
 const good=()=>{x.trs+=15;affGain(x,10);x.fv+=20;x.hist.push({a:ageY(P),t:'ท่านช่วย'+x.n+'ยามลำบาก'})};
 ask({title:`${x.n}มาขอให้ช่วย`,rare:1,chain:'เรื่องของผู้คน',who:x.id,sc:x.home||'city',text:T.t(x),opts:[...T.o(x).map(o=>({...o,ok:{r:`${x.n}ขอบคุณไม่หยุด สายตาที่มองท่านเปลี่ยนไป`,c:'c-good',d:{karma:3},line:'บุญคุณครั้งนี้ข้าจะไม่ลืม',then:good},no:{r:'ช่วยได้ไม่เต็มที่ แต่เขาก็ซึ้งใจที่ท่านลองช่วย',then:()=>{x.trs+=5;affGain(x,3)}}})),
  {t:'ปฏิเสธ',ok:{r:`${x.n}เดินจากไปเงียบ ๆ`,line:'...ข้าเข้าใจ',then:()=>{x.trs-=10;x.aff-=6}}}]})};
// ทุกเรื่องที่มีคนเกี่ยวข้อง บันทึกไว้เป็นเรื่องที่ผ่านมาด้วยกัน
const _ans12=answer;answer=function(i){const ev=PENDING[0];const who=ev&&ev.who&&person(ev.who);const o=ev&&ev.opts&&ev.opts[i];_ans12(i);if(who&&o&&P){ensureNpc(who);who.hist.push({a:ageY(P),t:`${ev.title}: ${o.t}`});if(who.hist.length>14)who.hist.shift()}};
// ---- รายเดือน ----
const _tick12=tick;tick=function(){const was=P&&P.m;_tick12();if(!P||!P.alive||P.m===was)return;
 P.people.forEach(x=>{if(x.alive)ensureNpc(x)});
 // พบคนใหม่ตามที่ที่อยู่
 const soc=P.path==='social'||P.path==='guild'?2:1;if(ageY(P)>=6&&!PENDING.length&&RNG()<.05*soc)meetSomeone();
 // คนรู้จักขอความช่วยเหลือ
 if(mon(P)===4&&RNG()<.18&&!(P.flags.troubleCd>P.m)){P.flags.troubleCd=P.m+24;const c=P.people.filter(x=>x.alive&&!isFamily(x)&&x.aff>=15&&x.age>=14);if(c.length&&!P.q.some(q=>q.k==='npcTrouble'))schedule('npcTrouble',ri(0,5),{id:pick(c).id})}
 // ไม่ได้พบกันนาน ความสนิทค่อย ๆ จางลง / บุญคุณที่ติดค้างทำให้ความไว้ใจลด
 if(mon(P)===0)P.people.forEach(x=>{if(!x.alive||isFamily(x)||x.rel==='spouse')return;const last=P.acted&&P.acted[x.id];if(x.aff>30&&(last==null||P.m-last>24))x.aff-=2;if((x.fv||0)<0&&x.askAt!=null&&P.m-x.askAt>36){x.trs-=4;if(P.m-x.askAt>60&&!x.gr){x.gr=1;log(`${x.n}เริ่มผูกใจเจ็บที่ท่านยังไม่คืนบุญคุณ`,'c-bad')}}});
 // อยากมีลูก: เพิ่มโอกาส
 const sp=P.people.find(y=>y.rel==='spouse'&&y.alive);if(sp&&sp.wantChild>P.m&&mon(P)===9&&RNG()<.5){const c=mkPerson(RNG()<.5?'ลูกชาย':'ลูกสาว','m',{aff:85});c.sex=c.role==='ลูกชาย'?'m':'f';c.look=randomLook(c.sex);c.age=0;c.home='home';sp.wantChild=0;P.homeMark={k:'baby',until:P.m+3};nlog(sp,`${sp.n}ให้กำเนิด${c.role} ชื่อ${c.n}`,'c-gold')}};
// คนเดิมที่มีอยู่แล้วได้บ้านตามบทบาท
const _mk12=mkPerson;mkPerson=function(role,sex,extra={}){const x=_mk12(role,sex,extra);let tries=0;while(P&&(x.n===P.name||P.people.some(y=>y!==x&&y.n===x.n))&&tries++<20)x.n=pick(x.sex==='f'?NAMES_F:NAMES_M);if(!x.home){x.home=isFamily(x)?'home':/กิลด์|นักผจญภัย|ฮันเตอร์|หัวหน้าทีม/.test(role)?'guild':/เพื่อน|อาจารย์|ครู/.test(role)?'school':pick(['market','tavern','city','lake','shrine'])}return x};

const _rl12=relLabel;relLabel=function(x){if(isFamily(x)&&!x.rel)return x.aff>=60?'ครอบครัวที่รักกัน':x.aff>=0?'ครอบครัว':'ครอบครัวที่บาดหมาง';return _rl12(x)};
