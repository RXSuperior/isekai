// =============== การสร้างชีวิต (แบบ Way of Xian) ===============
const FAMILIES=[
 {id:'orphan',n:'เด็กกำพร้า',c:0,d:'โตมาในบ้านเด็กกำพร้าข้างเขตกั้นเกต ไม่มีใครค้ำ แต่ก็ไม่มีใครบังคับ',gold:0,st:{vit:3},tr:{brave:10},roles:['แม่ชีบ้านเด็ก','ผอ.บ้านเด็ก','น้องในบ้านเด็ก']},
 {id:'poor',n:'ครอบครัวยากจน',c:1,d:'ห้องเช่าเล็ก ๆ หลังตลาด พ่อแม่ทำงานสองกะ ค่าเทอมคือเรื่องที่บ้านคุยกันทุกเดือน',gold:40,st:{vit:2,str:1}},
 {id:'slum',n:'ชุมชนริมเขตเกต',c:1,d:'บ้านอยู่ติดรั้วกั้นเกตเก่า ได้ยินเสียงไซเรนจนชิน วิ่งหนีเป็นตั้งแต่เด็ก',gold:30,st:{agi:3,luk:2}},
 {id:'middle',n:'ครอบครัวชนชั้นกลาง',c:2,d:'บ้านทาวน์เฮาส์ พ่อเป็นพนักงานบริษัท แม่เปิดร้านซักรีด หวังให้ลูกสอบติดมหาวิทยาลัยดี ๆ',gold:200,st:{int:2,cha:1}},
 {id:'mafia',n:'ครอบครัวมาเฟีย',c:2,d:'พ่อคุมบ่อนใต้ดินสองแห่ง ลูกน้องเรียกท่านว่า "คุณหนู" เงินไม่เคยขาดแต่ชื่อเสียงไม่เคยดี',gold:500,st:{str:3},karma:-5},
 {id:'merchant',n:'ครอบครัวพ่อค้า',c:3,d:'ร้านขายอุปกรณ์ฮันเตอร์สามสาขา โตมากับบัญชีและการต่อรองราคา',gold:800,st:{cha:3,int:1}},
 {id:'hunter',n:'ครอบครัวฮันเตอร์เกษียณ',c:3,d:'พ่อเคยเป็นฮันเตอร์แรงก์ C ที่เลิกลงเกตหลังเสียเพื่อนร่วมทีม บ้านมีลานฝึกเล็ก ๆ หลังบ้าน',gold:300,st:{str:2,vit:2}},
 {id:'research',n:'ครอบครัวนักวิจัยเกต',c:3,d:'แม่เป็นนักวิจัยแกนอสูรของรัฐ ห้องนั่งเล่นเต็มไปด้วยเอกสารลับที่ห้ามแตะ',gold:400,st:{int:5},flag:'lore'},
 {id:'chaebol',n:'ตระกูลแชโบล',c:5,d:'ตระกูลเจ้าของบริษัทพลังงานมานาที่ใหญ่ที่สุดในประเทศ ทุกคนจับตาว่าทายาทคนนี้จะตื่นพลังหรือไม่',gold:3000,st:{cha:5,int:2}},
 {id:'guildheir',n:'ทายาทกิลด์ใหญ่',c:5,d:'ปู่ก่อตั้งกิลด์ใหญ่อันดับต้นของประเทศ เกิดมาพร้อมความคาดหวังที่หนักกว่าทอง',gold:1500,st:{str:2,cha:3},fame:10,flag:'heir'}];
const MANA=[{n:'ไม่มีแวว',c:0,v:5,d:'เครื่องวัดที่โรงเรียนไม่เคยกระดิก'},{n:'มานาอ่อน',c:1,v:15,d:'รู้สึกถึงเกตได้จาง ๆ'},{n:'มานาปานกลาง',c:2,v:25,d:'มีแววตื่นพลังแรงก์ต่ำถึงกลาง'},
 {n:'มานาสูง',c:4,v:40,d:'ครูแนะแนวเคยเรียกไปคุยเรื่องอนาคต'},{n:'มานาสูงมาก',c:6,v:55,d:'เครื่องวัดที่โรงเรียนกะพริบทุกครั้งที่เดินผ่าน'},
 {n:'มานาล้นเกินมนุษย์',c:8,v:70,d:'สัตว์เลี้ยงในบ้านกลัวท่านโดยไม่มีเหตุผล'},{n:'มานาผิดปกติ',c:10,v:85,d:'เครื่องวัดระเบิด มีเสียงแปลก ๆ ในหัวที่เรียกตัวเองว่า "ระบบ"',sys:1}];
const BODY=[{n:'ร่างกายสามัญ',c:0,st:{},d:'ไม่มีอะไรพิเศษ'},{n:'ร่างกายแข็งแรง',c:2,st:{str:4,vit:4},d:'ไม่ค่อยป่วย ยกของหนักได้'},
 {n:'ร่างนักกีฬา',c:4,st:{str:6,agi:6,vit:6},d:'วิ่งเร็วที่สุดในโรงเรียนตั้งแต่ ม.1'},{n:'ร่างอสูร',c:7,st:{str:12,vit:12},d:'กระดูกหนากว่าคนทั่วไปครึ่งหนึ่ง หมอบอกว่าไม่เคยเห็นมาก่อน',grow:.2},
 {n:'ร่างไร้ขีดจำกัด',c:10,st:{str:12,agi:12,vit:12},d:'ฝึกเท่าไรก็ไม่ถึงเพดาน',grow:.4}];
const DESTINY=[{n:'ดาวผ่านฟ้า',c:0,d:'ชีวิตธรรมดาที่ไม่มีดวงดาวดวงไหนจับจ้อง'},
 {n:'ดาวค้ำชะตา',c:2,d:'ชะตาให้เป็นผู้ค้ำจุนคนรอบตัว เพื่อนและครอบครัวสนิทกับท่านง่ายกว่าปกติ',k:'support'},
 {n:'ดาวร่วง',c:3,d:'ช่วงแรกของชีวิตจะลำบาก แต่โอกาสตื่นพลังครั้งที่สองสูงกว่าคนอื่นสามเท่า',k:'fall'},
 {n:'ดาวทมิฬ',c:5,d:'อสรพิษแห่งเหวลึกจับตาท่านตั้งแต่เกิด เส้นทางมืดเปิดรออยู่เสมอ',k:'dark'},
 {n:'ดาวคู่ชะตา',c:7,d:'มีคนหนึ่งที่ชะตาผูกไว้กับท่าน จะเป็นคู่แข่งหรือคนรักก็ขึ้นกับท่าน',k:'pair'},
 {n:'ดาวนำชะตา',c:10,d:'ตัวเอกของเรื่องเล่า กลุ่มดาวทุกดวงสนใจท่านตั้งแต่ก่อนตื่นพลัง',k:'lead'}];
const TALENTS=[
 {id:'beauty',n:'งามล่มเมือง',ic:'🌸',c:3,d:'เสน่ห์ +15 และโตเร็วขึ้น 30%',st:{cha:15},g:{cha:.3}},
 {id:'smart',n:'หัวไว',ic:'🧠',c:3,d:'ปัญญา +10 และโตเร็วขึ้น 30%',st:{int:10},g:{int:.3}},
 {id:'tough',n:'ร่างแกร่ง',ic:'💪',c:2,d:'ความอึด +10 พลังชีวิตสูงสุด +15%',st:{vit:10},m:{hp:.15}},
 {id:'swift',n:'เท้าไว',ic:'💨',c:2,d:'ความเร็ว +10',st:{agi:10}},
 {id:'iron',n:'แขนเหล็ก',ic:'🦾',c:2,d:'กาย +10',st:{str:10}},
 {id:'lucky',n:'ดวงดี',ic:'🍀',c:3,d:'โชค +15',st:{luk:15}},
 {id:'money',n:'ทองไหลมา',ic:'🪙',c:2,d:'เงินที่ได้ +50%',m:{gold:.5}},
 {id:'star',n:'ดาวรุ่งพุ่งแรง',ic:'✨',c:2,d:'ชื่อเสียงที่ได้ +50%',m:{fame:.5}},
 {id:'long',n:'อายุยืน',ic:'🐢',c:3,d:'อายุขัย +10 ปี',life:10},
 {id:'learner',n:'เรียนรู้ไว',ic:'📘',c:4,d:'EXP ที่ได้ +25%',m:{exp:.25}},
 {id:'regen',n:'ฟื้นตัวไว',ic:'💚',c:2,d:'ฟื้นพลังชีวิตเร็วขึ้น 50%',m:{heal:.5}},
 {id:'diligent',n:'ขยันโดยกำเนิด',ic:'⏰',c:1,d:'เริ่มต้นนิสัยขยัน',tr:{dili:40}},
 {id:'brave',n:'ใจสิงห์',ic:'🦁',c:1,d:'เริ่มต้นนิสัยกล้าหาญ',tr:{brave:40}},
 {id:'manasense',n:'สัมผัสมานา',ic:'🔮',c:4,d:'มานาแฝง +15',mana:15},
 {id:'starlove',n:'ที่รักของดวงดาว',ic:'🌌',c:3,d:'กลุ่มดาวทุกดวงชอบท่านเพิ่ม 10 ตั้งแต่ตื่นพลัง',fav:10},
 {id:'memory',n:'ความจำภาพถ่าย',ic:'📷',c:2,d:'ปัญญา +5 และโอกาสสำเร็จเมื่อใช้ปัญญา +10%',st:{int:5},chk:{int:.1}},
 {id:'charm',n:'ปากหวาน',ic:'💬',c:2,d:'โอกาสสำเร็จเมื่อใช้เสน่ห์ +10%',chk:{cha:.1}},
 {id:'survivor',n:'ผู้รอดชีวิต',ic:'🛡️',c:3,d:'เริ่มต้นมีตราสัญญาชีวิต 1 อัน',mark:1},
 {id:'weak',n:'ร่างอ่อนแอ',ic:'🤒',c:-2,bad:1,d:'ความอึด -8',st:{vit:-8}},
 {id:'clumsy',n:'ซุ่มซ่าม',ic:'🍌',c:-2,bad:1,d:'ความเร็ว -8',st:{agi:-8}},
 {id:'unlucky',n:'ดวงซวย',ic:'🐈‍⬛',c:-3,bad:1,d:'โชค -12',st:{luk:-12}},
 {id:'spender',n:'มือเติบ',ic:'💸',c:-2,bad:1,d:'เงินที่ได้ -30%',m:{gold:-.3}},
 {id:'short',n:'อายุสั้น',ic:'🥀',c:-3,bad:1,d:'อายุขัย -10 ปี',life:-10},
 {id:'coward',n:'ขี้ขลาด',ic:'🐭',c:-1,bad:1,d:'เริ่มต้นนิสัยขี้ขลาด',tr:{brave:-40}},
 {id:'lazy',n:'ขี้เกียจ',ic:'😪',c:-1,bad:1,d:'เริ่มต้นนิสัยขี้เกียจ',tr:{dili:-40}}];
const BUDGET=15,TBUDGET=10;
function randomCfg(sex,keepLook){
 const r=n=>Math.floor(Math.random()*n);sex=sex||(Math.random()<.5?'m':'f');
 let pts=BUDGET;const pickC=arr=>{const ok=arr.map((x,i)=>i).filter(i=>arr[i].c<=pts);const i=ok[r(ok.length)];pts-=arr[i].c;return i};
 const order=[['body',BODY],['family',FAMILIES],['mana',MANA],['destiny',DESTINY]].sort(()=>Math.random()-.5);const cfg={sex,look:keepLook||randomLook(sex),talents:[]};
 order.forEach(([k,arr])=>cfg[k]=pickC(arr));
 const deck=TALENTS.slice().sort(()=>Math.random()-.5).slice(0,9);let tp=TBUDGET;deck.forEach(t=>{if(cfg.talents.length<3&&Math.random()<.45&&t.c<=tp){cfg.talents.push(t.id);tp-=t.c}});
 return cfg;
}
function cfgCost(cfg){return FAMILIES[cfg.family].c+MANA[cfg.mana].c+BODY[cfg.body].c+DESTINY[cfg.destiny].c}
function talentCost(ids){return ids.reduce((s,id)=>s+TALENTS.find(t=>t.id===id).c,0)}
// ---- สร้างชีวิตจากค่าที่เลือก ----
newLife=function(cfg){
 const fam=FAMILIES[cfg.family],mana=MANA[cfg.mana],body=BODY[cfg.body],des=DESTINY[cfg.destiny];
 const p={name:cfg.name||pick(cfg.sex==='f'?NAMES_F:NAMES_M),sex:cfg.sex,look:cfg.look,m:15*12,life:ri(72,90),stage:'school',path:null,rank:-1,cls:null,lvl:1,exp:0,
  str:ri(14,24),agi:ri(14,24),int:ri(14,24),vit:ri(14,24),cha:ri(14,24),luk:ri(10,28),mana:mana.v,
  gold:fam.gold,fame:fam.fame||0,karma:fam.karma||0,coin:0,favor:{},sponsor:null,mark:0,wep:-1,arm:-1,titles:[],tr:{brave:0,kind:0,dili:0,loyal:0},
  floor:0,best:0,guild:null,alive:true,log:[],year:{acts:{},d:{}},q:[],flags:{},people:[],party:[],place:'home',
  sys:!!mana.sys,gates:[],gateDone:false,towerDone:false,scen:null,talk:null,cool:0,
  family:fam.n,famId:fam.id,manaN:mana.n,bodyN:body.n,destiny:des.k||null,destinyN:des.n,talents:cfg.talents.slice(),mul:{gold:0,fame:0,exp:0,heal:0,hp:0},gmul:{},chk:{}};
 STARS.forEach(s=>p.favor[s.id]=0);
 const add=st=>{for(const k in st||{})p[k]+=st[k]};add(fam.st);add(body.st);if(body.grow)['str','agi','vit'].forEach(k=>p.gmul[k]=(p.gmul[k]||0)+body.grow);
 if(fam.tr)for(const k in fam.tr)p.tr[k]+=fam.tr[k];if(fam.flag)p.flags[fam.flag]=1;
 p.talents.forEach(id=>{const t=TALENTS.find(x=>x.id===id);add(t.st);for(const k in t.m||{})p.mul[k]+=t.m[k];for(const k in t.g||{})p.gmul[k]=(p.gmul[k]||0)+t.g[k];
  for(const k in t.tr||{})p.tr[k]=clamp(p.tr[k]+t.tr[k],-100,100);for(const k in t.chk||{})p.chk[k]=(p.chk[k]||0)+t.chk[k];if(t.life)p.life+=t.life;if(t.mana)p.mana+=t.mana;if(t.mark)p.mark+=t.mark});
 STATS.forEach(k=>p[k]=Math.max(1,p[k]));
 if(des.k==='dark')p.favor.serpent=30;if(des.k==='lead')STARS.forEach(s=>p.favor[s.id]+=15);if(des.k==='fall'){p.luk=Math.max(1,p.luk-6)}
 const L=Math.min(META.legacy,30);for(let i=0;i<L;i++)p[pick(STATS)]++;
 P=p;p.hp=maxHp(p);
 const roles=fam.roles||['แม่','พ่อ',null];
 mkPerson(roles[0],'f',{aff:ri(60,85)});mkPerson(roles[1],'m',{aff:ri(50,85),hunter:fam.id==='hunter'});
 const sr=roles[2]||(RNG()<.5?'น้องสาว':'น้องชาย');const s=mkPerson(sr,sr==='น้องสาว'?'f':sr==='น้องชาย'?'m':(RNG()<.5?'f':'m'),{aff:ri(50,80)});
 const b=mkPerson('เพื่อนสนิท',RNG()<.5?'f':'m',{aff:ri(55,75)});p.flags.bf=b.id;
 if(des.k==='support')P.people.forEach(x=>x.aff=Math.min(100,x.aff+15));
 if(des.k==='pair'){const r=mkPerson('คู่ชะตา',p.sex==='f'?'m':'f',{aff:0});p.flags.rival=r.id;schedule('rival1',ri(14,24))}
 log(`${p.name} อายุ 15 ปี นักเรียน ม.4 โรงเรียนมัธยมฮันนัม เกิดใน${fam.n}`,'','home');
 log(`พื้นเพ: ${fam.d}`,'mut');
 if(p.talents.length)log(`พรสวรรค์: ${p.talents.map(id=>TALENTS.find(t=>t.id===id).n).join(', ')}`,'c-gold');
 log(`ดวงชะตา: ${des.n}${des.k?' · '+des.d:''}`,'c-star');
 if(p.sys)log('[ระบบ] ...สัญญาณอ่อน...กำลังรอผู้เล่นตื่นพลัง','c-sys');
 if(L)log(`ความทรงจำจากชีวิตก่อนไหลกลับมา ค่าพลังรวม +${L}`,'c-star');
 schedule('pathSchool',0);
 return p;
};
