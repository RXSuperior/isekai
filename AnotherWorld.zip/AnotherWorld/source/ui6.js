// ---- v6: แท็บอาชีพ + เรื่องหลัก ----
function capLine(){const b=BODY_CAP[bodyIdx(P)];return `มานา <b>${Math.floor(P.mana)}</b> → เพดานแรงก์ <b>${P.sys?'ไร้เพดาน [ระบบ]':RANKS[rankCap(P)]}</b> · เพดานค่าพลังตอนนี้ <b>${statCap(P)>=9999?'ไม่มี':statCap(P)}</b>${b?` (ร่างกาย +${b>=999?'∞':b})`:''}`}
views.job=()=>{const cur=P.job||P.cls,j=JOBS[cur]||JOBS.sword;
 const nj=nextJobs(P).map(([id,x])=>{if(x.secret&&!P.sys)return `<div class="card"><b>??? อาชีพลับ</b><div class="mut" style="font-size:13px">ต้องมีบางสิ่งที่คนทั่วไปไม่มีวันได้</div></div>`;
  const rl=reqList(x.req),ok=reqOk(id),cd=P.flags['tcd_'+id]>P.m,after=Object.entries(JOBS).filter(([k,y])=>Array.isArray(y.from)&&y.from.includes(id)).map(([k,y])=>y.secret&&!P.sys?'???':y.n);
  return `<div class="card"><div class="row"><b>${x.n}</b><span class="chip r${Math.min(4,x.t)}">${TIER_N[x.t]}</span><span class="sp"></span><button class="btn sm pri" data-trial="${id}" ${ok&&!PENDING.length?'':'disabled'}>${cd?'รอ '+(P.flags['tcd_'+id]-P.m)+' เดือน':'ท้าด่านเลื่อนขั้น'}</button></div>
   <div class="mut" style="font-size:13px">${x.d}${after.length?` · ต่อไป: ${after.join(', ')}`:''}</div>
   <div style="font-size:13px;margin-top:4px">${rl.map(r=>`<span class="${r.ok?'c-good':'c-bad'}">${r.ok?'✓':'✗'} ${r.lab} ${r.cur}/${r.need}</span>${r.hint&&!r.ok?` <span class="mut">(${r.hint})</span>`:''}`).join(' · ')}</div></div>`}).join('');
 return `<div class="card"><div class="row"><b>${j.n}</b><span class="chip r${Math.min(4,j.t)}">${TIER_N[j.t]}</span><span class="sp"></span><span class="mut">พลังอาชีพ ×${jobMul(cur)}</span></div><div class="mut" style="font-size:13px">${j.d}</div></div>
  <div class="card sysbox" style="font-size:13px">${capLine()}<br><span class="mut">มานาเพิ่มทุก 5 เลเวล และจากวิถีนักวิจัยเกต · เลื่อนแรงก์ = เพดานค่าพลังสูงขึ้น = เข้าด่านอาชีพที่สูงขึ้นได้</span></div>
  ${(P.shadows||[]).length?`<h3>ทหารเงา ${P.shadows.length} ตน · พลังรวม +${shadowPow(P)}</h3><div style="font-size:13px">${P.shadows.map(s=>`<span class="chip">${esc(s.n)}</span>`).join(' ')}</div>`:''}
  <h3>เส้นทางเลื่อนขั้น</h3>${nj||'<p class="mut">ท่านอยู่บนจุดสูงสุดของสายนี้แล้ว</p>'}`};
function storyBox(){if(!P.flags.momSleep&&!P.flags.momDone)return '';const m=momP();
 if(P.flags.momDone)return `<div class="card"><b>📜 นิทราอนันต์</b> · ${m?.alive?'<span class="c-good">แม่ตื่นแล้ว</span>':'<span class="c-bad">แม่จากไปแล้ว</span>'}</div>`;
 const e=elixParts(),left=Math.max(0,Math.ceil((P.flags.momDue-P.m)/12));
 return `<div class="card"><b>📜 นิทราอนันต์</b> · ${esc(m?.n||'')}ยังหลับอยู่ · ค่ารักษาเดือนละ ${billOf()} ทอง${P.flags.debt?` · <span class="c-bad">ค้างจ่าย ${P.flags.debt} เดือน</span>`:''} · ร่างกายแม่จะทนได้อีกราว <b class="${left<4?'c-bad':''}">${left} ปี</b>
  ${P.flags.elixQ?`<div style="font-size:13px;margin-top:4px">น้ำมนต์แห่งชีวิต: <span class="${e.boss?'c-good':'c-bad'}">${e.boss?'✓':'✗'} หัวใจราชาอสูร (ชนะบอสเกตแรงก์ C ขึ้นไป หรือศึกเกาะทะเลดำ)</span> · <span class="${e.tower?'c-good':'c-bad'}">${e.tower?'✓':'✗'} ผลึกหอคอยชั้น 30 (${P.best}/30)</span> · <span class="${e.root?'c-good':'c-bad'}">${e.root?'✓':'✗'} รากต้นไม้โลก (มีเงิน 4,000 ทองขึ้นไปแล้วตลาดประมูลจะเปิด ราคา 5,000)</span></div>`:''}</div>`}
const _lifeV6=views.life;views.life=()=>storyBox()+`<div class="card sysbox" style="font-size:13px">${capLine()}</div>`+_lifeV6();
const _render6=render;render=function(){_render6();document.querySelectorAll('[data-trial]').forEach(b=>b.onclick=()=>{QUESTS.jobTrial({id:b.dataset.trial});save();render()})};
