// =============== การต่อสู้แบบผลัดกันโจมตี (ผลแพ้ชนะคำนวณไว้แล้วใน fight() ตรงนี้แสดงการต่อสู้ทีละจังหวะ) ===============
const EX=16,INTRO=10,OUTRO=22; // เฟรมต่อการโจมตีหนึ่งครั้ง (10 เฟรม = 1 วินาที)
function planBattle(B){const r=clamp(B.ratio||1,.3,3),close=1-Math.min(1,Math.abs(Math.log(r)));
 const n=Math.round(4+close*4+(B.boss?2:0)+RNG()*2);const seq=[];let who='h';
 for(let i=0;i<n;i++){seq.push({who,miss:RNG()<.12,crit:RNG()<.15});who=who==='h'?'m':'h'}
 if(B.win&&seq[seq.length-1].who!=='h')seq.push({who:'h',miss:false,crit:RNG()<.4});
 if(!B.win&&seq[seq.length-1].who!=='m')seq.push({who:'m',miss:false,crit:RNG()<.4});
 seq[seq.length-1].miss=false;
 // แบ่งดาเมจให้ถึงค่าสุดท้ายพอดี
 const share=(arr,total)=>{const w=arr.map(e=>e.miss?0:(e.crit?2:1)*(.7+RNG()*.6)),s=w.reduce((a,b)=>a+b,0)||1;arr.forEach((e,i)=>e.d=total*w[i]/s)};
 const h1=Math.max(0,P.hp/maxHp(P)),h0=Math.min(1,h1+(B.win?.12:.3)+RNG()*.15),m1=B.win?0:.25+RNG()*.3;
 share(seq.filter(e=>e.who==='h'),1-m1);share(seq.filter(e=>e.who==='m'),h0-h1);
 const mhp=B.boss?Math.round(800+r*600):Math.round(200+r*300);
 seq.forEach(e=>e.num=Math.max(e.miss?0:1,Math.round(e.d*mhp*(e.who==='m'?.6:1))));
 Object.assign(B,{seq,h0,m0:1,mhpMax:mhp,end:INTRO+seq.length*EX+OUTRO,skipT:null})}
const _sb14=startBattle;startBattle=function(){const L=P.lastFight;_sb14();if(BATTLE&&L){BATTLE.ratio=L.ratio;planBattle(BATTLE)}};
// ค่าพลังชีวิตตามเวลา
function hpAt(B,t){let h=B.h0,m=1;B.seq.forEach((e,i)=>{if(t>=INTRO+i*EX+8){if(e.who==='h')m-=e.d;else h-=e.d}});return [Math.max(0,h),Math.max(0,m)]}
drawBattle=function(cv,P,B){if(!B.seq)planBattle(B);const g=cv.getContext('2d');g.imageSmoothingEnabled=false;const key=B.world==='tower'?'tower':B.world;
 const t=B.t,M=B.foe?null:MF.mons[B.mon],sc=B.boss?2.6:2,fx=MF.fx[FX_OF[P.cls]||'wind'],cl=P.cls||'sword',i=Math.floor((t-INTRO)/EX),e=t>=INTRO?B.seq[i]:null,k=(t-INTRO)%EX,over=t>=INTRO+B.seq.length*EX;
 bgWide(g,key,Math.min(t,10),true,true);g.save();g.translate(CX,0);
 const HOME=230,MX=470;let hx=t<INTRO?HOME-80+t*8:HOME,mx=MX,ha='idle',hf=t,ma='Idle',mf=t,mal=1,shake=0,hflip=false;
 if(e&&!over){
  if(e.who==='h'){const melee=['sword','tank','assassin'].includes(cl)||!P.cls;
   if(melee)hx=k<5?HOME+k*40:k<10?MX-90:MX-90-(k-10)*30;if(cl==='assassin'&&k>=5&&k<10){hx=MX+70;hflip=true}
   ha=k>=4&&k<10?'attack':k<4?'walk':'idle';hf=Math.min(2,Math.max(0,Math.floor((k-4)/2)));
   if(k>=8&&k<13&&!e.miss){ma='Hurt';mf=k-8;shake=k%2?4:-4}}
  else{mx=k<5?MX-k*36:k<10?HOME+90:HOME+90+(k-10)*30;ma=k>=4&&k<10?'Attack':'Idle';mf=k-4;
   if(k>=8&&k<12&&!e.miss){ha='hurt';hx=HOME-(k-8)*4}}}
 const [hh,mh]=hpAt(B,t);
 if(over){const o=t-(INTRO+B.seq.length*EX);if(B.win){ma='Dead';mf=Math.min(o,(M?M.Dead.n:3)-1);mal=o<14?1:Math.max(0,1-(o-14)/6)}else{ha=o<6?'hurt':'dead';hf=o}}
 P.party.forEach((id,j)=>{const x=person(id);if(x&&x.alive)person4(g,x.look,x.tint,e&&e.who==='h'&&k>=4&&k<10?'Attack':'Idle',t+j*2,HOME-80-j*55,false,null,1.8)});
 shadow(g,mx,FEET,44);
 if(M)spr(g,ma==='Attack'?M.Attack_1:M[ma],mf,mx+shake,FEET,sc,true,mal);
 else drawHuman(g,B.foeLook||THUG,ma==='Attack'?'attack':ma==='Dead'?'dead':ma==='Hurt'?'hurt':'idle',ma==='Attack'?Math.min(2,Math.max(0,mf>>1)):mf,mx+shake,FEET,2,true,mal,'sword');
 shadow(g,hx,FEET);drawHuman(g,P.look,ha,hf,hx,FEET,2,hflip,1,P.cls);
 // กระสุนเวทและลูกธนู
 if(e&&e.who==='h'&&k>=4&&k<9&&['bow','mage','healer'].includes(cl)){const p=(k-4)/4,x=HOME+40+(MX-HOME-60)*p;
  if(cl==='bow'){R(g,x,FEET-70,26,2,'#e8d8b0');R(g,x+26,FEET-72,5,6,'#cfd8e8')}else{g.fillStyle=cl==='mage'?'rgba(255,140,40,.9)':'rgba(140,255,200,.9)';g.beginPath();g.arc(x,FEET-80,10,0,7);g.fill();g.fillStyle='#fff3b0';g.beginPath();g.arc(x,FEET-80,4,0,7);g.fill()}}
 // เอฟเฟกต์เมื่อโดน
 if(e&&e.who==='h'&&!e.miss&&k>=7&&k<15){const im=IMG[fx.src],q=(k-7)/8;if(im&&im.complete){if(fx.px){const fr=Math.min(fx.n-1,Math.floor(q*fx.n)),S=2.2;g.drawImage(im,fr*fx.w,fx.y,fx.w,fx.h,MX-fx.px*S,FEET-55-fx.py*S,fx.w*S,fx.h*S)}else{const fr=Math.min(fx.n-1,Math.floor(q*fx.n));g.drawImage(im,fr*fx.w,0,fx.w,fx.h,MX-100,FEET-180,fx.w,fx.h)}}}
 if(e&&e.who==='m'&&!e.miss&&k>=8&&k<11){g.fillStyle='rgba(255,60,60,.35)';g.beginPath();g.arc(HOME,FEET-60,40,0,7);g.fill()}
 // ตัวเลขดาเมจลอย
 if(e&&k>=8&&k<EX){const up=(k-8)*4,x=e.who==='h'?MX:HOME,s=e.miss?'หลบ!':(e.crit?'คริติคอล ':'')+e.num;g.font=`bold ${e.crit?26:20}px Mitr, sans-serif`;g.textAlign='center';g.lineWidth=4;g.strokeStyle='#000';g.strokeText(s,x,FEET-150-up);g.fillStyle=e.miss?'#cfd8e8':e.who==='h'?(e.crit?'#ffd36b':'#fff'):'#ff6a6a';g.fillText(s,x,FEET-150-up)}
 g.restore();
 hb(g,20,64,`ท่าน ${Math.round(hh*maxHp(P))}/${maxHp(P)}`,hh,'#4fd18b');hb(g,W-220,64,`${B.foe?B.foeName:MON_N[B.mon]||'ผู้พิทักษ์'} ${Math.round(mh*B.mhpMax)}`,mh,'#ff5d6c');
 g.font='12px Sarabun';g.fillStyle='rgba(255,255,255,.75)';g.textAlign='center';g.fillText(over?'':`จังหวะที่ ${Math.min(B.seq.length,i+1)}/${B.seq.length} · แตะฉากเพื่อข้าม`,W/2,40);
 if(over&&t-(INTRO+B.seq.length*EX)>=8){g.font='bold 40px Mitr, sans-serif';g.textAlign='center';g.lineWidth=7;g.strokeStyle='#000';const s=B.win?'ชนะ!':'ถอยทัพ';g.strokeText(s,W/2,120);g.fillStyle=B.win?'#ffd36b':'#ff5d6c';g.fillText(s,W/2,120)}};
// แตะฉากเพื่อข้ามไปตอนจบ
document.addEventListener('click',ev=>{if(BATTLE&&BATTLE.seq&&ev.target.closest('#scene')){const e=INTRO+BATTLE.seq.length*EX;if(BATTLE.t<e)BATTLE.t=e}});
// ป้ายหยุดเวลาชั่วคราว
setInterval(()=>{if(!P)return;let b=document.getElementById('pausebadge');const on=speed&&!BATTLE&&uiPaused();if(!b&&on){b=document.createElement('div');b.id='pausebadge';b.textContent='⏸ หยุดเวลาชั่วคราว (ปิดหน้านี้เพื่อเล่นต่อ)';document.body.appendChild(b)}if(b)b.style.display=on?'block':'none'},300);
