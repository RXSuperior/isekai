// =============== ตัวละครพิกเซลแบบซ้อนชั้น (GandalfHardcore Character Asset Pack) ===============
// เฟรม 80x64 · แถว: 0 ยืน(5) 1 เดิน(8) 2 วิ่ง(8) 3-4 กระโดด(4) 5 ฟัน(6) 6 ตาย(10)
const CW=80,CH=66,FW=80,FH=64,ROWN=[5,8,8,4,4,6,10];
const GH_IDX={mskin0:0,mskin1:1,mskin2:2,mskin3:3,mskin4:4,fskin0:5,fskin1:6,fskin2:7,fskin3:8,fskin4:9,mhair0:10,fhair0:15,mshirt0:20,mshirt1:21,mpants:22,mboots:23,mshoes:24,fcorset0:25,fcorset1:26,fskirt:27,fsocks:28,fboots:29,msword:30,fsword:31};
const HAIR_COLORS=[['ดำ','#1c1b26'],['ดำอมน้ำเงิน','#1d2340'],['น้ำตาลเข้ม','#3e2a20'],['น้ำตาล','#6b4428'],['น้ำตาลแดง','#7a3424'],['บลอนด์','#d9b45a'],['บลอนด์อ่อน','#ece0a6'],['เงิน','#c8ccd8'],['ขาว','#eef0f6'],['เทา','#7a7f8c'],
 ['แดง','#b8282e'],['ส้ม','#d8702a'],['ชมพู','#e88aaa'],['ม่วง','#7a4ab8'],['ม่วงเข้ม','#4a2a6e'],['น้ำเงิน','#2e56b8'],['ฟ้า','#6ab8e8'],['เขียว','#2e8a4e'],['เขียวมิ้นต์','#6ad0b0'],['ทอง','#e8b830']];
const SKINS=[['ผิวขาวซีด','#f6dccc'],['ผิวขาวเหลือง','#efc9a4'],['ผิวสองสี','#d6a074'],['ผิวแทน','#a8704a'],['ผิวเข้ม','#6a3e2e']];
const OUT_COLORS=[['กรมท่า','#2a3a7a'],['น้ำเงิน','#3a5ad0'],['ม่วง','#5a3a9a'],['ดำ','#2a2a32'],['เทาเข้ม','#4a4e5a'],['ขาว','#e4e6ee'],['แดง','#a82a34'],['แดงเลือดหมู','#6a1a24'],
 ['เขียว','#2e6a3e'],['เขียวทหาร','#5a6a3a'],['น้ำตาล','#6a4a2e'],['ครีม','#d8c8a0'],['ส้ม','#d0702a'],['ชมพู','#d07aa0'],['ฟ้า','#4a9ad0'],['ทอง','#c8a030']];
const HAIRS_M=['สั้นยุ่ง','ชี้ฟู','หางม้าสั้น','ยาวประบ่า','รองทรง','มวยบน'],HAIRS_F=['ยาวสลวย','บ็อบ','หางม้า','มวยผม','แกละสองข้าง','สั้นซอย'];
const TOPS_M=['เสื้อเชิ้ต','เชิ้ตคาดเข็มขัด'],TOPS_F=['คอร์เซ็ต','คอร์เซ็ตเสื้อเบลาส์'],SHOES_M=['รองเท้าบูท','รองเท้าหนัง'],SHOES_F=['บูท','บูทกับถุงเท้ายาว'];
const HAIRS=HAIRS_M;
const LOOK_OPTS={skin:5,hair:6,hairC:20,top:2,topC:16,botC:16,shoe:2};
function randomLook(sex){const r=n=>Math.floor(Math.random()*n);const L={sex:sex||(Math.random()<.5?'m':'f')};for(const k in LOOK_OPTS)L[k]=r(LOOK_OPTS[k]);if(Math.random()<.6)L.hairC=r(5);return L}
function hx(c){const n=parseInt(c.slice(1),16);return [n>>16,n>>8&255,n&255]}
function mix(c,t,a){const A=hx(c),B=hx(t);return '#'+A.map((v,i)=>Math.round(v+(B[i]-v)*a).toString(16).padStart(2,'0')).join('')}
const lumOf=c=>{const [r,g,b]=hx(c);return .3*r+.59*g+.11*b};
function ramp4(c){if(lumOf(c)<45)c=mix(c,'#4a4466',.38);return [mix(c,'#0a0612',.72),mix(c,'#1a1030',.34),c,mix(c,'#ffffff',.3)].map(hx)}
// ชุดสีต้นฉบับของแต่ละชั้น (มืด→สว่าง)
const FAM={red:[[51,15,31],[94,32,39],[145,43,46],[185,42,59]],white:[[97,75,68],[163,137,130],[191,176,168],[229,218,209]],
 hairM:[[19,19,28],[44,34,29],[64,45,32],[89,59,31]],hairF:[[20,11,15],[44,34,29],[64,45,32],[89,59,31]]};
const GH_IMG=typeof Image!=='undefined'?new Image():null;if(GH_IMG)GH_IMG.src='a/gh/chars.png';
const LAYER_CACHE={};
function layerData(name){if(LAYER_CACHE[name])return LAYER_CACHE[name];if(!GH_IMG||!GH_IMG.complete||!GH_IMG.naturalWidth)return null;
 const c=document.createElement('canvas');c.width=800;c.height=448;const g=c.getContext('2d');g.drawImage(GH_IMG,0,-448*GH_IDX[name]);return LAYER_CACHE[name]=g.getImageData(0,0,800,448).data}
const keyOf=([r,g,b])=>(r<<16)|(g<<8)|b;
function famMap(fam,ramp){const m=new Map();fam.forEach((c,i)=>m.set(keyOf(c),ramp[i]));return m}
// ทรงผม: แก้หน้ากากผมทีละเฟรม (0=เส้นขอบ 1 มืด 2 กลาง 3 สว่าง)
function hairIdx(sex){const d=layerData(sex==='f'?'fhair0':'mhair0');if(!d)return null;const fam=sex==='f'?FAM.hairF:FAM.hairM,m=new Map();fam.forEach((c,i)=>m.set(keyOf(c),i));
 const idx=new Int8Array(800*448).fill(-1);for(let p=0;p<800*448;p++){if(d[p*4+3]<10)continue;const k=keyOf([d[p*4],d[p*4+1],d[p*4+2]]);idx[p]=m.has(k)?m.get(k):1}return idx}
function hairVariant(idx,sex,v){if(!v)return idx;const out=new Int8Array(idx);
 for(let r=0;r<7;r++)for(let c=0;c<ROWN[r];c++){const X=c*FW,Y=r*FH;let x0=99,x1=-1,y0=99,y1=-1;
  for(let y=0;y<FH;y++)for(let x=0;x<FW;x++)if(idx[(Y+y)*800+X+x]>=0){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}
  if(x1<0||x1-x0>y1-y0+6)continue;
  const at=(x,y)=>(Y+y)*800+X+x,set=(x,y,k=2)=>{if(x>=0&&y>=0&&x<FW&&y<FH)out[at(x,y)]=k},cut=yc=>{for(let y=yc;y<FH;y++)for(let x=0;x<FW;x++)out[at(x,y)]=-1};
  const blob=(cx,cy,rx,ry)=>{for(let y=Math.floor(cy-ry);y<=cy+ry;y++)for(let x=Math.floor(cx-rx);x<=cx+rx;x++){const dx=(x+.5-cx)/rx,dy=(y+.5-cy)/ry;if(dx*dx+dy*dy<=1)set(x,y,y<cy-ry/3?3:2)}};
  const tail=(sx,sy,ex,ey,w)=>{const n=Math.max(Math.abs(ex-sx),Math.abs(ey-sy));for(let i=0;i<=n;i++){const x=Math.round(sx+(ex-sx)*i/n),y=Math.round(sy+(ey-sy)*i/n),ww=Math.max(1,Math.round(w*(1-i/n*.5)));for(let k=0;k<ww;k++)set(x+k-(ww>>1),y,i<2?2:1)}};
  const spikes=()=>{[[2,2],[5,3],[8,2],[10,1]].forEach(([dx,h])=>{for(let k=1;k<=h;k++){set(x0+dx,y0-k+1,2);if(k<h)set(x0+dx+1,y0-k+1,3)}})};
  const hw=x1-x0,mid=x0+hw/2;
  if(sex==='m'){
   if(v===1)spikes();
   if(v===2){tail(x1-1,y0+4,x1+2,y0+11,3)}
   if(v===3){for(let y=y0+6;y<y0+16;y++)for(let x=x1-4;x<=x1;x++)set(x,y,y>y0+13?1:2);for(let y=y0+6;y<y0+12;y++)set(x0,y,1)}
   if(v===4){for(let y=y0+8;y<FH;y++)for(let x=0;x<FW;x++)if(out[at(x,y)]>=0&&x>x1-3)out[at(x,y)]=-1}
   if(v===5){blob(mid+1,y0-1,2.6,2.2)}
  }else{
   const jaw=y0+10;
   if(v===1){cut(jaw+1)}
   if(v===2){cut(jaw-1);tail(x1-1,y0+3,x1+3,y0+14,3)}
   if(v===3){cut(jaw-1);blob(x1-2,y0,2.8,2.4)}
   if(v===4){cut(jaw-1);tail(x0+1,y0+4,x0-1,y0+14,2);tail(x1-1,y0+4,x1+1,y0+14,2)}
   if(v===5){cut(jaw-3);spikes()}
  }
  // ลงเส้นขอบใหม่รอบหน้ากาก
  const nb=(x,y)=>x<0||y<0||x>=FW||y>=FH||out[at(x,y)]<0;
  for(let y=Math.max(0,y0-6);y<FH;y++)for(let x=0;x<FW;x++){const p=at(x,y);if(out[p]<0)continue;const rm=(xx,yy)=>xx>=0&&yy>=0&&xx<FW&&yy<FH&&idx[at(xx,yy)]>=0&&out[at(xx,yy)]<0;if(idx[p]<0||out[p]!==idx[p]||rm(x-1,y)||rm(x+1,y)||rm(x,y-1)||rm(x,y+1)){if(nb(x-1,y)||nb(x+1,y)||nb(x,y-1)||nb(x,y+1))out[p]=0}}
 }
 return out}

// ---- เครื่องประดับและชุดเพิ่ม ให้ตัวละครแต่ละคนดูต่างกัน ----
const FACE_N=['ไม่มี','เคราเต็มหน้า','หนวด','แว่นตา','ผ้าปิดตา','แผลเป็น'],HEAD_N=['ไม่มี','ฮู้ด','หมวกพ่อมด','ผ้าโพกหัว','มงกุฎเล็ก','หมวกปีกกว้าง','ดอกไม้ทัดผม'],OUTFIT_N=['ไม่มี','ผ้าคลุม','เกราะ','ผ้ากันเปื้อน','เสื้อคลุมยาว','ผ้าพันคอ'];
const GEAR_OPTS={face:6,head:7,outfit:6,accC:16};
function gearPaint(o,L,hi,shirtD,skinD,hr){const acc=ramp4(OUT_COLORS[L.accC|0][1]),gold=ramp4('#d8b040'),steel=ramp4('#9aa4b4');
 const A=p=>o[p*4+3],put=(p,c)=>{o[p*4]=c[0];o[p*4+1]=c[1];o[p*4+2]=c[2];o[p*4+3]=255};
 for(let r=0;r<7;r++)for(let c=0;c<ROWN[r];c++){const X=c*FW,Y=r*FH,at=(x,y)=>(Y+y)*800+X+x,ok=(x,y)=>x>=0&&y>=0&&x<FW&&y<FH;
  let x0=99,x1=-1,y0=99,y1=-1,sx0=99,sx1=-1,sy0=99,sy1=-1;
  for(let y=0;y<FH;y++)for(let x=0;x<FW;x++){const p=at(x,y);if(hi[p]>=0){x0=Math.min(x0,x);x1=Math.max(x1,x);y0=Math.min(y0,y);y1=Math.max(y1,y)}if(shirtD[p*4+3]>=10){sx0=Math.min(sx0,x);sx1=Math.max(sx1,x);sy0=Math.min(sy0,y);sy1=Math.max(sy1,y)}}
  const lying=x1<0||x1-x0>y1-y0+6||r===6&&c>=3;
  const P=(x,y,col)=>{if(ok(x,y))put(at(x,y),col)},B=(x,y,col)=>{if(ok(x,y)&&!A(at(x,y)))put(at(x,y),col)},has=(x,y)=>ok(x,y)&&A(at(x,y))>0,skin=(x,y)=>ok(x,y)&&skinD[at(x,y)*4+3]>=10&&hi[at(x,y)]<0;
  // ร่างกาย
  if(sx1>=0){
   if(L.outfit===1){for(let y=sy0;y<Math.min(FH-2,sy1+14);y++){const w=3+((y-sy0)>>2);for(let x=sx1-2;x<=sx1+w;x++)B(x,y,x>=sx1+w-1||y>=Math.min(FH-3,sy1+13)?acc[0]:acc[1])}for(let x=sx0+2;x<=sx1;x++){P(x,sy0,acc[2]);if(has(x,sy0+1))P(x,sy0+1,acc[1])}}
   if(L.outfit===2){for(let y=sy0;y<=sy1;y++)for(let x=sx0;x<=sx1;x++){const p=at(x,y);if(shirtD[p*4+3]>=10&&hi[p]<0){const l=(o[p*4]*.3+o[p*4+1]*.59+o[p*4+2]*.11);put(p,steel[l<50?0:l<110?1:l<170?2:3])}}
    for(let y=sy0-1;y<sy0+4;y++)for(let x=sx0-1;x<sx0+4;x++)P(x,y,(x===sx0-1||y===sy0-1)?steel[0]:steel[y<sy0+1?3:2]);for(let x=sx0;x<=sx1;x++)if(has(x,sy1-1))P(x,sy1-1,gold[2])}
   if(L.outfit===3){const t=sy0+6,b=Math.min(FH-5,sy1+12);for(let y=t;y<=b;y++){let mn=99,mx=-1;for(let x=sx0;x<=sx1-2;x++)if(has(x,y)){mn=Math.min(mn,x);mx=Math.max(mx,x)}for(let x=mn+1;x<mx;x++)P(x,y,y===b||x===mn+1?acc[1]:acc[3])}for(let x=sx0+2;x<sx1-2;x++)if(has(x,sy0+2))P(x,sy0+2,acc[1])}
   if(L.outfit===4){for(let y=sy0;y<=sy1;y++)for(let x=sx0;x<=sx1;x++){const p=at(x,y);if(shirtD[p*4+3]>=10&&hi[p]<0){const l=(o[p*4]*.3+o[p*4+1]*.59+o[p*4+2]*.11);put(p,acc[l<50?0:l<110?1:l<170?2:3])}}
    for(let y=sy1;y<FH-2;y++){let mn=99,mx=-1;for(let x=0;x<FW;x++)if(has(x,y)){mn=Math.min(mn,x);mx=Math.max(mx,x)}if(mx<0)continue;const e=(y-sy1)>>3;mn-=e;mx+=e;for(let x=mn;x<=mx;x++)P(x,y,x===mn||x===mx||y===FH-3?acc[0]:x<mn+2?acc[1]:acc[2])}}
   if(L.outfit===5&&!lying){for(let y=sy0-1;y<=sy0+1;y++)for(let x=x0+1;x<=x1;x++)if(has(x,y))P(x,y,y===sy0+1?acc[1]:acc[2]);for(let y=sy0;y<sy0+6;y++){B(x1+1,y,acc[1]);B(x1+2,y,acc[0])}}
  }
  if(lying)continue;const e=y0+7;
  // ใบหน้า
  if(L.face===1)for(let y=y0+9;y<=y0+13;y++)for(let x=x0+1;x<=x0+9;x++){if(!skin(x,y))continue;const edge=x<=x0+2||x>=x0+7;if(y<=y0+10&&!edge)continue;P(x,y,(y===y0+13||x===x0+1)?hr[0]:hr[1])}
  if(L.face===2)for(let x=x0+2;x<=x0+6;x++)P(x,y0+9,hr[1]);
  if(L.face===3){for(let x=x0+1;x<=x0+7;x++)P(x,e-1,[30,26,40]);[x0+1,x0+4,x0+7].forEach(x=>P(x,e,[30,26,40]));[x0+2,x0+3,x0+5,x0+6].forEach(x=>P(x,e,[190,224,255]))}
  if(L.face===4){for(let y=e-1;y<=e+1;y++)for(let x=x0+5;x<=x0+7;x++)P(x,y,[20,18,24]);for(let x=x0+7;x<=x1;x++)P(x,e-2,[40,30,30])}
  if(L.face===5){P(x0+6,e-1,[150,50,50]);P(x0+7,e,[150,50,50]);P(x0+6,e+1,[150,50,50]);P(x0+7,e+2,[150,50,50])}
  // ศีรษะ
  if(L.head===1){for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const p=at(x,y);if(hi[p]>=0)put(p,acc[hi[p]===0?0:hi[p]>=3?3:2])}for(let x=x0;x<=x1;x++)P(x,y0-1,acc[0]);for(let y=y0;y<y0+11;y++){B(x0-1,y,acc[0]);P(x1+1,y,acc[1]);B(x1+2,y,acc[0])}for(let y=y0+8;y<y0+17;y++){B(x1,y,acc[1]);B(x1+1,y,acc[1]);B(x1+2,y,acc[0])}}
  if(L.head===2){const w=x1-x0;for(let x=x0-3;x<=x1+3;x++){P(x,y0+1,acc[1]);P(x,y0+2,acc[0])}for(let x=x0;x<=x1;x++)P(x,y0,gold[2]);for(let k=1;k<=12;k++){const hw=Math.max(0,Math.round(w/2*(1-k/12))),cx=Math.round(x0+w/2+k*.4);for(let x=cx-hw;x<=cx+hw;x++)P(x,y0-k,x===cx-hw||x===cx+hw?acc[0]:acc[2])}P(Math.round(x0+w/2),y0-5,gold[3])}
  if(L.head===3){for(let y=y0+2;y<=y0+3;y++)for(let x=x0;x<=x1;x++)if(has(x,y))P(x,y,acc[y===y0+2?3:2]);for(let k=0;k<4;k++){B(x1+1+k,y0+3+k,acc[2]);B(x1+1+k,y0+4+k,acc[1])}}
  if(L.head===4){for(let x=x0;x<=x1;x++)if(has(x,y0+4))P(x,y0+4,gold[2]);P(x0+4,y0+3,acc[3]);P(x0+4,y0+4,acc[2]);P(x0+3,y0+4,gold[3])}
  if(L.head===5){for(let y=y0-3;y<=y0+1;y++)for(let x=x0+2;x<=x1-1;x++)P(x,y,x===x0+2||x===x1-1||y===y0-3?acc[0]:y===y0+1?acc[1]:acc[2]);for(let x=x0-3;x<=x1+3;x++){P(x,y0+2,acc[2]);P(x,y0+3,acc[0])}}
  if(L.head===6){const fx=x1-1,fy=y0+2;[[0,-1],[-1,0],[1,0],[0,1]].forEach(([dx,dy])=>P(fx+dx,fy+dy,acc[3]));P(fx,fy,[250,220,90])}
 }}
const SHEET_CACHE={};
function lookKey(L,w){return [L.sex,L.skin,L.hair,L.hairC,L.top,L.topC,L.botC,L.shoe,L.face|0,L.head|0,L.outfit|0,L.accC|0,w?1:0].join('.')}
function normLook(L){const n={sex:L.sex==='f'?'f':'m'};for(const k in LOOK_OPTS)n[k]=((L[k]|0)%LOOK_OPTS[k]+LOOK_OPTS[k])%LOOK_OPTS[k];for(const k in GEAR_OPTS)n[k]=((L[k]|0)%GEAR_OPTS[k]+GEAR_OPTS[k])%GEAR_OPTS[k];return n}
function getSheet(L0,wep){const L=normLook(L0),key=lookKey(L,wep);if(SHEET_CACHE[key])return SHEET_CACHE[key];
 const f=L.sex==='f',P=f?'f':'m';const order=[[P+'skin'+L.skin,null]];
 const top=ramp4(OUT_COLORS[L.topC][1]),bot=ramp4(OUT_COLORS[L.botC][1]);
 if(f){if(L.shoe===1)order.push(['fsocks',null]);order.push(['fskirt',famMap(FAM.white,bot)],['fboots',null],['fcorset'+L.top,famMap(FAM.red,top)])}
 else order.push(['mpants',famMap(FAM.red,bot)],[L.shoe?'mshoes':'mboots',null],['mshirt'+L.top,famMap(FAM.white,top)]);
 const datas=order.map(([n])=>layerData(n));if(datas.some(d=>!d))return null;
 const hi=hairIdx(L.sex);if(!hi)return null;const hv=hairVariant(hi,L.sex,L.hair),hr=ramp4(HAIR_COLORS[L.hairC][1]);
 const sw=wep?layerData(P+'sword'):null;
 const c=document.createElement('canvas');c.width=800;c.height=448;const g=c.getContext('2d'),im=g.createImageData(800,448),o=im.data;
 const put=(p,r,gg,b)=>{o[p*4]=r;o[p*4+1]=gg;o[p*4+2]=b;o[p*4+3]=255};
 order.forEach(([n,map],li)=>{const d=datas[li];for(let p=0;p<800*448;p++){if(d[p*4+3]<10)continue;let col=[d[p*4],d[p*4+1],d[p*4+2]];if(map){const m=map.get(keyOf(col));if(m)col=m}put(p,col[0],col[1],col[2])}});
 for(let p=0;p<800*448;p++)if(hv[p]>=0){const k=hv[p];put(p,...hr[k])}
 if(L.face||L.head||L.outfit)gearPaint(o,L,hi,datas[datas.length-1],datas[0],hr);
 if(sw)for(let p=0;p<800*448;p++)if(sw[p*4+3]>=10)put(p,sw[p*4],sw[p*4+1],sw[p*4+2]);
 g.putImageData(im,0,0);return SHEET_CACHE[key]=c}
const SWORD_CLS={sword:1,assassin:1,tank:1};
function pickFrame(name,t){if(name==='walk')return [1,t%8];if(name==='attack')return [5,[1,3,5][Math.min(2,t|0)]];if(name==='hurt')return [6,1];if(name==='dead')return [6,9];return [0,Math.floor(t/3)%5]}
function charFrame(L,name,f,wep){const s=getSheet(L,!!SWORD_CLS[wep]);if(!s)return null;const [r,c]=pickFrame(name,f);const cv=document.createElement('canvas');cv.width=FW;cv.height=FH;cv.getContext('2d').drawImage(s,c*FW,r*FH,FW,FH,0,0,FW,FH);return cv}
function drawHuman(g,L,name,t,x,y,sc=2,flip=false,alpha=1,wep){if(!L)return;const s=getSheet(L,!!SWORD_CLS[wep]);if(!s)return;const [r,c]=pickFrame(name,t);const k=Math.max(1,Math.round(sc*1.5));
 g.save();g.globalAlpha=alpha;g.imageSmoothingEnabled=false;g.translate(Math.round(x),Math.round(y));if(!flip)g.scale(-1,1);g.drawImage(s,c*FW,r*FH,FW,FH,-39.5*k,-FH*k,FW*k,FH*k);g.restore()}
