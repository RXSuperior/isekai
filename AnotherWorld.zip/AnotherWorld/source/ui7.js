// ---- v7: แสดงที่มาในหน้าชีวิต ----
const _lifeV7=views.life;views.life=()=>(P.originN?`<div class="card" style="font-size:13px"><b class="c-star">ที่มา:</b> ${esc(P.originN)}${P.flags.earth?' · <span class="mut">ยังจำโลกเดิมได้ทุกอย่าง</span>':''}</div>`:'')+_lifeV7();
