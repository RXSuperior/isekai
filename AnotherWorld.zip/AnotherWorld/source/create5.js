// ---------- หน้าแรก ----------
let TITLE_LOOK=null,NEWSEX=null;
function titleScene(cv,t){
 if(!cv)return;const g=cv.getContext('2d');g.imageSmoothingEnabled=false;g.setTransform(2,0,0,2,0,0);
 // ฟ้ายามสนธยาที่ถูกฉีกด้วยประตูมิติ (วาดในพิกัด 576x324 แล้วขยาย 2 เท่า)
 {const im=IMG['a/gh/c_n5.png']||img('a/gh/c_n5.png');if(im&&im.complete)g.drawImage(im,0,0)}g.fillStyle='rgba(30,10,60,.72)';g.fillRect(0,0,576,324);
 for(let i=0;i<90;i++){const a=.3+.7*Math.abs(Math.sin(t*.07+i));g.fillStyle=`rgba(255,250,230,${a*.8})`;g.fillRect(hr(i)*576|0,hr(i*3)*170|0,hr(i*5)<.15?2:1,hr(i*5)<.15?2:1)}
 g.fillStyle='#f4ecd0';g.beginPath();g.arc(92,64,24,0,7);g.fill();g.fillStyle='rgba(30,20,50,.18)';g.beginPath();g.arc(84,58,6,0,7);g.arc(100,74,4,0,7);g.fill();
 g.fillStyle='#e89a8a';g.beginPath();g.arc(138,40,8,0,7);g.fill();
 // แสงจากประตู
 const px=430,py=92,gr=g.createRadialGradient(px,py,0,px,py,220);gr.addColorStop(0,'rgba(190,140,255,.55)');gr.addColorStop(1,'rgba(190,140,255,0)');g.fillStyle=gr;g.fillRect(0,0,576,324);
 // ภูเขา ปราสาท และป่า
 ['castle','4','3'].forEach(n=>{const im=IMG['a/gh/c_n'+n+'.png']||img('a/gh/c_n'+n+'.png');if(im&&im.complete)g.drawImage(im,n==='castle'?60:0,0)});
 g.fillStyle='rgba(40,16,70,.5)';g.fillRect(0,0,576,324);
 ['2','1'].forEach(n=>{const im=IMG['a/gh/c_n'+n+'.png']||img('a/gh/c_n'+n+'.png');if(im&&im.complete)g.drawImage(im,0,0)});
 for(let y=150;y<324;y+=4){g.fillStyle=`rgba(14,6,30,${Math.min(.85,(y-150)/200)})`;g.fillRect(0,y,576,4)}
 portal(g,'violet',px,py+84*1.1,2.2,t);
 for(let i=0;i<5;i++){const a=t*.02+i*1.26;g.strokeStyle=`rgba(210,180,255,${.25+.15*Math.sin(t*.1+i)})`;g.lineWidth=2;g.beginPath();g.arc(px,py,60+i*14+((t*.6)%14),a,a+1.2);g.stroke()}
 // หุบเขา หมู่บ้านไฟสลัว ถนน และหมอก
 g.fillStyle='#1c1230';g.beginPath();g.moveTo(180,262);g.quadraticCurveTo(380,236,576,250);g.lineTo(576,324);g.lineTo(180,324);g.fill();
 g.strokeStyle='#4a3a5a';g.lineWidth=5;g.beginPath();g.moveTo(214,300);g.quadraticCurveTo(330,262,420,282);g.quadraticCurveTo(500,300,576,272);g.stroke();
 for(let i=0;i<11;i++){const x=250+i*29+hr(i)*10,y=256+hr(i*3)*22,w=14+hr(i*5)*8;g.fillStyle='#2a1c3a';g.fillRect(x,y,w,12);g.fillStyle='#3a2448';g.beginPath();g.moveTo(x-2,y);g.lineTo(x+w/2,y-7);g.lineTo(x+w+2,y);g.fill();g.fillStyle=`rgba(255,${190+hr(i)*40|0},110,${.7+.3*Math.sin(t*.2+i)})`;g.fillRect(x+4,y+4,3,3);if(hr(i*7)>.4)g.fillRect(x+w-7,y+4,3,3)}
 for(let k=0;k<3;k++){g.fillStyle=`rgba(180,160,220,${.08+k*.03})`;for(let x=-80;x<576;x+=160){const ox=(x+t*(.3+k*.2))%656-80;g.beginPath();g.ellipse(ox,236+k*18,110,10,0,0,7);g.fill()}}
 // ประกายที่ถูกดูดเข้าประตู
 for(let i=0;i<46;i++){const k=((t*.8+i*37)%300)/300,sx=hr(i)*576,sy=200+hr(i*3)*120,x=sx+(px-sx)*k,y=sy+(py-sy)*k;g.fillStyle=`rgba(${200+hr(i*7)*55|0},${170+hr(i*9)*60|0},255,${1-k})`;g.fillRect(x|0,y|0,2,2)}
 // หน้าผาที่ตัวเอกยืน
 g.fillStyle='#120a1c';g.beginPath();g.moveTo(0,232);g.lineTo(70,222);g.lineTo(150,228);g.lineTo(196,236);g.lineTo(214,262);g.lineTo(200,324);g.lineTo(0,324);g.fill();
 g.fillStyle='#2a1a38';for(let x=0;x<200;x+=4)g.fillRect(x,226+Math.sin(x/30)*3+(x>150?(x-150)/5:0)|0,3,2);
 for(let i=0;i<14;i++){const a=t*.05+i;g.fillStyle=`rgba(255,230,140,${.4+.4*Math.sin(t*.13+i)})`;g.fillRect(30+hr(i)*170+Math.sin(a)*8|0,180+hr(i*2)*50+Math.cos(a*1.3)*6|0,2,2)}
 if(!TITLE_LOOK){TITLE_LOOK=randomLook('m');Object.assign(TITLE_LOOK,{outfit:1,accC:6})}
 shadow(g,128,228);drawHuman(g,TITLE_LOOK,'idle',t,128,228,1.1,false,1,'sword');
 g.setTransform(1,0,0,1,0,0);
}
function startScreen(){
 WZ=null;$('#modal').innerHTML='';
 $('#app').innerHTML=`<div class="titlewrap"><canvas id="title" width="1152" height="648" class="scene tscene"></canvas>
  <div class="ttext"><div class="tmain">ต่างโลกที่ไม่มีทางกลับ</div><div class="tsub">ANOTHER WORLD · NO RETURN</div><div class="tban">ชีวิตหนึ่งชีวิต ในโลกที่ไม่มีทางกลับ</div></div></div>
  <div class="tmenu">
   <input id="nm" maxlength="16" placeholder="ชื่อตัวละคร (เว้นว่าง = สุ่ม)">
   <button class="tb main" id="go">ชีวิตใหม่</button>
   <div class="row" style="gap:6px">${[['','🎲 สุ่มเพศ'],['m','♂ ชาย'],['f','♀ หญิง']].map(([v,n])=>`<button class="tb sm ${NEWSEX===(v||null)?'on':''}" data-sex="${v}">${n}</button>`).join('')}</div>
   <button class="tb" id="load">โหลด</button><button class="tb" id="sett">ตั้งค่า</button><button class="tb" id="how">วิธีเล่น</button>
   <button class="tb" id="news">บันทึกการพัฒนา</button>
  </div>
  <p class="credit">${META.lives?`ใช้ชีวิตมาแล้ว ${META.lives} ชีวิต · ความทรงจำที่สืบทอด +${Math.min(META.legacy,30)}${META.best?` · ดีที่สุด: ${esc(META.best.name)} เลเวล ${META.best.lvl}`:''} · `:''}ตัวละครและฉากป่า: GandalfHardcore · มอนสเตอร์ ฉากต่างโลก ไอคอน: CraftPix.net</p>`;
 titleScene($('#title'),frame);
 document.querySelectorAll('[data-sex]').forEach(b=>b.onclick=()=>{NEWSEX=b.dataset.sex||null;startScreen()});
 $('#go').onclick=()=>slotModal('new');$('#load').onclick=()=>slotModal('load');
 $('#sett').onclick=()=>infoModal('ตั้งค่า',`<label class="row"><input type="checkbox" id="sf" ${SET.fate?'checked':''} style="width:auto"> ให้ชะตาเลือกแทนเมื่อไม่ได้กดภายใน <input id="sw" type="number" min="2" max="30" value="${SET.fateWait}" style="width:70px"> วินาที</label>`,()=>{SET.fate=$('#sf').checked;SET.fateWait=clamp(+$('#sw').value||5,2,30);save()});
 $('#how').onclick=()=>infoModal('วิธีเล่น',HOWTO);
 $('#news').onclick=()=>infoModal('บันทึกการพัฒนา',`<p><b>v5</b> ตัวละครพิกเซลแบบใหม่ แต่งได้ 10 หมวด หน้าแรกใหม่ ช่องเซฟ 3 ช่อง สร้างชีวิตแบบสุ่ม แบบออกแบบหน้าตา หรือสร้างเองทั้งหมดด้วยแต้ม พร้อมพรสวรรค์ มานาแฝง ร่างกาย และดวงชะตา</p><p><b>v4.1</b> เหตุการณ์ใหม่ชุดใหญ่ 68 เรื่อง เรื่องต่อเนื่อง 13 ชุด</p><p><b>v4</b> ระบบจำลองชีวิตตาม Way of Xian บันทึกรายปี วิถีชีวิต นิสัย ผู้คน แผนที่</p>`);
}
function infoModal(title,html,onClose){$('#modal').innerHTML=`<div class="modal"><div class="panel"><h2>${title}</h2>${html}<div class="row" style="justify-content:flex-end;margin-top:10px"><button class="btn pri" id="cl">ปิด</button></div></div></div>`;$('#cl').onclick=()=>{onClose&&onClose();$('#modal').innerHTML=''}}
function slotModal(mode){
 const rows=[0,1,2].map(i=>{const p=slotInfo(i);return `<div class="card row"><div class="sp"><b>ช่อง ${i+1}</b><div class="mut" style="font-size:13px">${p?`${esc(p.name)} · อายุ ${ageY(p)} · ${p.alive?(p.rank>=0?`ฮันเตอร์แรงก์ ${RANKS[p.rank]}`:'นักเรียน'):'เสียชีวิตแล้ว'}`:'ว่าง'}</div></div>
  ${mode==='new'?`<button class="btn pri sm" data-new="${i}">ชีวิตใหม่</button>`:p?`<button class="btn pri sm" data-load="${i}">เล่นต่อ</button><button class="btn sm" data-del="${i}">ลบ</button>`:''}</div>`}).join('');
 $('#modal').innerHTML=`<div class="modal"><div class="panel"><h2>${mode==='new'?'เลือกช่องสำหรับชีวิตใหม่':'โหลด'}</h2>${rows}<div class="row" style="justify-content:flex-end"><button class="btn" id="cl">ปิด</button></div></div></div>`;
 $('#cl').onclick=()=>$('#modal').innerHTML='';
 document.querySelectorAll('[data-new]').forEach(b=>b.onclick=()=>{const i=+b.dataset.new;if(slotInfo(i)&&!confirmSlot(i))return;SLOT=i;modeModal()});
 document.querySelectorAll('[data-load]').forEach(b=>b.onclick=()=>{SLOT=+b.dataset.load;P=slotInfo(SLOT);PENDING=[];save();$('#modal').innerHTML='';tab='log';setSpeed(0)});
 document.querySelectorAll('[data-del]').forEach(b=>b.onclick=()=>{const i=+b.dataset.del;if(b.dataset.sure){try{localStorage.removeItem(SKEY(i))}catch(e){}slotModal(mode)}else{b.dataset.sure=1;b.textContent='กดอีกครั้งเพื่อลบ'}});
}
function confirmSlot(i){const b=document.querySelector(`[data-new="${i}"]`);if(b.dataset.sure)return true;b.dataset.sure=1;b.textContent='ทับเซฟเดิม? กดอีกครั้ง';return false}
function modeModal(){
 const sex=NEWSEX||(Math.random()<.5?'m':'f'),name=($('#nm')?.value||'').trim();
 $('#modal').innerHTML=`<div class="modal"><div class="panel"><h2>ชีวิตใหม่</h2>
  <p class="mut">สุ่ม: ชะตากำหนดทุกอย่าง · ออกแบบหน้าตา: เลือกแค่หน้าตา ส่วนครอบครัว มานา ร่างกาย ดวงชะตา และพรสวรรค์ ชะตาเป็นคนจัดให้ โดยไม่ใช้แต้ม · สร้างเอง: ออกแบบหน้าตาและใช้แต้ม ${BUDGET} แต้มเลือกทุกอย่างเอง</p>
  <button class="opt" id="m1"><b>🎲 สุ่ม (ให้ชะตาตัดสิน)</b></button>
  <button class="opt" id="m2"><b>🎨 ออกแบบหน้าตา ชะตากำหนดที่เหลือ</b></button>
  <button class="opt" id="m3"><b>✍️ สร้างเองทั้งหมด</b></button>
  <button class="opt" id="m4"><b>♾️ สร้างเองไม่จำกัดแต้ม</b><span class="mut">เลือกได้ทุกอย่างไม่มีแต้ม เลือกพรสวรรค์ได้ทุกใบ</span></button>
  <div class="row" style="justify-content:flex-end"><button class="btn" id="cl">ปิด</button></div></div></div>`;
 $('#cl').onclick=()=>$('#modal').innerHTML='';
 $('#m1').onclick=()=>{const c=randomCfg(sex);c.name=name;begin(c)};
 $('#m2').onclick=()=>{startWizard('look',{...randomCfg(sex),name})};
 $('#m3').onclick=()=>{const c=randomCfg(sex);c.family=1;c.origin=0;c.mana=0;c.body=0;c.destiny=0;c.talents=[];c.name=name;startWizard('full',c)};
 $('#m4').onclick=()=>{const c=randomCfg(sex);c.family=1;c.origin=0;c.mana=0;c.body=0;c.destiny=0;c.talents=[];c.name=name;startWizard('free',c)};
}
function begin(cfg){WZ=null;$('#modal').innerHTML='';newLife(cfg);save();tab='log';setSpeed(1)}
// ---------- ตัวช่วยสร้างทีละขั้น ----------
const isF=()=>((typeof WZ!=='undefined'&&WZ&&WZ.cfg&&WZ.cfg.look.sex)||'m')==='f';
const LOOK_STEPS=[['sex','เพศ',2,i=>['ชาย','หญิง'][i]],['skin','สีผิว',SKINS.length,i=>SKINS[i][0],i=>SKINS[i][1]],['hair','ทรงผม',6,i=>(isF()?HAIRS_F:HAIRS_M)[i]],['hairC','สีผม',HAIR_COLORS.length,i=>HAIR_COLORS[i][0],i=>HAIR_COLORS[i][1]],
 ['top','เสื้อ',2,i=>(isF()?TOPS_F:TOPS_M)[i]],['topC','สีเสื้อ',OUT_COLORS.length,i=>OUT_COLORS[i][0],i=>OUT_COLORS[i][1]],['botC',()=>isF()?'สีกระโปรง':'สีกางเกง',OUT_COLORS.length,i=>OUT_COLORS[i][0],i=>OUT_COLORS[i][1]],
 ['shoe','รองเท้า',2,i=>(isF()?SHOES_F:SHOES_M)[i]],['face','ใบหน้า',6,i=>FACE_N[i]],['head','ของบนศีรษะ',7,i=>HEAD_N[i]],['outfit','ชุดพิเศษ',OUTFIT_N.length,i=>OUTFIT_N[i]],['accC','สีเครื่องประดับ',OUT_COLORS.length,i=>OUT_COLORS[i][0],i=>OUT_COLORS[i][1]]];
const PAID_STEPS=[['origin','ที่มา',ORIGINS],['family','พื้นหลังครอบครัว',FAMILIES],['mana','มานาแฝง',MANA],['body','ร่างกาย',BODY],['destiny','ดวงชะตา',DESTINY]];
function startWizard(mode,cfg){
 if(mode==='edit')cfg={look:{...P.look},sex:P.sex};
 const steps=[...LOOK_STEPS.map(s=>({k:s[0],look:1,s})),...(mode==='full'||mode==='free'?[...PAID_STEPS.map(s=>({k:s[0],paid:1,s})),{k:'talents'}]:[]),...(mode==='edit'?[]:[{k:'name'}])];
 WZ={mode,cfg,steps,i:0,deck:TALENTS.slice().sort(()=>Math.random()-.5).slice(0,9),rolls:0};
 if(mode==='edit')WZ.steps=WZ.steps.filter(s=>s.k!=='sex');
 wizard();
}
function wizard(){
 const w=WZ,st=w.steps[w.i],c=w.cfg,L=c.look,FREE=w.mode==='free',left=FREE?999:BUDGET-(w.mode==='full'?cfgCost(c):0),tleft=FREE?999:TBUDGET-talentCost(c.talents||[]),TMAX=FREE?99:3,DECK=FREE?TALENTS:w.deck;
 let body='';
 if(st.look){const [k,lab0,n,nm,col]=st.s,lab=typeof lab0==='function'?lab0():lab0;const v=k==='sex'?(L.sex==='f'?1:0):(L[k]??=0);
  body=`<div class="stepname">${lab}</div><div class="pick1"><button class="btn" data-d="-1">◀</button><div class="pv1">${col?`<span class="sw on" style="background:${col(v)}"></span>`:''}<b>${nm(v)}</b><div class="mut">${v+1} / ${n}</div></div><button class="btn" data-d="1">▶</button></div>
   ${col?`<div class="row swrow">${Array.from({length:n},(_,i)=>`<button class="sw ${i===v?'on':''}" data-v="${i}" style="background:${col(i)}" title="${nm(i)}"></button>`).join('')}</div>`:''}`}
 else if(st.paid){const [k,lab,arr]=st.s,v=c[k],it=arr[v];
  body=`<div class="stepname">${lab}</div><div class="pick1"><button class="btn" data-d="-1">◀</button><div class="pv1"><b>${it.n}</b><div class="c-gold">แต้ม ${it.c}</div></div><button class="btn" data-d="1">▶</button></div><p class="mut" style="text-align:center">${it.d}</p>
   <div class="row" style="justify-content:center;gap:4px">${arr.map((x,i)=>`<button class="btn sm ${i===v?'on':''}" data-v="${i}" ${i!==v&&x.c-it.c>left?'disabled':''}>${x.n} · ${x.c}</button>`).join('')}</div>`}
 else if(st.k==='talents'){
  body=`<div class="stepname">พรสวรรค์แรกเกิด</div><p class="mut" style="text-align:center;font-size:13px">${FREE?'โหมดไม่จำกัด: เลือกได้ทุกใบ':`แต้มพรสวรรค์: <b class="c-gold">${tleft} / ${TBUDGET}</b> · เลือกได้สูงสุด 3 ใบ ข้อเสียให้แต้มคืน ว่างไว้ ฟ้าจะลิขิตให้เอง`}</p>
   <div class="tgrid">${DECK.map(t=>{const on=c.talents.includes(t.id),dis=!on&&(c.talents.length>=TMAX||t.c>tleft);return `<button class="tcard ${on?'on':''} ${t.bad?'bad':''} ${tierCls(t)}" data-t="${t.id}" ${dis?'disabled':''}><span class="tc">${t.c>0?t.c:'+'+(-t.c)}</span><span class="ti">${t.ic}</span><b>${t.n}</b><span>${t.d}</span><span class="tl">${tierName(t)}</span></button>`}).join('')}</div>
   ${FREE?'':`<div class="row" style="justify-content:center"><button class="btn" id="reroll">🎲 สุ่มใหม่</button><span class="mut">สุ่มแล้ว ${w.rolls} ครั้ง (ใบที่เลือกไว้ไม่หาย)</span></div>`}`}
 else{body=`<div class="stepname">ชื่อ</div><input id="wname" maxlength="16" value="${esc(c.name||'')}" placeholder="เว้นว่างไว้ ให้ฟ้าตั้งชื่อให้">`}
 const last=w.i===w.steps.length-1;
 $('#modal').innerHTML='';
 $('#app').innerHTML=`<div class="panel wz"><div class="row"><h2>${w.mode==='edit'?'แต่งตัวใหม่':w.mode==='full'?'สร้างชีวิตเอง':FREE?'สร้างเองไม่จำกัดแต้ม':'ออกแบบหน้าตา'}</h2><span class="sp"></span>${w.mode==='full'?`<span class="chip">แต้มคงเหลือ ${left} / ${BUDGET}</span>`:''}<span class="mut">${w.i+1} / ${w.steps.length}</span></div>
  <div class="wzgrid"><canvas id="pv" width="120" height="150" class="px pvbox"></canvas><div>${body}</div></div>
  <div class="row"><button class="btn" id="rnd">🎲 สุ่มหน้าตา</button><span class="sp"></span><button class="btn" id="back">${w.i?'ย้อนกลับ':'ปิด'}</button><button class="btn pri" id="next">${last?(w.mode==='edit'?'บันทึก':'เริ่มชีวิต'):'ถัดไป'}</button></div></div>`;
 const setv=v=>{if(st.look){const [k,,n]=st.s;v=(v+n)%n;if(k==='sex'){L.sex=v?'f':'m';c.sex=L.sex}else L[k]=v}else if(st.paid){const [k,,arr]=st.s;v=(v+arr.length)%arr.length;const d=arr[v].c-arr[c[k]].c;if(d<=left)c[k]=v}wizard()};
 document.querySelectorAll('[data-d]').forEach(b=>b.onclick=()=>{let cur=st.look?(st.s[0]==='sex'?(L.sex==='f'?1:0):L[st.s[0]]):c[st.s[0]];if(st.paid){const arr=st.s[2];let v=cur;for(let i=0;i<arr.length;i++){v=(v+(+b.dataset.d)+arr.length)%arr.length;if(arr[v].c-arr[cur].c<=left)break}return setv(v)}setv(cur+(+b.dataset.d))});
 document.querySelectorAll('[data-v]').forEach(b=>b.onclick=()=>setv(+b.dataset.v));
 document.querySelectorAll('[data-t]').forEach(b=>b.onclick=()=>{const id=b.dataset.t,i=c.talents.indexOf(id);if(i>=0)c.talents.splice(i,1);else c.talents.push(id);wizard()});
 const rr=$('#reroll');if(rr)rr.onclick=()=>{w.rolls++;const keep=w.deck.filter(t=>c.talents.includes(t.id));w.deck=[...keep,...TALENTS.filter(t=>!keep.includes(t)).sort(()=>Math.random()-.5).slice(0,9-keep.length)];wizard()};
 const wn=$('#wname');if(wn)wn.oninput=()=>c.name=wn.value;
 $('#rnd').onclick=()=>{const s=L.sex;c.look=randomLook(s);wizard()};
 $('#back').onclick=()=>{if(w.i){w.i--;wizard()}else{WZ=null;w.mode==='edit'?render():startScreen()}};
 $('#next').onclick=()=>{if(!last){w.i++;return wizard()}
  if(w.mode==='edit'){P.look=c.look;WZ=null;save();render();return}
  if(w.mode==='look'){const r=randomCfg(c.sex,c.look);r.name=c.name;begin(r);return}
  begin(c)};
}
