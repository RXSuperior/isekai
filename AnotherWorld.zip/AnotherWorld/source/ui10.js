// ---- v9: กระดานประกาศในแท็บแผนที่ + บ้านมองจากข้างนอกตามฐานะ + ร่องรอยเหตุการณ์ ----
const _map10=views.map;views.map=()=>{const t=tfTier(),nx=TF_TIERS[t+1];
 const board=(P.board||[]).map(id=>BOARD.find(b=>b.id===id)).filter(Boolean);
 return `<div class="card"><div class="row"><b>ชื่อเสียงใน${TOWN}</b><span class="chip">${TF_TIERS[t][1]}</span><span class="sp"></span><span class="mut">${P.tfame||0}${nx?` / ${nx[0]}`:''}</span></div>${bar(P.tfame||0,nx?nx[0]:400,'#ffd36b')}</div>
 <h3>กระดานประกาศ <span class="mut" style="font-size:13px">เปลี่ยนทุกฤดู</span></h3>
 ${board.length?board.map(b=>`<div class="card row"><div class="sp"><b>📜 ${b.n}</b><div class="mut" style="font-size:13px">${b.d}</div></div><button class="btn sm pri" data-board="${b.id}" ${PENDING.length?'disabled':''}>รับงาน</button></div>`).join(''):'<p class="mut">ฤดูนี้ไม่มีประกาศ</p>'}
 <h3>สถานที่</h3>`+_map10()};
const _render10=render;render=function(){_render10();document.querySelectorAll('[data-board]').forEach(b=>b.onclick=()=>{takeBoard(b.dataset.board);save();render()})};
