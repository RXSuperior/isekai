ต่างโลกที่ไม่มีทางกลับ (Another World: No Return)

game/       เกมพร้อมเล่น เปิด game/index.html ผ่านเว็บเซิร์ฟเวอร์ (เช่น python -m http.server ในโฟลเดอร์ game แล้วเข้า http://localhost:8000)
game/a/     ภาพทั้งหมดที่ใช้ในเกม
            gh/  ตัวละครและฉากป่า (GandalfHardcore)
            m/   สไลม์ โครงกระดูก หมาป่า (CraftPix)
            m2/  มอนสเตอร์ td แม่ทัพ จอมมาร เอฟเฟกต์ pvfx
            bg/  ฉากหลังต่างโลก (CraftPix)
            fx/  เอฟเฟกต์เวท  i/ ไอคอนไอเทม  c/ NPC พ่อค้า
            art/char/ ชั้นภาพที่วาดเอง (ทูนิก ไม้เท้า)
docs/       GAME_REFERENCE.html (ภาพและระบบทั้งหมด), คู่มือสไตล์, audit, manifest, backlog, ระบบตัวละคร
            tools/build_char_layers.py สคริปต์สร้างชั้นภาพตัวละคร
source/     ซอร์สโค้ดทุกไฟล์ ประกอบด้วย python3 assemble.py (ต้องวางโฟลเดอร์ a ไว้ข้าง ๆ)

หมายเหตุสัญญาอนุญาต: ภาพ GandalfHardcore และ CraftPix ใช้ในเกมได้ แต่ห้ามแจกไฟล์ต้นฉบับต่อ
